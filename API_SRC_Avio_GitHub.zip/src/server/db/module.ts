import {db} from "./db-provider";

export class ModuleDBOperations {
  async queryModuleDetails(queryText: string, params: []) {
    let dbResult: any;
    dbResult = await db.query(queryText, params);
    return dbResult.rows;
  }
}
