import express, {Request, Response} from 'express';
import fs from 'fs';
import { Path } from 'aws-sdk/clients/codecommit';
import paths from 'path';
import logger from '../../../../logger';
const routes = express.Router();

const logPath = paths.join(__dirname, '..', '..','..', '..','log','IOTKey.txt')



function WriteDataToFile(filePath:Path,fileContent:String)
{
     fs.appendFile(filePath
                   , "\n"+fileContent+"\n", function (err) {
  if (err) 
    {
        logger.error("error in module get function: " + err);
        console.log(err);
    }
  else{
    logger.debug("Saved File Confirmation");
  //console.log('Saved!');
  }
});
}



function WriteToFile(filePath:Path,Content:String)
{

//console.log(filePath)
    

 fs.stat(filePath, (exists) => {
    if (exists == null) {
        //console.log("Yes!!")
        WriteDataToFile(filePath,Content)
    } else if (exists.code === 'ENOENT') {
        //console.log("Not")
        var createStream = fs.createWriteStream(filePath);
        createStream.end();
        WriteDataToFile(filePath,Content)
        return false;
    }    
    });
}


routes.post('/', async (req: Request, resp: Response) => {
    if(req.body) {
       // console.log(logPath);
        WriteToFile(logPath,JSON.stringify(req.body));
        
        resp.sendStatus(200);
    }else {
        resp.sendStatus(500);
    }
        
});




export default routes;