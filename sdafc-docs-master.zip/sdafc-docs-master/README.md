# SDAFC
SDAFC is the new Service Desk AFC application deployed in Avio's VPC on Amazon Web Services. The complete documentation with compodoc is available [here](https://github.build.ge.com/pages/212606826/sdafc.github.io/)

__NOTE__: The first access for people with access to the old tool is to simply enter the SSO + Password and access the application directly. The new users must enter the SSO + Password: first, the system will not allow access to the site but the AFC admin will be able to provide access and communicate the successful approval. Each user is enabled to manage the requests of his own functional area and / or process.

### Application Environments
| Resource                         | Link                                                                                 |
| ----------                       | ------                                                                               |
| Login page for stage environment | [https://test-avsdafc.avio.net/user/login](https://test-avsdafc.avio.net/user/login) |
| Login page for prod  environment | [https://avsdafc.avio.net/user/login](https://avsdafc.avio.net/user/login)           |

### Local Resource and Repositories
| Resource             | Link                                                                                                         |
| ----------           | ------                                                                                                       |
| OpenID               | TODO                                                                                                         |
| API-Gateway          | [https://github.build.ge.com/AvioAero/api-gateway](https://github.build.ge.com/AvioAero/api-gateway)         |
| Angular.js Front-end | [https://github.build.ge.com/AvioAero/angular-starter](https://github.build.ge.com/AvioAero/angular-starter) |

### External Resources (AWS Console)
| Resource        | Link                                                                                                                                                                                                                 |
| ----------      | ------                                                                                                                                                                                                               |
| AWS Login       | [http://sc.ge.com/*AWSEntLogin](http://sc.ge.com/*AWSEntLogin)                                                                                                                                                       |
| AWS ECS Console | [https://eu-west-1.console.aws.amazon.com/ecs/home?region=eu-west-1#/clusters/AV-ECS-Cluster-dev/services](https://eu-west-1.console.aws.amazon.com/ecs/home?region=eu-west-1#/clusters/AV-ECS-Cluster-dev/services) |
| AWS Lambda(s)   | [https://eu-west-1.console.aws.amazon.com/lambda/home?region=eu-west-1#/functions](https://eu-west-1.console.aws.amazon.com/lambda/home?region=eu-west-1#/functions)                                                 |
| AWS DynamoDB    | [https://eu-west-1.console.aws.amazon.com/dynamodb/home?region=eu-west-1](https://eu-west-1.console.aws.amazon.com/dynamodb/home?region=eu-west-1)                                                                   |
| AWS S3          | [https://s3.console.aws.amazon.com/s3/home?region=eu-west-1](https://s3.console.aws.amazon.com/s3/home?region=eu-west-1)                                                                                             |

### Contents:
[[1] Involved technologies overview](#overview)

[[2] SDAFC Big Picture](#sdafc-big-picture)

[[3.1] Application Functional flow](#app-func-flow)

[[3.2] Application Technical flow](#app-tech-flow)

[[4] Repositories](#repositories)

[[4.1] Avio Repository](#avio-repositories)

[[4.2] Automatic Deploy](#deploy)

[[5] Notes](#notes)

[[6] Contacts](#contacts)

### <a name="overview"></a>Involved technologies overview
The application involves the use of the following technologies:

- [OpenID](http://openid.net/connect/)
- [Node.js](https://nodejs.org/en/)
- [Angular.js](https://angular.io)
- [Docker](http://docker.com)
- [AWS Elastic Container Service](https://aws.amazon.com/en/ecs/)
- [AWS Lambda](https://aws.amazon.com/en/lambda/)
- [AWS DynamoDB](https://aws.amazon.com/en/lambda/)
- [AWS S3](https://aws.amazon.com/en/lambda/)

Each of theme is briefly described in the next paragraph: further, the _scenario(s)_ explain the role in the SDAFC application

#### <a name="open-id"></a>OpenID
```OpenID Connect 1.0``` (more [here](http://openid.net/connect/)) is an identity layer on top of the ```OAuth 2.0``` protocol. It allows clients to verify the identity of the end-user based on the authentication performed by an authorization server, as well as to obtain basic profile information about the end-user in an interoperable and REST-like manner. This technology allows clients to request and receive information about authenticated sessions and end-users. 

##### Scenario
OpenID Connect is used in our scenario to provide the login through the SSO (Single Sign On) mechanism.

#### <a name="node-js"></a>Node.js
```Node.js``` (more [node.js](https://nodejs.org/en/)) is a javaScript runtime built on Chrome's V8 JavaScript engine that acts as a web-server. Node.js uses an event-driven, non-blocking I/O model that makes it lightweight and efficient. Node.js' package ecosystem is called ```npm```.

##### Scenario
Node.js is used in our AWS ECS (see later) Cluster as both (internal) API Gateway to expose AWS Lambda and to serve the front-end developed using Angular.js

#### <a name="angular-js"></a>Angular.js
```AngularJS``` (more [here](https://angular.io)) is a JavaScript-based open-source front-end web application framework mainly maintained by Google: the framework works by first reading the HTML page, which has additional custom tag attributes embedded into it. Angular interprets those attributes as directives to bind input or output parts of the page to a model that is represented by standard JavaScript variables. The values of those JavaScript variables can be manually set within the code, or retrieved from static or dynamic JSON resources.

##### Scenario
Angular.js is the framework used to develop the front-end for the SDAFC application. The source of the applications are written in ```Typescript```, then compiled with static resources to be optimally served.

#### <a name="docker"></a>Docker
```Docker``` (more [here](http://docker.com)) is a tool that performs operating-system-level virtualization also known as ```containerization```. Containerization is a extremely used way to isolate an application from the environment in which it is deployed: in this way, you can build a container and then run it without any problems in any environment that can run a docker-daemon.

##### Scenario
In SDAFC, Docker is used to run a Node.js server to serve both the application front-end (written in Angular) and the API Gateway to expose AWS Lambda functions.

#### <a name="api-gateway"></a>AWS ECS (API Gateway)
```AWS Elastic Container Service``` (more [here](https://aws.amazon.com/en/ecs/)) permits you run and manage Docker container. In the VPC the ECS Cluster is named ```AV-ECS-Cluster-dev``` and host Avio Dockers container. The ```API Gateway``` service is running over a Docker container in Avio's AWS ECS Cluster. This service _emulate_ the API Gateway service by Amazon Web Services. 

##### Scenario
Avio use its own API Gateway developed using Node.js for security reason imposed by GE on its Aviation Business and Sub-Business. For this application, the involved containers are four (two for stage, two fro production environment):

- _ticket-__[prod/no-prod]__-FrontendTemplateProd-43TS9996DXN5-service-15FMQONQXS6W3_
- _ticket-__[prod/no-prod]__-ApiGatewayTemplateProd-1VJXA2N4HOAJ-service-PPKQ2K0314WT_

The console to manage the AWS ECS Cluster is available at [https://eu-west-1.console.aws.amazon.com/ecs/home?region=eu-west-1#/clusters/AV-ECS-Cluster-dev/services](https://eu-west-1.console.aws.amazon.com/ecs/home?region=eu-west-1#/clusters/AV-ECS-Cluster-dev/services). 

#### <a name="lambdas"></a>AWS Lambdas
```AWS Lambda``` (more [here](https://aws.amazon.com/en/lambda/)) lets you run code (single methods - there are many supported languages) without provisioning or managing servers. The code is pushed - as is - in AWS Lambda console: you can set up the functions to automatically trigger from other AWS services or call it directly from any web or mobile app.

__NOTE__: AWS Lambdas are NOT running on ECS cluster because 1) literally they are not running at all, if nobody is using the application and 2) even when they are triggerd but any kind of event (in this scenario, an API call), Amazon Web Services takes care of creating a container, run the function, and destroy the container after a certain amount of time. This is completly done by AWS.

##### Scenario
Avio used Node.js for each of the SDAFC AWS Lambda functions. For this application, the involved lambda(s) are 40 (20 for stage, 20 for production environment).

| Function Name                                                | Runtime      | Code size   |
| ---------------                                              | ---------    | ----------- |
| aviotkt\___[prod/no-prod]__\_delete\_ticket\_id              | Node.js 6.10 | 2.6 MB      |
| aviotkt\___[prod/no-prod]__\_delete\_user\_id                | Node.js 6.10 | 2.6 MB      |
| aviotkt\___[prod/no-prod]__\_get\_dashboard                  | Node.js 6.10 | 2.6 MB      |
| aviotkt\___[prod/no-prod]__\_get\_ticket                     | Node.js 6.10 | 2.6 MB      |
| aviotkt\___[prod/no-prod]__\_get\_ticket\_id                 | Node.js 6.10 | 2.6 MB      |
| aviotkt\___[prod/no-prod]__\_get\_upload\_sign               | Node.js 6.10 | 2.6 MB      |
| aviotkt\___[prod/no-prod]__\_get\_user                       | Node.js 6.10 | 2.6 MB      |
| aviotkt\___[prod/no-prod]__\_get\_user\_id                   | Node.js 6.10 | 2.6 MB      |
| aviotkt\___[prod/no-prod]__\_patch\_ticket\_id               | Node.js 6.10 | 2.6 MB      |
| aviotkt\___[prod/no-prod]__\_patch\_ticket\_id\_assign       | Node.js 6.10 | 2.6 MB      |
| aviotkt\___[prod/no-prod]__\_patch\_ticket\_id\_note\_idnote | Node.js 6.10 | 2.6 MB      |
| aviotkt\___[prod/no-prod]__\_patch\_user\_id                 | Node.js 6.10 | 2.6 MB      |
| aviotkt\___[prod/no-prod]__\_post\_login                     | Node.js 6.10 | 2.6 MB      |
| aviotkt\___[prod/no-prod]__\_post\_ticket                    | Node.js 6.10 | 2.6 MB      |
| aviotkt\___[prod/no-prod]__\_post\_ticket\_id\_note          | Node.js 6.10 | 2.6 MB      |
| aviotkt\___[prod/no-prod]__\_post\_user                      | Node.js 6.10 | 2.6 MB      |
| aviotkt\___[prod/no-prod]__\_stream\_new\_note               | Node.js 6.10 | 2.6 MB      |
| aviotkt\___[prod/no-prod]__\_stream\_new\_ticket             | Node.js 6.10 | 2.6 MB      |
| aviotkt\___[prod/no-prod]__\_stream\_patch\_note             | Node.js 6.10 | 2.6 MB      |
| aviotkt\___[prod/no-prod]__\_stream\_patch\_ticket           | Node.js 6.10 | 2.6 MB      |

The console to manage AWS Lambda(s) is available at [https://eu-west-1.console.aws.amazon.com/lambda/home?region=eu-west-1#/functions](https://eu-west-1.console.aws.amazon.com/lambda/home?region=eu-west-1#/functions). 

For more details about the function flow, see the section [[3.2] Application Technical flow](#app-tech-flow).

#### <a name="dynamodb"></a>AWS DynamoDB
```Amazon DynamoDB``` is a fast and flexible NoSQL database service: it is a fully managed cloud database and supports both document and key-value store models. You can setup performance with fine-grained configuration (number of i/o for second in writing and reading table).

#### Scenario
In our scenario, AWS DynamoDB is used to store data related to users, opened tickets and attached notes. There are 10 (5 for prod, 5 for stage) tables:

| Name                  | Status   | Partition Key   | Sort Key   | Indexes   | Total Read Capacity   | Total Write Capacity   | Auto Scaling   | Encryption   |
| ------                | -------- | --------------- | ---------- | --------- | --------------------- | ---------------------- | -------------- | ------------ |
| ticket-no-prod-note   | Active   | id (String)     | -          | 0         | 10                    | 3                      | -              | -            |
| ticket-no-prod-stat   | Active   | id (String)     | -          | 0         | 10                    | 3                      | -              | -            |
| ticket-no-prod-ticket | Active   | id (String)     | -          | 4         | 50                    | 15                     | -              | -            |
| ticket-no-prod-token  | Active   | id (String)     | -          | 0         | 10                    | 3                      | -              | -            |
| ticket-no-prod-user   | Active   | id (String)     | -          | 3         | 40                    | 12                     | -              | -            |
| ticket-prod-note      | Active   | id (String)     | -          | 0         | 10                    | 3                      | -              | -            |
| ticket-prod-stat      | Active   | id (String)     | -          | 0         | 10                    | 3                      | -              | -            |
| ticket-prod-ticket    | Active   | id (String)     | -          | 4         | 50                    | 15                     | -              | -            |
| ticket-prod-token     | Active   | id (String)     | -          | 0         | 10                    | 3                      | -              | -            |
| ticket-prod-user      | Active   | id (String)     | -          | 3         | 40                    | 12                     | -              | -            |

The console to manage the AWS DynamoDB is available at [https://eu-west-1.console.aws.amazon.com/dynamodb/home?region=eu-west-1](https://eu-west-1.console.aws.amazon.com/dynamodb/home?region=eu-west-1)

#### <a name="s3"></a>AWS S3
```Amazon S3``` is an object storage system built to store and retrieve any amount of data from anywhere. The files are organized in buckets and for each buckets you can specify security policies to allow - at groups, users and roles levels - to manipulate files stored in them.

#### Scenario
In our scenario S3 is used to store the file eventually attached to the tickets opened from the users in the application. For this application, the involved AWS S3 buckets are four (two for stage, two fro production environment):

- _ticket-__[prod/no-prod]__-serverlessdeploymentbucket-3oighhx5vz5w_: used for the deploy of the lambda function throught CloudFormation
- _ticket-__[prod/no-prod]__-no-prod-sdafc-files_: used to effectively store the files.

The console to manage the AWS S3 is available at [https://s3.console.aws.amazon.com/s3/home?region=eu-west-1](https://s3.console.aws.amazon.com/s3/home?region=eu-west-1).

### <a name="sdafc-big-picture"></a>SDAFC Big Picture
The application is integrated with OpenID: the application login page is reachable at [https://test-avsdafc.avio.net/user/login](https://test-avsdafc.avio.net/user/login) for stage and [https://avsdafc.avio.net/user/login](https://avsdafc.avio.net/user/login) for prod. After the login, you will be automatically redirect to the the dashboard page.

#### <a name="app-arch-flow"></a>Application Architecture
The application architecture is show in the following schema:

<img src="./img/sdafc.png" alt="SDAFC Application Architecture" style="width: 40%;"/>

#### <a name="app-tech-flow"></a>Application Technical flow
SDAFC Front-end works using 11 different module: the next paragraphs some there is a brief description of some of them with a focus on Authentication procedure.

##### AppModule
This is the main module that links part together. It provides declarations of the following components:

- AppComponent
- HomeComponent
- AboutComponent
- NoContentComponent
- XLargeDirective

The ```AppComponent``` sets the app state by trying to retriving the ```identity``` of the user from the local storage, implemented using the ```ngx-webstorage``` package available in npm (more [here](https://github.com/RenovoSolutions/ngx-webstorage)). The ngx-webstorage is a service for utilizing both local and session storage resources of a browser. The ```checkAcl``` method that checks if role (ex. ROLE\_USER) is in the array of roles admitted by the list, or if the role list is a void array (that means that the request route is public).

The ```HomeComponent``` is routed by ```home``` path as defined in ```app.route.ts```. It is a sort of middleware component that __redirect the user__ to the ```'/ticket/list/1```. The redirect is catched by routes defined in the ```RouterModule``` imported in ```ticket.module.ts```. See the next paragraph for the more details about the tickets retrieval.

##### TicketModule
The ```TicketModule``` contains declarations of three different component:
- TicketListComponent
- TicketEditComponent
- TicketUploadComponent

The ```RouterModule``` declaration inside provide routes to engage the three component.

```js
RouterModule.forRoot([
	{ path: 'ticket/list/:page', component: TicketListComponent, data: {acl: "*", section:'ticket.list'} },
	{ path: 'ticket/edit/:id', component: TicketEditComponent, data: {acl: "*"} },
	{ path: 'ticket/new', component: TicketEditComponent, data: {acl: "*", section:'ticket.new'} },
]),
```

For instance, after the authentication (see above), the ```TicketListComponent``` is engaged: by using the ```TicketService```, the component - _on init_ (look at ngOnInit()) - call the search() method and retrieves and populate the ticket list of the component. In the template, an ```ngFor``` loop over the list property of the TicketListComponent and fills the template.

##### Authentication
The authentication is done by the ```UserLoginComponent```. This component contains the ```login()``` method

```js
public login(username, password): any {
	let p = new Promise((resolve, reject) => {
		this.http.post(CONFIG.endpoint + 'login',  {username: username, password: password}, {observe: 'response'}).toPromise().then(res => { 
			this.storage.store("identity", {user: res.body['user'], access_token: res.body['access_token'], role: res.body['user'].role});
			resolve(res);
		}, 
		err => reject(err));
	});
	return p;
}
```

This method call the URL generated by looking in the ```CONFIG``` const exposed by ```CoreModule``` for the api ```endpoint```: the URL is composed by the ```endpoint``` defined in ```core.module.ts``` and ```login``` path. The HTTP request is a POST request. The call is handled by the Application Load Balancer the __routes the requests__ to the ```AWS ECS``` cluster. Then, the API Gateway handles the request: the routes handled are defined in the API Gateway repository, the Avio repository with the code of the Node.js server that handle the application requests. The file that define the route request is [here](https://github.build.ge.com/AvioAero/api-gateway/blob/master/src/routes.js). It looks like

```js
const router = require('express').Router()
  api = require('./api-gateway');

router.get('/ping', function(req, res) {
  res.json("OK");
});

router.post('/login', api.route);

router.get('/ticket', api.route);
router.get('/ticket/:id', api.route);
router.get('/ticket/:id/note', api.route);
router.post('/ticket/:id/note', api.route);
router.patch('/ticket/:id/note/:idnote', api.route);
...
```

The api.route is exported from the [here](https://github.build.ge.com/AvioAero/api-gateway/blob/master/src/api-gateway.js). In this, the function ```route``` __literally composes the lambda function request__ using the HTTP request method (in the case of the authentication, a POST request), the path required to the API Gateway (in the case of the authentication, login). The lambda name composition is accomplished by the createLambdaFunctionName that actually create the lambda function name using the following pattern

```js
let lambdaName = `aviotkt_${env}_${method}${path}`;
```

The lambda is then invoked by the route function throught the invoke call.

```js
module.exports = {
  route: function(req, res) {
    const env = req.app.get('env');
    const lambda = req.app.get('aws').lambda;

    lambda
        .invoke(
          createLambdaFunctionName(env, req),
          convertRequest(req)
        ).then((data) => {
          res.json(apiResponseConverter(res, createResponseFromLambdaResponse(data)));
        }, (err) => {
          res.json(apiResponseConverter(res, createError(err)));
        });
  }
};
```

Thus, the invoked lambda for the authentication will be the 

```shell
aviotkt_[prod/no-prod]_post_login
```

The entry point (the ```index.js``` file) of the prod env version of the lambda - available [here](https://eu-west-1.console.aws.amazon.com/lambda/home?region=eu-west-1#/functions/aviotkt_prod_post_login?tab=graph) is shown below.

```js
'use strict';

var lib = require('../lib');

// POST LOGIN
module.exports.post = (event, context, callback) => {
  var user = require('../db/user');
  var token = require('../db/token');
  var body = JSON.parse(event.body);
//
  // input vlaidation
  lib.validate(body, "Login").then(function() {
    console.log("login con " + body.username);
    // make login with username e password
    user.login(body.username, body.password).then(function(user) {
      //7200000
      token.put({id: user.access_token.substr(0, 47), userId: user.user.id, expiresAt: new Date().getTime() + 7200000}).then(function() {
        context.done(null, lib.response(user, 200));
      })
    }, function(err) {
    	...
```

A method called login is called over the user - imported with the require statement from the db folder. The login method in the ```user.js``` file is shown below:

```js
User.prototype.login = function(username, password) {

  var d = q.defer();
  rp.post(process.env.OAUTH_SERVER, { json:true, form: {
    username: username,
    password: password,
    client_id: process.env.CLIENT_ID,
    client_secret: process.env.CLIENT_SECRET,
    grant_type: "password",
    scope: process.env.OAUTH_SCOPES,
  }}).then(function(res) {
    lib.authO({headers: {authorization: 'Bearer ' + res.access_token}}).then(function(activeUser) {
      console.log("user", activeUser);
      if(!activeUser.mail) {
        // d.reject({message: "user without email"});
        // activeUser.mail = "gianmario.perlo@avioaero.it";
      }
      d.resolve({
        access_token: res.access_token,
        user: activeUser
      })
    }, function(err) {
      d.reject(err);
    } );
```

Each ```process.env``` vars are the environment variables defined for each AWS Lambda functions. 

Back to the ```index.js``` file of the ```aviotkt_[prod/no-prod]_post_login```, if the user is successfully authenticated by the OpenID server of GE, then the access token is stored in the DynamoDB table throught the use of ```token```. Inside ```token.js``` the ```put``` method is defined as shown below:

```js
Token.prototype.put = function(token) {
	var d = q.defer();
	if(!token.id) {
		d.reject("no token id");
	}
	else {
		this.docClient.put({Item: token, TableName: tableName}).promise().then(function() {
		d.resolve(token);
	}, function(err) {
		d.reject(err);
		});
	}
	return d.promise;
};
```

All the steps accomplished by the architecture for the authentication are shown in the below schema: the number of each step are described after the image.

<img src="./img/authentication.png" alt="SDAFC Authentication Flow" style="width: 35%;"/>

##### Steps
1) A User points his browser to [https://avsdafc.avio.net/]([https://avsdafc.avio.net/).

2) The request is handled by the Application Load Balancer that routes the request to the Avio AWS ECS Cluster. 

3) The Docker that run the Node.js server handles the request and provide the respective dashboard page - if it is already logged. In the general case, the user is automatically redirected [https://avsdafc.avio.net/user/login]([https://avsdafc.avio.net/user/login).

4) The login page is shown

<img src="./img/login.png" alt="SDAFC Login Screen" style="width: 35%;"/>

When the user insert his credentials and click on the access button - defined in the ```user-login.component.html```
```js
<button type="submit" [ladda]="loginLoading" [disabled]="!loginForm.valid" (click)="login()"
```
he will call the login function explained before. 

5) The ```login()``` function (see above) is called. The request to the API is composed in the front-end and the service make an POST HTTP request to the API Gateway on the login route.

6) The API Gateway composes the right lambda function name using the environment variables, the HTTP method used and the path of the original request: after the composition, it calls the right lambda.

For other details about functioning of each  modules, components and services, look at the ```Modules``` of the compodoc (generated in ```/docs``` folder). See at the end of this README.md about how to automatically generate documentation for the project.

7) The invoked AWS Lambda - compose the oauth request using environment variables and ask to the GE OpenID system to provide an access token for the user.

8) In case of error, the chain breaks and the front-end shows an Authentication Error (the first login will follow this case). In case of success, the OpenID server provides the token.

9) The token is stored in AWS DynamoDB by the token.js ```put``` function in the process.env.DYNAMODB_TOKEN_TABLE.

### <a name="repositories"></a>Repositories

#### <a name="avio-repositories"></a>Avio Repositories

- [API-Gateway](https://github.build.ge.com/AvioAero/api-gateway)
- [Front-end](https://github.build.ge.com/AvioAero/angular-starter)

#### <a name="deploy"></a>Automatic Deploy

TODO

### <a name="notes"></a>Notes

To build the application starting from zero, you need npm. Then

```shell
npm install
npm start
npm run build:prod
```

To create updated docs,

```shell
npm run docs:compodoc
```

### <a name="contacts"></a>Contacts

TODO

## Application OpenID usage

The application uses OpenId to support the authentication process. In particular
the `password mode` is used to support the user login flow.

The password mode is currently one of the simplest way to use the OAuth2/OpenId
Connect cross login feature.


```shell
curl -X POST \
  https://fssfed.ge.com/fss/as/token.oauth \
  -H 'Cache-Control: no-cache' \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  -H 'Postman-Token: 067b50ab-24ba-4868-be68-5bc8fefe05fa' \
  -d 'grant_type=password&client_id=UAI2000593&client_secret=testtest&username=YOUR_GE_SSO_USERNAME&password=HERE_THE_SUPER_SECRET_PASSWORD&scope=openid%20api%20profile'
```

When you create your application credentials, identified by the `client\_id` and
`client\_secret` variables you can only uses three scopes:

 * api
 * openid
 * profile

Those scopes limits the amount of data that you can retrieve back from the SSO
endpoint provided by GE.

The authentication token is provided by the final endpoint [https://fssfed.ge.com/fss/as/token.oauth](https://fssfed.ge.com/fss/as/token.oauth)

```
{
    "access_token":"xxxxxxxxxxxxxxxxxxxxxxxxxxxx",
    "refresh_token":"xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
    "token_type":"Bearer",
    "expires_in":7199
}
```

The OAuth2 response is composed by the access_token, and the refresh_token.
The access_token is used to provide the user credentials accross different
applications and the refresh_token is used to create a new authentication token
(access_token) without require the user engagement.

You can find the whole OpenID configuration using the fssfed well known
configuration endpoint: [https://fssfed.ge.com/fss/.well-known/openid-configuration](https://fssfed.ge.com/fss/.well-known/openid-configuration)

### Create CLIENT\_ID and CLIENT\_SECRET

The CLIENT_ID and CLIENT_SECRET must be created using the dedicated web
application [https://oidcapi.corporate.ge.com/#/submit](https://oidcapi.corporate.ge.com/).
The CLIENT_ID and  CLIENT_SECRET ara mandatory to correctly create the login
procedure. The token validation and expiration changes from 6hours to 1 hour and
dependes on the kind of information that your appplication manage. During the
token creation you have to correly select all the authorization information.

![img/oidc.png](img/oidc.png)

When you add a new client you have to create a complete configuration. Here the base example

![img/oidc-create.png](img/oidc-create.png)

When you create your client you can always update your configuration

![img/oidc-update.png](img/oidc-update.png)

### Register your API

When you create a new API you can also register your application to the Akana application discovery application. This procedure allows anybody to discover and use your APIs.

Here the Akana portal: [https://catalog.api.ge.com/apis/#/home/login](https://catalog.api.ge.com/apis/#/home/login)

![img/akana.png](img/akana.png)

The GE logo allow you to use the SSO feature. When you are correctly logged in you can add your API to the Akana community.

![img/akana-in.png](img/akana-in.png)
