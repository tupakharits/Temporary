import { Component, OnInit } from '@angular/core';
import { ChartDataSets, ChartOptions } from 'chart.js';
import { Color, Label } from 'ng2-charts';
import { MotorService } from  '../_Services/motor.service';
import { utilityservice } from '../_Services/utility.service';
import { NgxSpinnerService } from "ngx-spinner"; 
@Component({
  selector: 'app-forecast',
  templateUrl: './forecast.component.html',
  styleUrls: ['./forecast.component.scss']
})
export class ForecastComponent implements OnInit {

  constructor(private util:utilityservice,private MotorService:MotorService,private SpinnerService: NgxSpinnerService) { 
    this.util.displayNoSignUp=true;
    this.MotorName=this.util.motorName;
  }
public MotorName:string='X-Motor';
public Chart_selected:string='Power';
public motorDetails:any[];
public width:number=500;
public param_factor='MotorPower';
public GraphDetails:any;
DbConnectionFail=false;
public PerformanceTimeLineChart: any[]=[//] ChartDataSets[] = [
  { data: [], label: 'Power',fill: false },
   { data: [], label: 'Forecast',fill: false },
  { data: [], label: 'Max Warning',fill: false },
  { data: [], label: 'Max Critical',fill: false }
  // { data: [], label: 'Min Threshold',fill: false },
  //   { data: [], label: 'Min Warning',fill: false }
];

 public PerformanceTimeLineChartLabels: Label[] = [];//['12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00','19:00'];

private  PerformanceTimeLineOptions: any = {
  legend: { position: 'bottom' },
  scales: {
    yAxes: [{
        ticks: {
            beginAtZero: true
        }
    }]
  }
}
public PerformanceTimeLineChartColors: Color[] = [
  {borderColor: 'blue'},
  {borderColor:'#C4EE17'},
    {borderColor: 'Orange',},
    {borderColor: 'red',},
    {borderColor: 'Orange',},
    {borderColor: 'red',},
];
public PerformanceTimeLineChartLegend = true;
public PerformanceTimeLineChartType = 'line';
public PerformanceTimeLineChartPlugins = [];
public Selected_Param='Power';


  ngOnInit() {
    this.showConfig();
  }
showConfig(){
  this.SpinnerService.show();
  this.MotorService.getMotorDetails().subscribe((data) => {
    this.motorDetails=data;
    this.DbConnectionFail=false;
  },
  error =>{ 
    this.DbConnectionFail=true;
    console.log("Error :: " + error)}
  );

   var params={
       PartName:this.MotorName,
       Parameter:this.Chart_selected
        }
    this.MotorService.getMotorForcastDetails(params).subscribe((data)=>
    {
       this.GraphDetails=data;
       this.DbConnectionFail=false;
       this.clearChart();
       this.LoadChart(this.GraphDetails);
       this.SpinnerService.hide();
        },
        error =>{ 
          this.DbConnectionFail=true;
          this.SpinnerService.hide();
          console.log("Error :: " + error)});

}

  public ChangeMotor(Motor_name){   
    this.MotorName=Motor_name;
    this.showConfig();
  }
  public LoadChart(graphDetails){
    if(graphDetails.HistoricData.length>0){
      for(let i=0;i<graphDetails.HistoricData.length;i++)
      {
        this.PerformanceTimeLineChartLabels.push(graphDetails.HistoricData[i].DateTime);
        this.PerformanceTimeLineChart[0].data.push(graphDetails.HistoricData[i].value);//Power
        if(i==graphDetails.HistoricData.length-1)
            this.PerformanceTimeLineChart[1].data.push(graphDetails.HistoricData[i].value);
        else
            this.PerformanceTimeLineChart[1].data.push(null);//Power Forecast
        this.PerformanceTimeLineChart[2].data.push(graphDetails.HistoricData[i].maxthreshold);//Max Threshold
        this.PerformanceTimeLineChart[3].data.push(graphDetails.HistoricData[i].maxcritical);//Max warning
        // this.PerformanceTimeLineChart[4].data.push(graphDetails.HistoricData[i].minthreshold);//Min Threshold
        // this.PerformanceTimeLineChart[5].data.push(graphDetails.HistoricData[i].mincritical);//Min critical
      }  
    }
    if(graphDetails.ForecastData.length>0){
      for(let i=0;i<graphDetails.ForecastData.length;i++){
      this.PerformanceTimeLineChartLabels.push(graphDetails.ForecastData[i].DateTime);
      this.PerformanceTimeLineChart[1].data.push(graphDetails.ForecastData[i].value);//Forecast
        this.PerformanceTimeLineChart[2].data.push(graphDetails.HistoricData[graphDetails.HistoricData.length-1].maxthreshold);//Max Threshold
        this.PerformanceTimeLineChart[3].data.push(graphDetails.HistoricData[graphDetails.HistoricData.length-1].maxcritical);//Max warning
        // this.PerformanceTimeLineChart[4].data.push(graphDetails.HistoricData[graphDetails.HistoricData.length-1].minthreshold);//Min Threshold
        // this.PerformanceTimeLineChart[5].data.push(graphDetails.HistoricData[graphDetails.HistoricData.length-1].mincritical);//Min critical
      }
    }
  }
  public clearChart(){
    this.PerformanceTimeLineChartLabels=[];
    for(let i=0;i<4;i++)
        this.PerformanceTimeLineChart[i].data=[];
  }
  public changeChart(Chart_data){
    if(Chart_data.index==0) //Power
    this.Chart_selected='MotorPower';
    else if(Chart_data.index==1)//Current
    this.Chart_selected='MotorCurrent';
    else if(Chart_data.index==2)//Motor Loading
    this.Chart_selected='MotorLoadingPercentage';
    this.Selected_Param=Chart_data.tab.textLabel;
    this.PerformanceTimeLineChart[0].label=Chart_data.tab.textLabel;
    this.showConfig();
  }
}
