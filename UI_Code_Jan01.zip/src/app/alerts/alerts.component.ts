import {Component, ViewChild, OnInit} from '@angular/core';
import {MatPaginator, MatSort, MatTableDataSource} from '@angular/material';
import { MotorService } from  '../_Services/motor.service';
import { utilityservice } from '../_Services/utility.service';
import {ExcelService} from '../_Services/excel.service';
import { DatePipe } from '@angular/common';
import { NgxSpinnerService } from "ngx-spinner"; 
@Component({
  selector: 'app-alerts',
  templateUrl: './alerts.component.html',
  styleUrls: ['./alerts.component.scss']
})

export class AlertsComponent implements OnInit {
  displayedColumns:string[] = ['id', 'progress','name',  'color','Alert_Description','Date_Time','Criticality','Status','Date_time_if_closed','Remarks'];
  //dataSource:any[]=[];
  AlertsData:any;
  
  private dataSource;
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;  
  @ViewChild(MatSort, {static: true}) sort: MatSort;
// params
startIndex=1;
recordeperage=5;
SortParameter='';
SortType='Ascending';
Alertlength;
pageSizeOptions: number[] = [5, 10, 25,50, 100];
DbConnectionFail=false;

constructor(private util:utilityservice,private motorService:MotorService,private excelService:ExcelService,
  private datePipe:DatePipe,private SpinnerService: NgxSpinnerService) {
    this.util.displayNoSignUp=true; 
    // Assign the data to the data source for the table to render
    this.dataSource = new MatTableDataSource([]);
    this.Alertlength;
  }
  ngOnInit(){
    this.GetAlertData(); 
    //this.dataSource.paginator = this.paginator;
  }

  GetAlertData(){
    this.SpinnerService.show()
    this.dataSource.data =[];
    var params={
        "pageIndex":this.startIndex,
        "numberOfRecords":this.recordeperage,
    }
    this.motorService.getAlertsDetails(params)
    .subscribe((data: any):void =>{ 
      this.AlertsData = data["data"];
      this.DbConnectionFail=false;
      this.dataSource.data = data["data"];
      this.Alertlength=data["count"][0].count;
     this.SpinnerService.hide();
    },
    error =>{ 
      this.DbConnectionFail=true;
      this.SpinnerService.hide();
      console.log("Error :: " + error)}
    );
  }
  /**
   * Set the paginator and sort after the view init since this component will
   * be able to query its view for the initialized paginator and sort.
   */
  ngAfterViewInit() {
    if(this.dataSource)
       {//this.dataSource.paginator = this.paginator;
  this.dataSource.sort = this.sort;  }
  }
  getServerData(ev){
console.log(ev.length,ev.pageSize,ev.pageIndex);
this.startIndex=ev.pageIndex+1;
this.recordeperage=ev.pageSize;
this.GetAlertData();
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

  exportToExcel(name) {
    var params={
      "pageIndex":1,
      "numberOfRecords":100,
  }
    this.motorService.getAlertsDetails(params)
    .subscribe((data: any):void =>{ 
      this.AlertsData = data["data"];
      let timespan=this.datePipe.transform(new Date(), 'yyyy-MM-dd');
      let filename = 'Alerts'+timespan.toString();
      this.excelService.exportAsExcelFile(this.AlertsData, filename);
    },
    error =>{ 
      this.DbConnectionFail=true;
      console.log("Error :: " + error)}
    );

  }
}



