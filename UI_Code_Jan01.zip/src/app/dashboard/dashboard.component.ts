import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MotorService } from  '../_Services/motor.service';
import { utilityservice } from '../_Services/utility.service';
import { NgxSpinnerService } from "ngx-spinner"; 
import { conditionallyCreateMapObjectLiteral } from '@angular/compiler/src/render3/view/util';
import { getLocaleDateTimeFormat, DatePipe } from '@angular/common';
// import 'rxjs/add/operator/delay';
//import {MotorName} from  './app-routing.module'; 

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  constructor(private _router: Router,private route:ActivatedRoute,private util:utilityservice,
    private motorService:MotorService, private datePipe:DatePipe,private SpinnerService: NgxSpinnerService) { 
    this.util.displayNoSignUp=true;
    this.getDetails();
  }
  mototDetails:any;
  HomeDetails:any;
  NoOfMotors:number=0;
  greenmotors:number=0;
  AmberMotors:number=0;
  RedMotors:number=0;
  PowerConsumptionTime:string;//= '18-11-2019';
  EnergyConsumptionTime:string;//='18-11-2019';
  ActiveAlert:string='0';
  HistoricalAlert:number=0;s
  DbConnectionFail:boolean=false;
getDetails()
{
  this.SpinnerService.show();
  this.motorService.getMotorDetails()
      .subscribe((data: any):void =>
      { this.mototDetails = data;
        this.DbConnectionFail=false;
        this.util.MotorDetails=data;             
                if(this.mototDetails){
               this.NoOfMotors=this.mototDetails.length;
               for(let i=0;i<this.mototDetails.length;i++)
               {
                 if(this.mototDetails[i].motorstatus=='R'){
                 this.RedMotors++;this.mototDetails[i].motorstatus='Red';}
                 else if(this.mototDetails[i].motorstatus=='G'){
                 this.greenmotors++;this.mototDetails[i].motorstatus='Green';}
                 else if(this.mototDetails[i].motorstatus=='A'){
                 this.AmberMotors++;this.mototDetails[i].motorstatus='Orange';}
                 else{
                  this.mototDetails[i].motorstatus='Grey';
                 }
                }
                this.GetChartData(this.mototDetails);
                this.SpinnerService.hide();
              }                        
              },
              error =>{ 
                this.DbConnectionFail=true;
                this.SpinnerService.hide();
                console.log("Error :: " + error)}
              );
              
              this.motorService.getHomeDetails().subscribe((data:any):void=>{
                this.HomeDetails=data;
                this.DbConnectionFail=false;
                if(this.HomeDetails && this.HomeDetails[0].activealerts!=null){                  
                  this.ActiveAlert=this.HomeDetails[0].activealerts;
                }
              },
              error =>{ 
                this.DbConnectionFail=true;
                console.log("Error :: " + error)})
      }

  ngOnInit() {
    this.EnergyConsumptionTime=this.datePipe.transform(new Date(),'MM-dd-yyyy');
    this.PowerConsumptionTime=this.datePipe.transform(new Date(),'MM-dd-yyyy');
  }
  
  //Motor Power Consumption Chart
  public PowerConsumptionChartLabels:string[] = [];
  public PowerConsumptionChart:any[] = [{data:[]}];
  public PowerConsumptionChartType:string = 'bar';
  public PowerConsumptionChartcolours: Array < any > = [{
    backgroundColor: [ 'lightgrey', 'lightgrey','lightgrey','lightgrey','lightgrey','lightgrey'],
    borderColor: ['rgba(135,206,250,1)', 'rgba(106,90,205,1)', 'rgba(148,159,177,1)']}];
    private  PowerConsumptionChartOptions: any = {
      legend: { 
        display:false, // to hide labels
        position:'bottom' },
      scales: {
          xAxes: [{
              barPercentage: 0.5
          }],
        yAxes: [{
            ticks: {
                beginAtZero: true
            }
        }]
      }
      }

    //Motor Life Consumption chart
    public LifeConsumptionChartLabels:string[] = [];
    public LifeConsumptionChart:any[] = [{data:[],label:"Motors"}];
    public LifeConsumptionChartType:string = 'bar';
    public LifeConsumptionChartcolours: Array < any > = [{
      backgroundColor: [ 'lightgrey', 'lightgrey','lightgrey','lightgrey','lightgrey','lightgrey'],
      borderColor: ['rgba(135,206,250,1)', 'rgba(106,90,205,1)', 'rgba(148,159,177,1)']}];
      private  LifeConsumptionChartOptions: any = {
        legend: { display:false,position:'bottom' },
        scales: {
            xAxes: [{
                barPercentage: 0.5
            }],
          yAxes: [{
              ticks: {
                  beginAtZero: true
              }
          }]
        }
        }

  // events
  public PowerConsumptionChartClicked(points,e:any):void {
    
    this.util.motorName=points.active[0]._view.label.toString();
    this._router.navigate(['/MotorCondition']);
  }
  public LifeConsumptionChartClicked(points,e:any):void {
  
    this.util.motorName=points.active[0]._view.label.toString();
    this._router.navigate(['/MotorCondition']);  
    //navigate to next page
  }
 
  public chartHovered(e:any):void {
   
  }
  GetChartData(chartData){    
    //this.LifeConsumptionChartcolours[0].backgroundColor=[];
    for(let i=0;i<chartData.length;i++)
    {   
    this.LifeConsumptionChartLabels.push(chartData[i].partname);
    this.LifeConsumptionChart[0].data.push(chartData[i].effectivemotorlifeconsumption);
    this.LifeConsumptionChartcolours[0].backgroundColor.push(this.mototDetails[i].motorstatus);
    this.PowerConsumptionChartLabels.push(chartData[i].partname);
    this.PowerConsumptionChart[0].data.push(chartData[i].avgmotorloadingpercent);
    this.PowerConsumptionChartcolours[0].backgroundColor.push(this.mototDetails[i].motorstatus);
    }
  }
}
