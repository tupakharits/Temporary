const AWS = require('aws-sdk');

var awsIot = require('aws-iot-device-sdk');
var ParseData = require('./src/parser/parsedata').parseData;
const path = require('path');
const logger = require('./logger').logger;
logger.debug(__dirname);
const dotenv_1 = require("dotenv");
const path_1 = require("path");
dotenv_1.config({ path: path_1.resolve(__dirname, "configs.env") });
async = require('asyncawait/async');
await = require('asyncawait/await');

let hostNameValue;
let AccessKeyVal;
let SecretKeyVal;

getDEc();
async function getDEc(){
  try {

    let hostname = await decrypt(process.env.HOST_NAME);
    hostNameValue = hostname.Plaintext.toString();

    let AccessKEY = await decrypt(process.env.ACCESSKEYID_NAME);
    AccessKeyVal = AccessKEY.Plaintext.toString();


    let SecretKey = await decrypt(process.env.SECRETKEY_NAME);
    SecretKeyVal = SecretKey.Plaintext.toString();

    var device = awsIot.device({
      keyPath: path.resolve(__dirname, 'certs',process.env.KEY_FILE_NAME),
      certPath: path.resolve(__dirname, 'certs',process.env.CERT_FILE_NAME),
      caPath: path.resolve(__dirname, 'certs',process.env.CA_FILE_NAME),
      debug: true,
      host: hostNameValue,
      clientId: 'TestThing',
  accessKeyId: AccessKeyVal,
  secretKey: SecretKeyVal,
    protocol: 'wss'
  });
  
  device.on('connect', () => {
      logger.debug('IOT Core connected');
      //console.log('connected to IOT core');
      device.subscribe('CBM');
      //thingShadows.publish('TestTopic', jsonPacket);
  });
  
  device.on('message', async (topic,payload)=> {
      if(topic === 'CBM') {
        try {
          //console.log('message', topic, payload.toString());
          await ParseData.parserLogic(JSON.parse(payload.toString()));
        } catch(error) {
          logger.error(error);
        }
      }
  });
  
  device.on('error',(error) => {
    logger.error("IOT Core Connection error: " + error);
    process.exit(0);
  });
  
     } catch (error) {
    
  }
    
}

    async function decrypt(source) {
      var kms = new AWS.KMS({
//        accessKeyId: 'AKIAQ4BG2TDI2QTS4UUF',
  //        secretAccessKey: '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',
        region: 'eu-west-1',
      });
    
      params = {
      CiphertextBlob: Buffer.from(source, 'base64')
      }
      
        return new Promise((resolve,reject)=> {
        kms.decrypt(params,(err, data) => {
            if(err) {
                return reject(err);
            }
            return resolve(data);
        });    
    
    });
    }

