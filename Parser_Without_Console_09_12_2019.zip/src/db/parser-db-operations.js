var DB = require('./db-provider');
const logger = require('../../logger').logger;

class ParserDbOpeartions {
    async insertPacket(params) {
        try{
            let queryText = `INSERT INTO Packet(Version, EntityId, LocationId, PlantId, DepartmentId, MachineId, PacketTimeStamp, InsertedTimeStamp) 
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`;
            let dbResult
            dbResult = await DB.DbProvider.query(queryText,params);
            return dbResult.rows[0].id;
        }catch(error) {
            logger.error(error);
            throw error;
        }
    }

    async insertPacketData(params) {
        try{
            let queryText = `INSERT INTO PacketData(MachineId, ModuleTypeId, ModuleId, PartId, ParameterId, Value, Quality, ParameterTimeStamp, PacketId) 
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id`;
            let dbResult
            dbResult = await DB.DbProvider.query(queryText,params);
            return dbResult.rows[0].id;
        }catch(error) {
            logger.error(error);
            throw error;
        }
    }
}

exports.ParserDbOpeartions = ParserDbOpeartions;

