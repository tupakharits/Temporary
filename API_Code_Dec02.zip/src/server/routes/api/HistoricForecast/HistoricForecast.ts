import express, { Request, Response } from "express";
import { HistoricForecastOperations } from "../../../db/HistoricForecast";
import logger from '../../../../logger';
import moment from "moment";

const routes = express.Router();
routes.post("/", async (req: Request, resp: Response) => {
  try {
    var PartName = req.body["PartName"]
    var Parameter = req.body["Parameter"]

    var dataToSend:{[index:string]:{}} = {};
    var historicData:{[index:string]:{}} = {};
    var forecastData:{[index:string]:{}} = {};
    
    const HistoricQueryText = "SELECT StartDateTime as startdatetime,SummaryValue as Value,LowWarning as MinThreshold,LowCritical as MinCritical,HighWarning as MaxThreshold,HighCritical as MaxCritical FROM ParameterSummarydaily where parameterid =(select id from parameter where name like '%"+Parameter+"%') and partid =(select id from part where name like '%"+PartName+"%') and StartDateTime <= now();"
    var params: any = [];
    //params.push(1);
    var dbResult = await new HistoricForecastOperations().GetHistoricForecastData(
        HistoricQueryText,
      params
    );
    

    for (var index = 0;index < dbResult.length;index++)
    {
        var dateFromDB = moment(dbResult[index]["startdatetime"]).format('YYYY-MM-DD');
        var timeFromDB = moment(dbResult[index]["startdatetime"]).format('HH:mm');
        dbResult[index]['DateTime'] = dateFromDB + " "+timeFromDB;
    }


    historicData = dbResult;


   


    const ForecastQueryText = "SELECT StartDateTime as startdatetime,SummaryValue as Value FROM ParameterForecastData where parameterid =(select id from parameter where name like '%"+Parameter+"%') and partid =(select id from part where name like '%"+PartName+"%') and StartDateTime > now();"
    console.log(ForecastQueryText)
    
    dbResult = await new HistoricForecastOperations().GetHistoricForecastData(
        ForecastQueryText,
      params
    );
    


    for (var index = 0;index < dbResult.length;index++)
    {
        var dateFromDB = moment(dbResult[index]["startdatetime"]).format('YYYY-MM-DD');
        var timeFromDB = moment(dbResult[index]["startdatetime"]).format('HH:mm');
        dbResult[index]['DateTime'] = dateFromDB + " "+timeFromDB;
    }


    forecastData = dbResult;


    dataToSend["HistoricData"] = historicData
    dataToSend["ForecastData"] = forecastData
    


    

    




    //once integrated with postgress plz uncomment above line and remove below line and remove JSON.parse function.
    //const dbResult=`[{"id":1,"partid":1,"partname":"X-Motor","motorstatus":"R","avgmotorloadingpercent":"85.00","effectivemotorlifeconsumption":"2555.00"},{"id":2,"partid":2,"partname":"Z-Motor","motorstatus":"G","avgmotorloadingpercent":"30.00","effectivemotorlifeconsumption":"2920.00"},{"id":3,"partid":3,"partname":"C-Motor","motorstatus":"G","avgmotorloadingpercent":"45.00","effectivemotorlifeconsumption":"4380.00"},{"id":4,"partid":4,"partname":"C2-Motor","motorstatus":"A","avgmotorloadingpercent":"5.00","effectivemotorlifeconsumption":"5475.00"},{"id":5,"partid":5,"partname":"LP1-Motor","motorstatus":"G","avgmotorloadingpercent":"3.00","effectivemotorlifeconsumption":"730.00"},{"id":6,"partid":6,"partname":"LP2-Motor","motorstatus":"G","avgmotorloadingpercent":"120.00","effectivemotorlifeconsumption":"1095.00"}]`;
    
    resp.json(dataToSend);
  } catch (error) {
    logger.error("error in parts get function: " + error);
    resp.status(500).json({ message: error.message ? error.message : "" });
  }
});

export default routes;
