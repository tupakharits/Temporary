import CreateApp from './app';
import logger from '../logger';

import express from 'express';




console.log(process.env.PORT);
const port = process.env.PORT || 3000;

const app = CreateApp();

app.listen(port, () => {
    logger.debug(`server running on port ${port}`);
    console.log(`server running on port ${port}`)
});