import {Pool} from 'pg';
import logger from '../../logger';
import {config} from 'dotenv';
import { resolve } from "path"

config({path: resolve(__dirname, "../../../configs.env")});

console.log(process.env.DB_URL);

const DATABASE_URL=process.env.DB_URL;
const pool = new Pool({
    
    
    connectionString: DATABASE_URL,
    connectionTimeoutMillis:36000
});

pool.connect((err, client, done) => {    
    if (err) {       
        logger.debug('error in db connection:' + err);
        done();
    }
    else {
        logger.debug('connected to db');   
    }     
    done();
});

pool.on('error', (error,client) => {
    console.log('Unexpected error on idle client: ' + error);
    logger.error('Unexpected error on idle client: ' + error); 
    process.exit(-1);   
});

export default {
    query(queryText: string, params?: any[]) {
        return new Promise((resolve,reject) => {
            pool.query(queryText,params)
            .then((dbResult) => resolve(dbResult))
            .catch((dbError) => reject(dbError))
        });    
    }    
}