import { Component, OnInit, Inject } from '@angular/core';
import { ChartDataSets, ChartOptions } from 'chart.js';
import { Color, Label } from 'ng2-charts';
import { ActivatedRoute, Router } from '@angular/router';
import { MotorService } from  '../_Services/motor.service';
import { utilityservice } from '../_Services/utility.service';

import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';

import { debug } from 'util';
import { DatePipe } from '@angular/common';
//import { MotorName } from '../MotorName';
import { NgxSpinnerService } from 'ngx-spinner';


export interface DialogData {
  customDate: Date;
  customTimemodel: any[];//=[{hour:12,minute:00}];
  customDuration:string;
}

@Component({
  selector: 'app-motor-condition',
  templateUrl: './motor-condition.component.html',
  styleUrls: ['./motor-condition.component.scss']
})

export class MotorConditionComponent implements OnInit {

  customDate:Date;
  //customTime:string;
  DurationTime:string='hour';
  customTimemodel:any;// = [{hour: 13, minute: 30}];
 
  public lineChartData: any[] = [
    { data: [], label: 'Power ',fill: false },
    { data: [], label: 'Max Warning',fill: false, hidden:true },
    { data: [], label: 'Max Critical',fill: false, hidden:true },
     { data: [], label: 'Torque',fill: false, hidden:true },
     { data: [], label: 'Position',fill: false, hidden:true }
  ];
  public motordata:any;
  public motorDetails:any[];
  public graphData:any[];
  public motorConditionDetails:any;
  public MotorMake:string='';
  public MotorModel:string='';
  public AssetID:string='';
  public Location:string='';
  public RatedCurrent:string='';
  public Voltage:string='';
  public RatedPower:string='';
  public PowerFactor:string='';
  public  MaxRPM:string='';
  public MinRPM:string='';
  public DateTime_Selected:string=new Date().toString();
  public Duration:string='hour';
  public parameter:string='MotorPower';
  public graphwidth:number=1000;
  public ShowSpinner=true;

  DbConnectionFail=false;

  LineChartInit(){
    
    this.lineChartOptions = {
      legend: { position:'bottom' },
      tooltips: {
        enabled: true,
        mode: 'index',
        position: 'nearest',
       // custom: customTooltips,
       callbacks: {
        labelColor: function(tooltipItem, chart) {
            return {
                borderColor: 'rgb(255, 0, 0)',
                backgroundColor: 'rgb(255, 0, 0)'
            };
        },
        label:function(tooltipItem, chart){ 
          var power='';
          power=chart.datasets[tooltipItem.datasetIndex].label+" : "+tooltipItem.yLabel;          
          return (power);
        },
        footer:function(tooltipItem, chart) {
          var torque=chart.datasets[3].label+" : "+chart.datasets[3].data[tooltipItem[0].index];
          var position=chart.datasets[4].label+" : "+chart.datasets[4].data[tooltipItem[0].index];
          return [torque, position];
          },
        labelTextColor: function(tooltipItem, chart) {
            return '#FFFFFF';
        }
    }
      },
      scales: {
        yAxes: [{
            ticks: {
                beginAtZero: true
            }
        }],
        xAxes: [{
          ticks:{beginAtZero:true}
        }]
      }     
  }
}
  public Chart_selected:string='MotorPower';
  public lineChartLabels: Label[] = [];//'12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00'];
  // public lineChartOptions: (ChartOptions & { annotation: any }) = {
  //   responsive: true,
  // };
  public lineChartColors: Color[] = [
    {borderColor: 'blue'},
    {borderColor: 'Orange',},
    {borderColor: 'red',},
    {borderColor: 'Orange',},
    {borderColor: 'red',},
  ];
  public  lineChartOptions: any = {
       }
  public lineChartLegend = true;
  public lineChartType = 'line';
  public lineChartPlugins = [];
  public MotorName:string='Xmotor';
  public motorstatus:string='Green';

  constructor(private route:ActivatedRoute, private router:Router,private MotorService:MotorService,
    private util:utilityservice, public dialog: MatDialog,private datePipe:DatePipe,private SpinnerService: NgxSpinnerService) {
    if(route.snapshot.data["p1"]!=undefined)
        this.MotorName=route.snapshot.data['p1'];
    this.util.displayNoSignUp=true;
    this.MotorName=this.util.motorName;
    this.motorDetails=this.util.MotorDetails;
    this.DateTime_Selected=this.datePipe.transform(new Date(),'MM/dd/yyyy HH:mm');
}

  ngOnInit() {
    
    this.showConfig();
    this.LineChartInit();
  }

  showConfig() {  

    this.MotorService.getMotorDetails().subscribe((data) =>
     {
      this.motorDetails=data;
      this.DbConnectionFail=false;
      this.DbConnectionFail=false;
      
      this.util.MotorDetails=data;
      for(let i=0;i<this.motorDetails.length;i++)
      {
        if(this.motorDetails[i].motorstatus=='R')
        this.motorDetails[i].motorstatus='Red';
        else if(this.motorDetails[i].motorstatus=='G')
        this.motorDetails[i].motorstatus='Green';
        else if(this.motorDetails[i].motorstatus=='A')
        this.motorDetails[i].motorstatus='Orange';
        else
        this.motorDetails[i].motorstatus='Grey';
        if(this.MotorName==this.motorDetails[i].partname)
        this.motorstatus=this.motorDetails[i].motorstatus;
       }
     
    },error =>{ 
      this.DbConnectionFail=true;
      console.log("Error :: " + error)});
      this.LoadGraphDetails();
  }

  LoadGraphDetails(){       
    this.SpinnerService.show();
 var cetTime = new Date(this.DateTime_Selected).toLocaleString("en-US", {timeZone: "Europe/Paris"});
 cetTime=this.datePipe.transform(new Date(cetTime),'MM-dd-yyyy HH:mm');

    var params = 
    {
      PartName: this.MotorName,
      Parameter:this.Chart_selected,//this.Chart_selected,
      DateTime: cetTime,  //this.DateTime_Selected,
      Duration: this.Duration
    }
    this.MotorService.getMotorFactorDetails(params).subscribe((data) => {
     
      this.motorConditionDetails=data;
      
      this.DbConnectionFail=false;
      if(this.motorConditionDetails){
      this.MotorMake=this.motorConditionDetails.MotorSnapShot.Make;
      this.MotorModel=this.motorConditionDetails.MotorSnapShot.Model;
      this.AssetID=this.motorConditionDetails.MotorSnapShot["Asset Id"];
      this.Location=this.motorConditionDetails.MotorSnapShot.Location;
      this.RatedCurrent=this.motorConditionDetails.MotorSnapShot.Current;
      this.Voltage=this.motorConditionDetails.MotorSnapShot.Voltage;
      this.RatedPower=this.motorConditionDetails.MotorSnapShot.Power;
      this.PowerFactor=this.motorConditionDetails.MotorSnapShot["Power Factor"];
      this.MaxRPM=this.motorConditionDetails.MotorSnapShot["Max RPM"];
      this.MinRPM=this.motorConditionDetails.MotorSnapShot["Min RPM"];
      this.graphData=this.motorConditionDetails.GraphData;
      this.ClearChartData();
      this.LoadChart(this.graphData);
      this.SpinnerService.hide();
}
      //this.motorDetails=data;
      //this.util.MotorDetails=data;
    },error =>{ 
      this.DbConnectionFail=true;
      this.SpinnerService.hide();
      console.log("Error :: " + error)});
  }
public LoadChart(graphdata){
    for(let i=0;i<graphdata.length;i++){
      if(this.graphData[i].DateTime!=null){
    this.lineChartData[0].data.push(this.graphData[i].summaryvalue);//For Power line
    this.lineChartData[1].data.push(this.graphData[i].maxwarning); //For max threshold
    this.lineChartData[2].data.push(this.graphData[i].maxcritical);  //For Warning
    this.lineChartData[3].data.push(this.graphData[i].torque); // min threshold
    this.lineChartData[4].data.push(this.graphData[i].actualposition); // min warning
    this.lineChartLabels.push(this.graphData[i].DateTime);
      }
  }
}
public ClearChartData(){
  this.lineChartLabels=[];
  for(let i=0;i<this.lineChartData.length;i++)
  this.lineChartData[i].data=[];
}
  public ChangeMotor(Motor_name){
        this.MotorName=Motor_name;
        this.util.motorName=Motor_name;
        //Call change chart
       // this.changeChart(this.Chart_selected);
        this.LoadGraphDetails();
  }
  public ChangeDuration(Duration){
     this.Duration=Duration;
     if(Duration=='hour'){this.graphwidth=1100;}
     else if(Duration=='day'){this.graphwidth=2000;}
     else if(Duration=='month'){this.graphwidth=5000;}
     this.DateTime_Selected=this.datePipe.transform(new Date(),'MM-dd-yyyy HH:mm');
     
     this.LoadGraphDetails();
  }
  public changeChart(Chart_data){
    if(Chart_data.index==0) //Power
    this.Chart_selected='MotorPower';
    else if(Chart_data.index==1)//Current
    this.Chart_selected='MotorCurrent';
    else if(Chart_data.index==2)//Motor Loading
    this.Chart_selected='MotorLoadingPercentage';

    this.DateTime_Selected=this.datePipe.transform(new Date(),'MM-dd-yyyy HH:mm');
    this.lineChartData[0].label=Chart_data.tab.textLabel;
    this.LoadGraphDetails();
    
  }

  GetChartData(chartData){
    for(let i=0;i<chartData.length;i++)
    {
    this.lineChartLabels.push(chartData[i].partname);
    this.lineChartData[0].data.push(chartData[i].effectivemotorlifeconsumption);
    this.lineChartData[0].data.push(chartData[i].effectivemotorlifeconsumption);
    //For Min Critical
    this.lineChartData[1].data.push(chartData[i].minCritical);
    this.lineChartData[1].data.push(chartData[i].minCritical);
    //For Min Threshold
    this.lineChartData[1].data.push(chartData[i].minThreshold);
    this.lineChartData[1].data.push(chartData[i].minThreshold);
    //For Max Critical
    this.lineChartData[1].data.push(chartData[i].maxCritical);
    this.lineChartData[1].data.push(chartData[i].maxCritical);
    //For Max Threshold
    this.lineChartData[1].data.push(chartData[i].maxThreshold);
    this.lineChartData[1].data.push(chartData[i].maxThreshold);
    
    }
  }

  public Forecast(){
    this.router.navigate(['/forecast']);
  }

  openDialog(): void {
    const dialogRef = this.dialog.open(MotorConditionCustomPopup, {
      //width: '350px',
      data: {customDate: this.customDate,customTimemodel:this.customTimemodel},//, DurationTime:this.DurationTime},
      disableClose: true
    },);

    dialogRef.afterClosed().subscribe(result => {
    
      if(result){
      this.customDate =result.customDate;
      if(result.customTimemodel==null){
        let hr=this.datePipe.transform(this.customDate,'HH');
        let mn=this.datePipe.transform(this.customDate,'mm');
        this.customTimemodel= {hour: hr, minute: mn, second: 0};
       // this.customTimemodel= {hour: 12, minute: 0, second: 0};
      //this.customTimemodel["hour"]='12';this.customTimemodel["minute"]='00';
    }
      else
      this.customTimemodel = result.customTimemodel;
      
      this.DateTime_Selected=this.datePipe.transform(this.customDate,'MM-dd-yyyy')+' '+
      //this.customTimemodel[0].hour.toString()+":"+this.customTimemodel[0].minute.toString();
       this.customTimemodel["hour"].toString()+":"+this.customTimemodel["minute"].toString();
      this.Duration=result.customDuration;
      
      this.LoadGraphDetails();
      }
      else 
      {

      }
    });    
  }
 
}


  @Component({
    selector: 'motor-condition-custom-popup',
    templateUrl: './motor-condition-custom-popup.component.html',
    styleUrls: ['./motor-condition.component.scss']
  })
  export class MotorConditionCustomPopup {
    meridian = true;
    customTime = {hour: 13, minute: 30};
    constructor(public dialogRef: MatDialogRef<MotorConditionCustomPopup>,
      @Inject(MAT_DIALOG_DATA) public data: DialogData) {
        data.customDate=new Date();
data.customDuration='hour';
//data.customTime=[{hour: 13, minute: 30}];
      }
  
    onNoClick(): void {
      this.dialogRef.close();
    }
    onOKClick(): void{

    }
  
  }


