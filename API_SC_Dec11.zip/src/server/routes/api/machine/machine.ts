import express, { Request, Response } from "express";
import { MachineDBOperations } from "../../../db/machine";
import logger from '../../../../logger';

const routes = express.Router();
routes.get("/", async (req: Request, resp: Response) => {
  try {
    const queryText = "Select * from machinesummaryinfo";
    let params: any = [];
    const dbResult = await new MachineDBOperations().queryMachineDetails(
      queryText,
      params
    );
    //once integrated with postgress plz uncomment above line and remove below line and remove JSON.parse function.
    //const dbResult = `[{"id":1,"machineid":1,"machinename":"Schuler Automation","plantid":1,"plantname":"Leapcell","locationid":1,"locationname":"Rivalta","overallstatus":"G","numberofmotors":6,"activealerts":13}]`;
    resp.send(dbResult);
  } catch (error) {
    logger.error("error in machine get function: " + error);
    resp.status(500).json({ message: error.message ? error.message : "" });
  }
});

export default routes;
