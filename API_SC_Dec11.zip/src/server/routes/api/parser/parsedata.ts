import { Parser } from "../../../db/parser";
import { Path } from "aws-sdk/clients/codecommit";
import paths from 'path';
import fs from 'fs';




const logPath = paths.join(__dirname, '..', '..','..', '..','log','ParserLog.txt')




function WriteDataToFile(filePath:Path,fileContent:String)
{
     fs.appendFile(filePath
                   , "\n"+fileContent+"\n", function (err) {
  if (err) 
    {
        console.log(err);
    }
  else{
  console.log('Saved!');
  }
});
}

function WriteToFile(filePath:Path,Content:String)
{


    
 fs.stat(filePath, (exists) => {
    if (exists == null) {
        WriteDataToFile(filePath,Content)
    } else if (exists.code === 'ENOENT') {
        var createStream = fs.createWriteStream(filePath);
        createStream.end();
        WriteDataToFile(filePath,Content)
        return false;
    }    
    });
}

export default {


  
  async parserLogic(req: any) {

    
    const reqPayload = req.body;

  
    WriteToFile(logPath,JSON.stringify(req.body))

    for (let message of reqPayload.messages) {
      let payload = [];
      let packetHeader: string;
      let splittedPacketDetails: any = [];
      let packetVersion: number;
      let entityId: number;
      let locationId: number;
      let plantId: number;
      let departmentId: number;
      let machineId: number = 0;
      let headerTimeStamp: string;
      let currentTimeStamp: string;
      var packetId: number = 0;
      payload = message.payload.Values;
      try {
        packetHeader = message.payload.PacketHeader.toString();
        splittedPacketDetails = packetHeader.split(".");

        if (splittedPacketDetails.length !== 6) {
          throw new Error("Header has missing details");
        }

        packetVersion = +splittedPacketDetails[0];
        entityId = +splittedPacketDetails[1];
        locationId = +splittedPacketDetails[2];
        plantId = +splittedPacketDetails[3];
        departmentId = +splittedPacketDetails[4];
        machineId = +splittedPacketDetails[5];
        //headerTimeStamp = new Date(reqPayload.payload.Timestamp);
        headerTimeStamp = new Date(message.payload.Timestamp).toISOString();
        currentTimeStamp = new Date(Date.now()).toISOString();
        packetId = await new Parser().insertPacket([
          packetVersion,
          entityId,
          locationId,
          plantId,
          departmentId,
          machineId,
          headerTimeStamp,
          currentTimeStamp
        ]);
      } catch (error) {
        console.log(error);
      }

      for (let item of payload) {
        try {
          let machineParameter: string;
          let splittedMachineParameters: any = [];
          let moduleTypeId: number;
          let moduleId: number;
          let partId: number;
          let parameterId: number;
          let parameterTimeStamp: string;

          machineParameter = item.id.toString();
          splittedMachineParameters = machineParameter.split(".");
          if (splittedMachineParameters.length !== 5) {
            throw Error;
          }

          moduleTypeId = +splittedMachineParameters[1];
          moduleId = +splittedMachineParameters[2];
          partId = +splittedMachineParameters[3];
          parameterId = +splittedMachineParameters[4];

          let value = item.v;
          let quality = item.q === true ? 1 : 0;
          parameterTimeStamp = new Date(item.t).toISOString();

          const packetDataId = await new Parser().insertPacketData([
            machineId,
            moduleTypeId,
            moduleId,
            partId,
            parameterId,
            value,
            quality,
            parameterTimeStamp,
            packetId
          ]);
        } catch (error) {}
      }
    }
  }
};
