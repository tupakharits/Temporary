import express, { Request, Response } from "express";
import logger from '../../../../logger';
import { MotorConditionOperations } from "../../../db/MotorCondition";
import moment from "moment";

const routes = express.Router();
routes.post("/", async (req: Request, resp: Response) => {
  try {
    var dataToSend:{[index:string]:{}}={};
    var MotorSnapShot:{[index:string]:string} = {};
    var PartName = req.body["PartName"]
    var Parameter = req.body["Parameter"]
    var DateTime = req.body["DateTime"]
    var Duration = req.body["Duration"]
    var GraphData:[{}] = [{}];
    
    const ConfigQueryText = "select ItemKey,ItemValue from PartConfig where partid = (select id from part where name like '%"+PartName+"%') union  select 'CurrentStatus' as ItemKey,MotorStatus as ItemValue from PartSummaryInfo where partid = (select id from part where name Like '%"+PartName+"%')";
    let params: any = [];
    var dbResult;
    //params.push(1);
    var dbResult = await new MotorConditionOperations().GetMotorConfigData(
      ConfigQueryText,
      params
    );

    for (var index = 0;index < dbResult.length;index++)
    {
        
        MotorSnapShot[dbResult[index]["itemkey"]] = dbResult[index]["itemvalue"];
    }

    dataToSend["MotorSnapShot"] = MotorSnapShot;



    if (true)
    {
      console.log(DateTime);
      var dateTimeFromUI = moment(new Date(DateTime));
      //var addedHour = dateTimeFromUI.add(1,'hours');
      var startTime;
      var endTime ;
      var startTimeFormat;
      var endTimeFormat;
      

      startTime = moment (dateTimeFromUI).startOf(Duration);
      endTime = moment(dateTimeFromUI).endOf(Duration);
      startTimeFormat = moment(startTime).format('YYYY-MM-DD HH:mm:ss');
      endTimeFormat = moment(endTime).format('YYYY-MM-DD HH:mm:ss');
      

      console.log(dateTimeFromUI)
      //console.log(addedHour)
      console.log(endTime)

      

      var GraphQuery = "SELECT Distinct on (StartDateTime)StartDateTime ,SummaryValue ,LowWarning as MinThreshold,LowCritical as MinCritical,HighWarning as MaxWarning,HighCritical as MaxCritical,Torque, ActualPosition,DriveTemperature FROM ParameterSummary where parameterid =(select id from parameter where name like '"+Parameter+"') and partid =(select id from part where name like '"+PartName+"') and startdateTIME between '"+startTimeFormat+"' AND '"+endTimeFormat+"'"



      //var GraphQuery = "select Distinct on (startdateTime)startdateTime,torque from Sample where startdateTIME between '"+startTimeFormat+"' AND '"+endTimeFormat+"' order by startdateTime asc"
      console.log(GraphQuery)
      dbResult = await new MotorConditionOperations().GetMotorConfigData(
          GraphQuery,
          params
        );
      var initialTime:moment.Moment = moment();
      var count:number = 0;
      if (dbResult.length != 0)
      {
        initialTime = moment(new Date(dbResult[0]["startdatetime"]));
        var dateFromDB = moment(dbResult[0]["startdatetime"]).format('YYYY-MM-DD');
        var timeFromDB = moment(dbResult[0]["startdatetime"]).format('HH:mm');
        dbResult[0]['DateTime'] = dateFromDB + " "+timeFromDB;
       // dbResult[0]['Time'] = timeFromDB;
        GraphData[count] = dbResult[0];
        
        count = count + 1;
      }
      console.log("Initial:"+ moment(initialTime).format('YYYY-MM-DD HH:mm:ss'));
      var loopIndex = 1;
      var nextTime = initialTime.add(10,'minutes');
      while (nextTime.isBefore(endTime))
      {      
          for (var index = loopIndex;index<dbResult.length;index++)
          {
            var maxLimit = (nextTime.clone().startOf('minutes').add(10,'minutes').minutes() - (nextTime.clone().startOf('minutes').add(10,'minutes').minutes() % 10));
            var startOf = (nextTime.startOf('minutes').minutes() - (nextTime.startOf('minutes').minutes()%10));
           
            if (maxLimit == 0)
            {
                maxLimit = 60
            }
            
            if (nextTime.date() == moment(new Date(dbResult[index]["startdatetime"])).date() && nextTime.month() == moment(new Date(dbResult[index]["startdatetime"])).month()  && nextTime.hour() == moment(new Date(dbResult[index]["startdatetime"])).hour() && startOf <= moment(new Date(dbResult[index]["startdatetime"])).minutes() && moment(new Date(dbResult[index]["startdatetime"])).minutes() < maxLimit)
            //if ( moment(new Date(dbResult[index]["startdatetime"])).isAfter(nextTime.startOf('minutes')) || moment(new Date(dbResult[index]["startdatetime"])).minutes() ==  nextTime.startOf('minutes').minutes())
            {
                //console.log("Next Day"+nextTime.day()+"--->"+moment(new Date(dbResult[index]["startdatetime"])).day())
                //console.log("Start:"+nextTime.startOf('minutes').minutes()+"-->"+moment(new Date(dbResult[index]["startdatetime"])).minutes()+"--->End:"+maxLimit);
                console.log("Initial:"+ moment(dbResult[index]["startdatetime"]).format('YYYY-MM-DD HH:mm:ss'));
                var dateFromDB = moment(dbResult[index]["startdatetime"]).format('YYYY-MM-DD');
                var timeFromDB = moment(dbResult[index]["startdatetime"]).format('HH:mm');
                dbResult[index]['DateTime'] = dateFromDB +" "+timeFromDB;
                //dbResult[index]['Time'] = timeFromDB;
                GraphData[count] = dbResult[index];
                count = count + 1;
                
                loopIndex = index + 1;
                break;
            }
            else if (moment(new Date(dbResult[index]["startdatetime"])).isAfter(nextTime.clone().add(10,'minutes').startOf('minutes')))
            {
              break;
            }
          }
          nextTime = nextTime.add(10,'minutes');
          //console.log("Next Time End:"+moment(initialTime).format('YYYY-MM-DD HH:mm:ss'));
      }
    }
    //once integrated with postgress plz uncomment above line and remove below line and remove JSON.parse function.
    //const dbResult=`[{"id":1,"partid":1,"partname":"X-Motor","motorstatus":"R","avgmotorloadingpercent":"85.00","effectivemotorlifeconsumption":"2555.00"},{"id":2,"partid":2,"partname":"Z-Motor","motorstatus":"G","avgmotorloadingpercent":"30.00","effectivemotorlifeconsumption":"2920.00"},{"id":3,"partid":3,"partname":"C-Motor","motorstatus":"G","avgmotorloadingpercent":"45.00","effectivemotorlifeconsumption":"4380.00"},{"id":4,"partid":4,"partname":"C2-Motor","motorstatus":"A","avgmotorloadingpercent":"5.00","effectivemotorlifeconsumption":"5475.00"},{"id":5,"partid":5,"partname":"LP1-Motor","motorstatus":"G","avgmotorloadingpercent":"3.00","effectivemotorlifeconsumption":"730.00"},{"id":6,"partid":6,"partname":"LP2-Motor","motorstatus":"G","avgmotorloadingpercent":"120.00","effectivemotorlifeconsumption":"1095.00"}]`;
    //resp.send(JSON.parse(dbResult));
    dataToSend["GraphData"] = GraphData;
    resp.send(dataToSend);
  } catch (error) {
    logger.error("error in parts get function: " + error);
    resp.status(500).json({ message: error.message ? error.message : "" });
  }
});

export default routes;
