import {Pool} from 'pg';
import logger from '../../logger';
import {config} from 'dotenv';
import { resolve } from "path"
import {KMS} from 'aws-sdk';

config({path: resolve(__dirname, "../../../configs.env")});

console.log(process.env.DB_URL);

const DATABASE_URL=process.env.DB_URL;

var pool:Pool;
var kms = new KMS({
    //accessKeyId: 'AKIAQ4BG2TDI2QTS4UUF',
    //secretAccessKey: '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',
    region: 'eu-west-1',
	//region: 'us-east-2',
    httpOptions: {        
        connectTimeout: 10 * 1000, /* msec */
        timeout: 10 * 1000 /* msec */
    } 
});

function decrypt(value: string) {
    let params = {
        CiphertextBlob: Buffer.from(value, 'base64')
    }
  
    kms.decrypt(params).promise().then(data => { 
        let res = data.Plaintext !== undefined ? data.Plaintext.toString() : '';
        process.env.DB_URL=res;        
        pool = new Pool({
          connectionString: process.env.DB_URL,
          connectionTimeoutMillis:3600
       });
       
       pool.connect((err, client, done) => {    
           if (err) {       
               logger.debug('error in db connection:' + err);
               done();
           }
           else {
               logger.debug('connected to db');   
           }     
           done();
       });
       
       pool.on('error', (error,client) => {
           console.log('Unexpected error on idle client: ' + error);
           logger.error('Unexpected error on idle client: ' + error); 
           
       })
        return res; 
    }).catch(error => {
        console.log('Unexpected error on kms decryption: ' + error);
        logger.error('Unexpected error on kms decryption: ' + error);
      });
  }
  
  decrypt(process.env.DB_URL !== undefined ? process.env.DB_URL : '');


export default {
    query(queryText: string, params?: any[]) {
        return new Promise((resolve,reject) => {
            pool.query(queryText,params)
            .then((dbResult) => resolve(dbResult))
            .catch((dbError) => reject(dbError))
        });    
    }    
}