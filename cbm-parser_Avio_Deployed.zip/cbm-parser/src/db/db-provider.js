var Pool = require('pg').Pool;
const logger = require('../../logger').logger;
const path = require('path');
require('dotenv').config({path: path.resolve(__dirname, "../../configs.env")});
//console.log(process.env.DB_URL);
var AWS = require('aws-sdk');

var pool;
var kms = new AWS.KMS({
    //accessKeyId: 'AKIAQ4BG2TDI2QTS4UUF',
    //secretAccessKey: '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',
    region: 'eu-west-1'  
});

function decrypt(value) {
  params = {
      CiphertextBlob: Buffer.from(value, 'base64')
  }

  kms.decrypt(params).promise().then(data => { 
      let res = data.Plaintext.toString(); 
      //console.log(res);
      process.env.DB_URL=res;
      pool = new Pool({
        connectionString: process.env.DB_URL,
        connectionTimeoutMillis:3600
     });
     
     pool.connect((err, client, done) => {    
         if (err) {       
             logger.debug('error in db connection:' + err);
             done();
         }
         else {
             logger.debug('connected to db');   
         }     
         done();
     });
     
     pool.on('error', (error,client) => {
         //console.log('Unexpected error on idle client: ' + error);
         logger.error('Unexpected error on idle client: ' + error); 
         process.exit(-1);   
     });
      return res; 
  });
}

decrypt(process.env.DB_URL);

const DbProvider = {
    query(queryText, params) {        
        return new Promise((resolve,reject) => {
            pool.query(queryText,params)
            .then((dbResult) => resolve(dbResult))
            .catch((dbError) => reject(dbError))
        });    
    }    
}



exports.DbProvider = DbProvider;
