import {Component, OnInit, ViewChild} from '@angular/core';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import { utilityservice } from '../utility.service';

export interface PeriodicElement { 
  MotorName: string;
  MinCritical: string;
  MaxCritical: string;
  MinWarning:string;
  MaxWarning:string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {MotorName: 'X-Axis',  MinCritical: '',MaxCritical: '',MinWarning:'',MaxWarning:''},
  {MotorName: 'Z-Axis',  MinCritical: '',MaxCritical: '',MinWarning:'',MaxWarning:''},
  {MotorName: 'C-Axis',  MinCritical: '',MaxCritical: '',MinWarning:'',MaxWarning:''},
  {MotorName: 'C2-Axis',  MinCritical: '',MaxCritical: '',MinWarning:'',MaxWarning:''},
  {MotorName: 'TT1-Axis',  MinCritical: '',MaxCritical: '',MinWarning:'',MaxWarning:''},
  {MotorName: 'TT2-Axis',  MinCritical: '',MaxCritical: '',MinWarning:'',MaxWarning:''},
  
];

@Component({
  selector: 'app-configure',
  templateUrl: './configure.component.html',
  styleUrls: ['./configure.component.scss']
})

export class ConfigureComponent implements OnInit {
  displayedColumns: string[] = ['MotorName','MinCritical',  'MaxCritical', 'MinWarning','MaxWarning'];
  dataSource = new MatTableDataSource(ELEMENT_DATA);
  states: string[] = [
    'Power','Current','State'
   ];
   public name:string = '';
   fieldArray: Array<any> = [
   
  ];
  newAttribute: any = {};

  firstField = true;
  firstFieldName = 'First Item name';
  isEditItems: boolean;
  Emails:string='';
  Email:string='';
  constructor(private util:utilityservice) {
    this.util.displayNoSignUp=true;
   }
  @ViewChild(MatSort, {static: true}) sort: MatSort;

  ngOnInit() {
    this.dataSource.sort = this.sort;
  }
  addFieldValue(index) {
    debugger;
//this.Emails=this.Emails+';'+fieldArray[index];
    if (this.fieldArray.length <= 100) {
      this.fieldArray.push(this.newAttribute);
      this.newAttribute = {};
    } else {

    }
  }

  deleteFieldValue(index) {
    this.fieldArray.splice(index, 1);
  }

  onEditCloseItems() {
    this.isEditItems = !this.isEditItems;
  }


}
