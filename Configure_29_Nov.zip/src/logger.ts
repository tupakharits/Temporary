import {createLogger, format, transports} from 'winston';
import DailyRotateFile  from 'winston-daily-rotate-file';
import fs from 'fs';
import path from 'path';

const logDir = 'log';
console.log(__dirname);

// Create the log directory if it does not exist
if (!fs.existsSync(path.resolve(__dirname, logDir))) {
    fs.mkdirSync(path.resolve(__dirname, logDir));
}

const dailyRotateFileTransport = new DailyRotateFile({
    filename: `${path.resolve(__dirname, logDir)}/%DATE%-logError.log`,
    datePattern: 'YYYY-MM-DD-HH'
});



const logger = createLogger({
    level: 'debug',
    format: format.combine(
        format.timestamp({
          format: 'YYYY-MM-DD HH:mm:ss'
        }),
        format.printf(info => `${info.timestamp} ${info.level}: ${info.message}`)
    ),
    transports: [
        new transports.Console({
          level: 'info',
          format: format.combine(
            format.colorize(),
            format.printf(
              info => `${info.timestamp} ${info.level}: ${info.message}`
            )
          )
        }),
        dailyRotateFileTransport
    ]
});

export default logger;


