import express, { Request, Response } from "express";
import { ModuleDBOperations } from "../../../db/module";
import logger from '../../../../logger';

const routes = express.Router();
routes.get("/", async (req: Request, resp: Response) => {
  try {
    //console.log("Inside module");
    const queryText = "Select * from modulesummaryinfo";
    let params: any = [];
    const dbResult = await new ModuleDBOperations().queryModuleDetails(
      queryText,
      params
    );
    //once integrated with postgress plz uncomment above line and remove below line and remove JSON.parse function.
    //const dbResult = `[{"id":1,"moduleid":1,"modulename":"Motor","numberofmotors":6,"numberofmotorsgreen":4,"numberofmotorsamber":1,"numberofmotorsred":1,"activealerts":4,"historicalalerts":15}]`;
    resp.send(dbResult);
  } catch (error) {
    logger.error("error in module get function: " + error);
    resp.status(500).json({ message: error.message ? error.message : "" });
  }
});

export default routes;
