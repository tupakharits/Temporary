import {db} from "./db-provider";

export class MotorConditionOperations {
    async GetMotorConfigData(queryText: string, params?: [])
    {
        let dbResult: any;
        dbResult = await db.query(queryText, params);
        return dbResult.rows;
    }

    async GetMotorConditions(queryText: string, params?: [])
    {
        let dbResult:any;
        dbResult = await db.query(queryText,params);
        return dbResult.rows;
    }
}