import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

import { AuthenticationService } from '../Services/Authentication.service';
import { map, catchError } from 'rxjs/operators';
import { Observable, of } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {
    constructor(
        private router: Router,
        private authenticationService: AuthenticationService
    ) { }

    Data: any = [];

    canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable <boolean> {
        return this.authenticationService.isLoggedIn().pipe(map(e => {
            this.Data = e;
            if(this.Data.success) {
                return true;
            } else {
                this.router.navigate(['/']);
            }
        }), catchError((err) => {
            this.router.navigate(['/']);
            return of(false);
        }));
    }
}