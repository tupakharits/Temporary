import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap, map } from 'rxjs/operators';
import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
  })

  export class MotorService {
      constructor(private httpClient: HttpClient) {}

      getAll(): Observable<any[]> {
        return this.httpClient.get('assets/MotorDetails.json')
        .pipe(map((data: any) => data));
      }

      getHomeDetails(): Observable<any[]> {
        return this.httpClient.get('assets/HomePAge.json')
        .pipe(map((data: any) => data));
        // return this.httpClient.get('http://my-alb-1885598496.us-east-2.elb.amazonaws.com:83/api/v1/machine')
        // .pipe(map((data: any) => data));
      }
      getMotorDetails(): Observable<any[]> {
        // return this.httpClient.get('http://localhost:4000/api/v1/parts/')
        // .pipe(map((data: any) => data));
         return this.httpClient.get('http://my-alb-1885598496.us-east-2.elb.amazonaws.com:83/api/v1/parts/')
         .pipe(map((data: any) => data));
        // return this.httpClient.get('assets/Dashboarddetails.json')
        // .pipe(map((data: any) => data));
      }
  }




// import { Injectable } from '@angular/core';
// import { HttpClient } from '@angular/common/http';


// @Injectable({
//   providedIn: 'root'
// })
// export class MotorService {
//   public configUrl:string;
//   constructor(private http: HttpClient) {     
//     this.configUrl = 'assets/MotorDetails.json';
//   }

//   public data:any;
//   getConfig() {
//     this.data=this.http.get('http://localhost:4000/api/v1/users/2');
//     return this.http.get('http://localhost:4000/api/v1/users/2');
//     //return this.http.get('assets/test.json')
//   }
// }
