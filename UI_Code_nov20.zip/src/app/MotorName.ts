export class MotorName {
    Name: string;
}
