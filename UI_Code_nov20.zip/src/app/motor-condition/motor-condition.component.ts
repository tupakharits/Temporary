import { Component, OnInit } from '@angular/core';
import { ChartDataSets, ChartOptions } from 'chart.js';
import { Color, Label } from 'ng2-charts';
import { ActivatedRoute, Router } from '@angular/router';
import { MotorService } from  '../motor.service';
import { utilityservice } from '../utility.service';

@Component({
  selector: 'app-motor-condition',
  templateUrl: './motor-condition.component.html',
  styleUrls: ['./motor-condition.component.scss']
})

export class MotorConditionComponent implements OnInit {
 
  public lineChartData: ChartDataSets[] = [
    { data: [45, 56, 80, 81, 56, 55, 40], label: 'Power ',fill: false },
    { data: [85, 85, 85, 85, 85,85, 85], label: 'Threshold',fill: false },
    { data: [100, 100,100,100,100,100,100], label: 'Warning',fill: false },
    { data: [20, 20,20,20,20,20,20], label: 'Min Threshold',fill: false },
    { data: [10, 10,10,10,10,10,10], label: 'Min Warning',fill: false }
  ];
  
  public motordata:any;
  public motorDetails:any[];
  LineChartInit(customTooltips){
    
    this.lineChartOptions = {
      legend: { position:'bottom' },
      tooltips: {
        enabled: true,
        mode: 'index',
        position: 'nearest',
        custom: customTooltips,
      },
      scales: {
        yAxes: [{
            ticks: {
                beginAtZero: true
            }
        }]
      }     
  }
}
  public Chart_selected:string='Power';
  public lineChartLabels: Label[] = ['12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00'];
  // public lineChartOptions: (ChartOptions & { annotation: any }) = {
  //   responsive: true,
  // };
  public lineChartColors: Color[] = [
    {borderColor: 'blue'},
    {borderColor: 'Orange',},
    {borderColor: 'red',},
    {borderColor: 'Orange',},
    {borderColor: 'red',},
  ];
  public  lineChartOptions: any = {
    // legend: { position:'bottom' },
    // scales: {
    //   xAxes:[{
    //     type: 'linear'
    //   }],
    //   yAxes: [{
    //       ticks: {
    //           beginAtZero: true
    //       }
    //   }],
    //   showtooltips:true,
    //   tooltipEvents: ["mousemove", "touchstart", "touchmove"],
    //   tooltips: {
    //     enabled: true,
    //     mode: 'index',
    //     position: 'nearest'
        //custom: customTooltips,
     // },
   // }
    }
  public lineChartLegend = true;
  public lineChartType = 'line';
  public lineChartPlugins = [];
  public MotorName:string='Xmotor';

  constructor(private route:ActivatedRoute, private router:Router,private MotorService:MotorService,private util:utilityservice) {
    //debugger;
    //console.log(route.snapshot.data['p1']);
    if(route.snapshot.data["p1"]!=undefined)
        this.MotorName=route.snapshot.data['p1'];
    this.util.displayNoSignUp=true;
    this.MotorName=this.util.motorName;
    this.motorDetails=this.util.MotorDetails;
    //console.log(this.motorDetails);
}

  ngOnInit() {
    const customTooltips = function(tooltip) {
      // Tooltip Element
      let tooltipEl = document.getElementById('chartjs-tooltip');
      if (!tooltipEl) {
        tooltipEl = document.createElement('div');
        tooltipEl.id = 'chartjs-tooltip';
        tooltipEl.innerHTML = '<table></table>';
        this._chart.canvas.parentNode.appendChild(tooltipEl);
      }
      // Hide if no tooltip
      if (tooltip.opacity === 0) {
        tooltipEl.style.opacity = 0 as any;
        return;
      }
      // Set caret Position
      tooltipEl.classList.remove('above', 'below', 'no-transform');
      if (tooltip.yAlign) {
        tooltipEl.classList.add(tooltip.yAlign);
      } else {
        tooltipEl.classList.add('no-transform');
      }
      function getBody(bodyItem) {
        return bodyItem.lines;
      }
      // Set Text
      //debugger;
      if (tooltip.body) {
        
        const titleLines = tooltip.title || [];
        //const bodyLines = tooltip.body.map(getBody);
        let innerHtml = '<thead>';
        const bodyLines=[['power'],['current']];
        //console.log(titleLines);
        //console.log(bodyLines);
        titleLines.forEach(function(title) {
          innerHtml += '<tr><th>' + title + '</th></tr>';
        });
        innerHtml += '</thead><tbody>';
        bodyLines.forEach(function(body, i) {
          const colors = tooltip.labelColors[i];
          let style = 'background:' + colors.backgroundColor;
          style += '; border-color:' + colors.borderColor;
          style += '; border-width: 2px';
          const span = '<span class="chartjs-tooltip-key" style="' +
          style +
          '"></span>';
          innerHtml += '<tr><td>' + span + body+'Alekhya'+ '</td></tr>';
        });
        innerHtml += '</tbody>';
        //console.log(innerHtml);
        const tableRoot = tooltipEl.querySelector('table');
        tableRoot.innerHTML = innerHtml;
        console.log(tableRoot.innerHTML);
      }
      const positionY = this._chart.canvas.offsetTop;
      const positionX = this._chart.canvas.offsetLeft;
      // Display, position, and set styles for font
      tooltipEl.style.opacity = 1 as any;
      tooltipEl.style.left = positionX + tooltip.caretX + 'px';
      tooltipEl.style.top = positionY + tooltip.caretY + 'px';
      tooltipEl.style.fontFamily = tooltip._bodyFontFamily;
      tooltipEl.style.fontSize = tooltip.bodyFontSize + 'px';
      tooltipEl.style.fontStyle = tooltip._bodyFontStyle;
      tooltipEl.style.padding = tooltip.yPadding +
      'px ' +
      tooltip.xPadding +
      'px';
    };
    this.showConfig();
    this.LineChartInit(customTooltips);
  }

  showConfig() {  
    //debugger;
    this.MotorService.getAll().subscribe((data) => {
      console.log(data);
    });
    this.MotorService.getMotorDetails().subscribe((data) => {
      this.motorDetails=data;
      this.util.MotorDetails=data;
      //console.log(data);
    });
  }

  public ChangeMotor(Motor_name){
        this.MotorName=Motor_name;
        this.util.motorName=Motor_name;
  }
  public changeChart(Chart_data){
    this.Chart_selected=Chart_data;
    //debugger;
    if(Chart_data=='Power')
    this.lineChartData=[{ data: [35, 59, 90, 81, 76, 65, 70], label: Chart_data,fill: false },
                        { data: [85, 85, 85, 85, 85,85, 85], label: 'Threshold',fill: false },
                        { data: [100, 100,100,100,100,100,100], label: 'Warning',fill: false },
                        { data: [20, 20,20,20,20,20,20], label: 'Min Threshold',fill: false },
                        { data: [10, 10,10,10,10,10,10], label: 'Min Warning',fill: false }];
    else if(Chart_data=='Current')
    this.lineChartData=[{ data: [70, 70, 85, 81, 70,78, 60], label: Chart_data,fill: false },
                        { data: [85, 85, 85, 85, 85,85, 85], label: 'Threshold',fill: false },
                         { data: [100, 100,100,100,100,100,100], label: 'Warning',fill: false },
                         { data: [20, 20,20,20,20,20,20], label: 'Min Threshold',fill: false },
                         { data: [10, 10,10,10,10,10,10], label: 'Min Warning',fill: false }];
    else if(Chart_data=='MotorLoading%')
    this.lineChartData=[{ data: [35, 59, 90, 81, 76, 65, 70], label: Chart_data,fill: false },
                        { data: [85, 85, 85, 85, 85,85, 85], label: 'Threshold',fill: false },
                        { data: [100, 100,100,100,100,100,100], label: 'Warning',fill: false },
                        { data: [20, 20,20,20,20,20,20], label: 'Min Threshold',fill: false },
                        { data: [10, 10,10,10,10,10,10], label: 'Min Warning',fill: false }];
  }
  public Forecast(){
    this.router.navigate(['/forecast']);
  }
}
