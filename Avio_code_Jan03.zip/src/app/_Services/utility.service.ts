import { Injectable } from "@angular/core";

@Injectable()
export class utilityservice{
public displayNoSignUp:boolean=false;
public motorName:string="X-Motor";
public MotorDetails:any[];
public userLoggedIn:boolean=false;
}