import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap, map } from 'rxjs/operators';
import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
  })

  export class MotorService {
      constructor(private httpClient: HttpClient) {}
public APIurl:string='https://cbm-api-qa.avio.net'; //For Avio DB
//public APIurl:string='http://localhost:4000';  //For Local API
//public APIurl:string='http://my-alb-1885598496.us-east-2.elb.amazonaws.com:83';  //For Local API

public handleError;
      getAll(): Observable<any[]> {
        return this.httpClient.get('assets/MotorDetails.json')
        .pipe(map((data: any) => data));
      }

      getHomeDetails(): Observable<Response> {
        var url=this.APIurl+'/api/v1/machine';
        //url='assets/HomePAge.json';
        return this.httpClient.get(url)
        .pipe(map((data: any) => data));        
      }
      getMotorDetails(): Observable<any[]> {
        var url=this.APIurl+'/api/v1/parts/';
        //url='http://localhost:4000/api/v1/parts/';
        //url='assets/Dashboarddetails.json';
         return this.httpClient.get(url)
         .pipe(map((data: any) => data));
      }
      getMotorFactorDetails(params): Observable<any[]> {
        const headeroptions={
          headers:new HttpHeaders({'Content-Type': 'application/json'})
        }
        var url=this.APIurl+'/api/v1/motorcondition';       
        url='assets/motorconditionsample.json'
        // return this.httpClient.post(url,params ,headeroptions)
        // .pipe(map((data: any) => data));
        return this.httpClient.get(url,headeroptions)
        .pipe(map((data: any) => data));
        
      }
      getMotorForcastDetails(params): Observable<any[]> {
        const headeroptions={
          headers:new HttpHeaders({'Content-Type': 'application/json'})
        }
        var url=this.APIurl+'/api/v1/HistoricForecast';
        //url='assets/Forecast.json'
        return this.httpClient.post(url,params)
        .pipe(map((data: any) => data));
        
      }
      getAlertsDetails(params): Observable<any[]> {
        var url=this.APIurl+'/api/v1/Alerts/';
       //url='assets/AlertsData.json';
         return this.httpClient.post(url,params)
         .pipe(map((data: any) => data));
      }
      getConfigureDetails(params): Observable<any[]> {
        const headeroptions={
          headers:new HttpHeaders({'Content-Type': 'application/json'})
        }
        var url=this.APIurl+'/api/v1/Configure';
        //url='assets/Configure.json'
        return this.httpClient.post(url,params)
        .pipe(map((data: any) => data));
        
      }
      SaveConfigureDetails(params): Observable<any[]> {
        const headeroptions={
          headers:new HttpHeaders({'Content-Type': 'application/json'})
        }
        var url=this.APIurl+'/api/v1/Configure/update';
       // url='assets/Configure.json'
        return this.httpClient.post(url,params)
        .pipe(map((data: any) => data));
        
      }
      GetEmailDetails(params): Observable<any[]> {
        const headeroptions={
          headers:new HttpHeaders({'Content-Type': 'application/json'})
        }
        var url=this.APIurl+'/api/v1/email';
       // url='assets/emails.json'
        return this.httpClient.post(url,params)
        .pipe(map((data: any) => data));
        
      }
      UpdateEmailDetails(params): Observable<any[]> {
        const headeroptions={
          headers:new HttpHeaders({'Content-Type': 'application/json'})
        }
        var url=this.APIurl+'/api/v1/email/update';
       // url='assets/Configure.json'
        return this.httpClient.post(url,params)
        .pipe(map((data: any) => data));
        
      }
  }