// import { Injectable } from '@angular/core';
// import {
//   HttpRequest,
//   HttpHandler,
//   HttpEvent,
//   HttpInterceptor,
//   HttpResponse
// } from '@angular/common/http';
// import { Router } from '@angular/router';
// import { Observable } from 'rxjs';
// import { tap } from "rxjs/operators";
// //import { throwError } from 'rxjs';
// //import 'rxjs/add/observable/throw';

// // import { LoadingService, LoadingOverlayRef } from '../_Services/loading.service';

// @Injectable()
// export class LoadingInterceptor implements HttpInterceptor {
//   constructor(private loadingService: LoadingService) {
//   }

//   intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
//     let loadingRef: LoadingOverlayRef;

//     // This is a little hacky and related to change detection (ExpressionChangedAfterItHasBeenCheckedError).
//     // More informations here:
//     // https://blog.angularindepth.com/everything-you-need-to-know-about-the-expressionchangedafterithasbeencheckederror-error-e3fd9ce7dbb4

//     Promise.resolve(null).then(() => loadingRef = this.loadingService.open());

//     // return next.handle(req).do(event => {
//     //   if (event instanceof HttpResponse && loadingRef) {
//     //     loadingRef.close();
//     //   }
//     // }).catch(error => {
//     //   if (loadingRef) {
//     //     loadingRef.close();
//     //   }

//     //   return Observable.throw(error);
//     // });

//     return next.handle(req).pipe(
//         tap(
//           event => { if (event instanceof HttpResponse && loadingRef) {
//             loadingRef.close();
//           }},
//           error => {  if (loadingRef) {
//             loadingRef.close();
//           }
    
//           return Observable.throw(error);}
//         )
//       );
//   }
// }
