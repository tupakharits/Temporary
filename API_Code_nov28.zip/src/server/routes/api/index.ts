import express from 'express';
import Parser from './parser/parser';
import MachineSummary from './machine/machine';
import ModuleSummary from './module/module';
import PartsSummary from './part/parts';
import User from './user/user';
import Default from './default/default';
import MotorCondition from './MotorCondition/MotorCondition';
import cors from "cors";
const app = express();
const router = express.Router();
const options:cors.CorsOptions = {
    allowedHeaders: ["Origin", "X-Requested-With", "Content-Type", "Accept", "X-Access-Token","Authorization"],    
    methods: "GET,HEAD,OPTIONS,PUT,PATCH,POST,DELETE",
    origin: '*',    
    optionsSuccessStatus: 200,
    preflightContinue: false
};

//router.all('*',cors(options));

router.use(cors(options));
router.use('/',Default);
router.use('/users', User);
router.use('/parser', Parser);
router.use('/machine', MachineSummary);
router.use('/module', ModuleSummary);
router.use('/parts', PartsSummary);
router.use("/motorCondition",MotorCondition);

router.options("*", cors(options));

export default router;