import express from 'express';
import apiRoutes from './api/index';

export default function(app:express.Application) {
    app.use("/api/v1",apiRoutes);
}