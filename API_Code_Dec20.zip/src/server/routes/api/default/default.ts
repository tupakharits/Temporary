import express, { Request, Response } from "express";


const routes = express.Router();
routes.get("/", async (req: Request, resp: Response) => {
    resp.status(200).end();
});

export default routes;