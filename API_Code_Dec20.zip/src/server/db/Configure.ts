import {db} from "./db-provider";

export class ConfigureOperations {
    async GetConfigureData(queryText: string, params?: [])
    {
        let dbResult: any;
        dbResult = await db.query(queryText, params);
        return dbResult.rows;
    }
}