import {db} from '../db/db-provider';
import logger from '../../logger';

export class Parser {
    async insertPacket(params: any[]) {
        try{
            let queryText = `INSERT INTO Packet(Version, EntityId, LocationId, PlantId, DepartmentId, MachineId, PacketTimeStamp, InsertedTimeStamp) 
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`;
            let dbResult: any
            dbResult = await db.query(queryText,params);
            return dbResult.rows[0].id;
        }catch(error) {
            logger.error("error in module get function: " + error);
            console.log(error);
        }
    }

    async insertPacketData(params: any[]) {
        try{
            let queryText = `INSERT INTO PacketData(MachineId, ModuleTypeId, ModuleId, PartId, ParameterId, Value, Quality, ParameterTimeStamp, PacketId) 
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id`;
            let dbResult: any
            dbResult = await db.query(queryText,params);
            return dbResult.rows[0].id;
        }catch(error) {
            logger.error("error in module get function: " + error);
            console.log(error);
        }
    }


}