import {Component, ViewChild, OnInit} from '@angular/core';
import {MatPaginator, MatSort, MatTableDataSource} from '@angular/material';
import { utilityservice } from '../utility.service';
import { MotorService } from  '../motor.service';

@Component({
  selector: 'app-alerts',
  templateUrl: './alerts.component.html',
  styleUrls: ['./alerts.component.scss']
})

export class AlertsComponent implements OnInit {
  displayedColumns = ['id', 'progress','name',  'color','Alert_Description','Date_Time','Criticality','Status','Date_time_if_closed','Remarks'];
  dataSource:any[]=[];
  AlertsData:any;
 //dataSource=ELEMENT_DATA
  //dataSource: MatTableDataSource<UserData>;
  // @ViewChild(MatPaginator) paginator: MatPaginator;
  // @ViewChild(MatSort) sort: MatSort;

  // @ViewChild(MatPaginator) paginator: MatPaginator;
  //  @ViewChild(MatSort) sort: MatSort;

  constructor(private util:utilityservice,private motorService:MotorService) {
    this.util.displayNoSignUp=true;
    // Create 100 users
    const users: UserData[] = [];
    //users.push(ELEMENT_DATA[0]);
   // for (let i = 1; i <= 100; i++) { users.push()); }

    // Assign the data to the data source for the table to render
   // this.dataSource = new MatTableDataSource(users);
  }
  ngOnInit(){
this.GetAlertData();
  }
  GetAlertData(){
   
    this.motorService.getAlertsDetails()
    .subscribe((data: any):void =>{ 
      this.AlertsData = data;
      this.dataSource=this.AlertsData;
    });
  }
  /**
   * Set the paginator and sort after the view init since this component will
   * be able to query its view for the initialized paginator and sort.
   */
  ngAfterViewInit() {
   // this.dataSource.paginator = this.paginator;
   // this.dataSource.sort = this.sort;
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    //this.dataSource.filter = filterValue;
  }
}

export interface AleertData {
  Alertid: string;
  Alertname: string;
  AlertDescription: string;
  Motor_Name: string;
  //Alert_Description:string;
  Date_Time:string;
  Criticality:string;
  Status:string;
  Date_time_if_closed:string;
  Remarks:string;
}

/** Builds and returns a new User. */
// function createNewUser(id: number): UserData {
//   const name =
//       NAMES[Math.round(Math.random() * (NAMES.length - 1))] + ' ' +
//       NAMES[Math.round(Math.random() * (NAMES.length - 1))].charAt(0) + '.';}

/** Constants used to fill up our data base. */
const COLORS = [];
// const NAMES = ['', '', '', '', '', '',
//   '', '', '', '', '', '',
//   '', '', '', '', '', '', ''];




  const ELEMENT_DATA: AleertData[] = [
    {Alertid: '1', Alertname: 'Hydrogen', AlertDescription: '', Remarks: 'H',Motor_Name:'',Date_Time:'',Date_time_if_closed:'', Status:'',Criticality:''}
    
  ];

export interface UserData {
  Alertid: string;
  Alertname: string;
  AlertDescription: string;
  Motor_Name: string;
  Alert_Description:string;
  Date_Time:string;
  Criticality:string;
  Status:string;
  Date_time_if_closed:string;
  Remarks:string;
}

export class TableBasicExample {
  displayedColumns: string[] = ['AlertID', 'MotorName', 'AlertName', 'AlertType',
  'Alert Description','Date & Time','Criticality','Status','DateTime If Closed','Remarks'];
  dataSource = ELEMENT_DATA;
}