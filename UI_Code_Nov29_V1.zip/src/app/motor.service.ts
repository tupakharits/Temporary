import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap, map } from 'rxjs/operators';
import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
  })

  export class MotorService {
      constructor(private httpClient: HttpClient) {}

      getAll(): Observable<any[]> {
        return this.httpClient.get('assets/MotorDetails.json')
        .pipe(map((data: any) => data));
      }

      getHomeDetails(): Observable<any[]> {
        var url='http://my-alb-1885598496.us-east-2.elb.amazonaws.com:83/api/v1/machine';
        //url='assets/HomePAge.json';
        return this.httpClient.get('http://my-alb-1885598496.us-east-2.elb.amazonaws.com:83/api/v1/machine')
        .pipe(map((data: any) => data));
      }
      getMotorDetails(): Observable<any[]> {
        var url='http://my-alb-1885598496.us-east-2.elb.amazonaws.com:83/api/v1/parts/';
        //url='http://localhost:4000/api/v1/parts/';
        //url='assets/Dashboarddetails.json';
         return this.httpClient.get(url)
         .pipe(map((data: any) => data));
      }
      getMotorFactorDetails(params): Observable<any[]> {
        const headeroptions={
          headers:new HttpHeaders({'Content-Type': 'application/json'})
        }
        var url='http://my-alb-1885598496.us-east-2.elb.amazonaws.com:83/api/v1/motorcondition';
        //url='http://localhost:4000/api/v1/motorcondition/';
        //url='assets/motorconditionsample.json;'
        return this.httpClient.post(url,params ,headeroptions)
        .pipe(map((data: any) => data));
        
      }
      getMotorForcastDetails(params): Observable<any[]> {
        const headeroptions={
          headers:new HttpHeaders({'Content-Type': 'application/json'})
        }
        var url='http://my-alb-1885598496.us-east-2.elb.amazonaws.com:83/api/v1/HistoricForecast';
        url='http://localhost:4000/api/v1/HistoricForecast/';
        //url='assets/Forecast.json'
        return this.httpClient.post(url,params)
        .pipe(map((data: any) => data));
        
      }
      getAlertsDetails(): Observable<any[]> {
        var url='http://my-alb-1885598496.us-east-2.elb.amazonaws.com:83/api/v1/Alerts/';
        //url='http://localhost:4000/api/v1/Alerts/';
       // url='assets/AlertsData.json';
         return this.httpClient.get(url)
         .pipe(map((data: any) => data));
      }
  }




// import { Injectable } from '@angular/core';
// import { HttpClient } from '@angular/common/http';


// @Injectable({
//   providedIn: 'root'
// })
// export class MotorService {
//   public configUrl:string;
//   constructor(private http: HttpClient) {     
//     this.configUrl = 'assets/MotorDetails.json';
//   }

//   public data:any;
//   getConfig() {
//     this.data=this.http.get('http://localhost:4000/api/v1/users/2');
//     return this.http.get('http://localhost:4000/api/v1/users/2');
//     //return this.http.get('assets/test.json')
//   }
// }
