const aws = require('aws-sdk')
const { Client } = require('pg')

//KMS Component
var kms = new aws.KMS({
  accessKeyId: process.env.ACCESSKEYID,
  secretAccessKey: process.env.SECRETACCESSKEY,
  region: process.env.REGION
});

const params = {
    CiphertextBlob: Buffer.from(process.env.DB_URL, 'base64')
  }
  
let result;
let DecryptedString;

exports.handler = async (event) => {
    
  var eventMessage = JSON.parse(JSON.stringify(event));
  var cronMessage = eventMessage.duration;
  console.log('CRON Message Value :' + cronMessage);

  //Decryption
  try {
    const Decrypted = await kms.decrypt(params).promise();
    DecryptedString = Decrypted.Plaintext.toString('utf-8');
  }
  catch (exception) {
    console.log(exception)
  }
  const queryText = `SELECT Fn_dashboardsummary(); SELECT fn_setAlerts()`;

  const queryTENMinuteFunction = `SELECT Fn_parametersummary()`;
  const queryHourlyMinuteFunction = `SELECT Fn_parametersummarydaily()`;

  const client = new Client({
    connectionString: DecryptedString
});

//DB Client
await client.connect();

switch (cronMessage) {
  case '1m':
    client.query(queryText)
            .then(result => console.log('Ran the Fn_dashboardsummary() and fn_setAlerts() function')) 
             .catch(e => console.error(e.stack)) 
              .then(() => client.end())
    break;
  case '10m':
    client.query(queryTENMinuteFunction)
            .then(result => console.log('Ran the Fn_parametersummary() function')) 
             .catch(e => console.error(e.stack)) 
              .then(() => client.end())
    break;
  case '1hr':
    client.query(queryHourlyMinuteFunction)
            .then(result => console.log('Ran the Fn_parametersummarydaily() function')) 
             .catch(e => console.error(e.stack)) 
              .then(() => client.end())
} 
    return result;
}