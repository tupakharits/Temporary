var DB = require('./db-provider');

//Function to query from the Db using Connetion string
class ParserDbOpeartions {
    async queryPacket(query) {
        try {
            let queryText = query;
            let dbResult
            dbResult = await DB.DbProvider.query(queryText);
            return dbResult
        } catch (error) {
            throw error;
        }
    }
}

exports.ParserDbOpeartions = ParserDbOpeartions;