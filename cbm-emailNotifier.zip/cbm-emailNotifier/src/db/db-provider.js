var Pool = require('pg').Pool;
var AWS = require('aws-sdk');

var pool;

//Function to Make DB Connection and the base code to query using pool
async function DBQueryPool(decryptedString) {

    pool = new Pool({
        connectionString: decryptedString,
        connectionTimeoutMillis: 5000
    });

    pool.connect((err, client, done) => {
        if (err) {
            done();
        }
        else {
        }
        done();
    });

    pool.on('error', (error, client) => {
        process.exit(-1);
    });
}

const DbProvider = {
    query(queryText) {
        return new Promise((resolve, reject) => {
            pool.query(queryText)
                .then((dbResult) => resolve(dbResult))
                .catch((dbError) => reject(dbError))
        });
    }
}

exports.pool = pool;
exports.DBQueryPool = DBQueryPool;
exports.DbProvider = DbProvider;