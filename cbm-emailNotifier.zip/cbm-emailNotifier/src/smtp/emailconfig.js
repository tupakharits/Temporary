const nodemailer = require("nodemailer");
const dotenv = require("dotenv");
const path_1 = require("path");
dotenv.config({ path: path_1.resolve(__dirname, "configs.env") });

let secureVal;

const emailConfig = {
    async emailSMTPServer() {

        //SMTP Server Config
        if (process.env.PORT == 465) {
            secureVal = true;
        } else {
            secureVal = false;
        }
        let transporter = nodemailer.createTransport({
            host: process.env.HOST,
            port: process.env.PORT,
            secure: secureVal, // true for 465, false for other ports
            pool: true,
            auth: {
                user: process.env.USER_VAL,
                pass: process.env.PASSWORD
            }
        });
        return transporter
    }
}

exports.emailConfig = emailConfig;