const nodemailer = require("nodemailer");
const dotenv = require("dotenv");
const path_1 = require("path");
dotenv.config({ path: path_1.resolve(__dirname, "configs.env") });

//Function to send tan email with the configure ddata
const emailNotifier = {
    async emailClass(item, transporter) {

        if (item.recipientlist == null) {
            return "NRA";
        }
        try {
            // send mail with defined transport object
            let emailInfo = await transporter.sendMail({
                from: '"CBM - " ' + process.env.USER_VAL,
                to: item.recipientlist,
                subject: "CBM: Alert Occurred: " + item.alertname,
                text: "An Alert has occured:" + "\n\n\n" +
                    "AlertId: " + item.alertid + "\n" +
                    "Motor: " + item.motor + "\n" +
                    "AlertName: " + item.alertname + "\n" +
                    "AlertType: " + item.alerttype + "\n" +
                    "AlertDescription: " + item.alertdescription + "\n" +
                    "AlertDateTime: " + item.alertdatetime + "\n" +
                    "Criticality: " + item.criticality + "\n\n" +
                    "*******************************************************************************"
            });
            return "SENT";
        } catch (error) {
            
        }
    }
};

exports.emailNotifier = emailNotifier;