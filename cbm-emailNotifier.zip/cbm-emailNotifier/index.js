var emailSMTPMethod = require('./src/smtp/emailclass').emailNotifier;
var queryMethod = require('./src/db/parser-db-operations');
var AWS = require('aws-sdk')
var DBConnection = require('./src/db/db-provider')
const dotenv = require("dotenv");
const path_1 = require("path");
dotenv.config({ path: path_1.resolve(__dirname, "configs.env") });
const logger = require('./logger').logger;
const smtpServer = require('./src/smtp/emailconfig').emailConfig;
require('pg')

//CRON Method to call the main function in every 1 minute
setInterval(mainclass, 60000)

//Function to Get the open alerts from the Alert table and send an email to the respective alert owner
async function mainclass() {

  let hostnameEncString = process.env.DB_URL;
  let fetchquery = `SELECT Id as AlertId, PartName as Motor, (ParameterName || ' Alert' ) as AlertName, AlertBreachModeName as AlertType,'' as AlertDescription, AlertInsertedDateTime as AlertDateTime, ActualBreachName as Criticality, AlertStatus as Status, AlertNotifiedDateTime as AlertClosedTime, '' as Remarks, RecipientList FROM Alert WHERE ModuleId = 1 and AlertStatus = 'O'`;// order by alertinserteddatetime desc limit 1
  let updateAlertquery = `Update Alert set AlertStatus = 'N',AlertNotifiedDateTime = Now() WHERE Id = `;
  let data;

  try {
    //Decrypt the Db String
    let hostname = await decrypt(hostnameEncString);
    hostNameValue = hostname.Plaintext.toString();

    //Make DB Connection
    await DBConnection.DBQueryPool(hostNameValue);

    let emailTransporter = await smtpServer.emailSMTPServer();
    //Get the Alert Data
    data = await new queryMethod.ParserDbOpeartions().queryPacket(fetchquery);
    if (data.rowCount == 0) {
      DBConnection.pool.end();
      process.exit();
    } else {
      for (let item of data.rows) {
        let sentmail = await emailSMTPMethod.emailClass(item, emailTransporter);

        if (sentmail == "NRA") {
          logger.info("No Recipient List Available")
          continue;
        }
        if (sentmail == 'Missing credentials for "PLAIN"') {
          logger.error(sentmail)
          DBConnection.pool.end();
          break;
        }
        if (sentmail == "SENT") {
          let updateAlert = updateAlertquery + item.alertid;
          await new queryMethod.ParserDbOpeartions().queryPacket(updateAlert);
        } else {
          continue;
        }
      }
      try {
        DBConnection.pool.end();
      } catch (error) {
      }
      emailTransporter.close();
    }

  } catch (error) {
    logger.error("Error While sending the mail or while decrypting" + error)
  }
}

//Kms Decryption Function
async function decrypt(EncString) {
  var kms = new AWS.KMS({
    region: 'us-east-2'
  });

  params = {
    CiphertextBlob: Buffer.from(EncString, 'base64')
  }

  return new Promise((resolve, reject) => {
    kms.decrypt(params, (err, data) => {
      if (err) {
        return reject(err);
      }
      return resolve(data);
    });

  });
}
