export class Constents{
    ProductionUrl:string=''
    developmentUrl:string=''
    AwsUrl:string=''
}