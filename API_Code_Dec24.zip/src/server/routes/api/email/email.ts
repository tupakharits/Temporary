import express, { Request, Response } from "express";
import { EmailDBOperations } from "../../../db/email";
import logger from '../../../../logger';
import moment from "moment";

const routes = express.Router();

// Insert Email
routes.post("/", async (req: Request, resp: Response) => {
  try {
   var ParameterName=req.body["parametername"];
   // const EmailQueryText = "INSERT INTO email (email) VALUES ($1)";
   //const EmailQueryText = "select * from alertdef"
   const EmailQueryText="SELECT * FROM alertdef WHERE parameterid = (select id from parameter where name like '%"+ParameterName+"%')  ORDER BY id ASC"
    var params: any = [];
	//params.push(req.body.email);
    var dbResult = await new EmailDBOperations().emailQuery(
        EmailQueryText,
		params
    );
    resp.json(dbResult);
  } catch (error) {
    logger.error("Error in email insert function: " + error);
    resp.status(500).json({ message: error.message ? error.message : "" });
  }
});

// Get all Emails
routes.get("/", async (req: Request, resp: Response) => {
  try {
    const EmailQueryText = "SELECT * FROM alertdef ORDER BY id ASC"
    var params: any = [];
    var dbResult = await new EmailDBOperations().emailQuery(
        EmailQueryText,
		params
    );
    resp.json(dbResult);
  } catch (error) {
    logger.error("Error in email get all function: " + error);
    resp.status(500).json({ message: error.message ? error.message : "" });
  }
});

// Get Email by ID
routes.get("/update", async (req: Request, resp: Response) => {
  try {
    const EmailQueryText = "SELECT * FROM alertdef WHERE parameterid IN (select id from parameter where name like '%"+req.body.parameterid+"%')"
    var params: any = [];
    var dbResult = await new EmailDBOperations().emailQuery(
        EmailQueryText,
		params
    );
    resp.json(dbResult);
  } catch (error) {
    logger.error("Error in email get by id function: " + error);
    resp.status(500).json({ message: error.message ? error.message : "" });
  }
});

// Update Email by ID
routes.post("/update", async (req: Request, resp: Response) => {
  try {
    const EmailQueryText = "UPDATE alertdef SET RecipientList  = '"+req.body.email+"' WHERE parameterid =(select id from parameter where name like '%"+req.body.parametername+"%')"
    var params: any = [];
//	params.push(req.params.parameterid);
//	params.push(req.body.email);
    var dbResult = await new EmailDBOperations().emailQuery(
        EmailQueryText,
		params
    );
    resp.json('updated successfully Email');
  } catch (error) {
    logger.error("Error in email update function: " + error);
    resp.status(500).json({ message: error.message ? error.message : "" });
  }
});

// Delete Email by ID
routes.post("/Remove", async (req: Request, resp: Response) => {
  try {
    var ParameterName=req.body.parametername;
    const EmailQueryText = "DELETE FROM alertdef WHERE parameterid = (select id from parameter where name like '%"+ParameterName+"%')"
    var params: any = [];
//	params.push(req.params.id);
    var dbResult = await new EmailDBOperations().emailQuery(
        EmailQueryText,
		params
    );
    resp.json(dbResult);
  } catch (error) {
    logger.error("Error in email delete function: " + error);
    resp.status(500).json({ message: error.message ? error.message : "" });
  }
});

export default routes;
