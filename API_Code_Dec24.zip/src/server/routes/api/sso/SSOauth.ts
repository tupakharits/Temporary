import express, { Request, Response } from "express";
import logger from '../../../../logger';
const routes = express.Router();
let cors = require('cors');

// passport js
const passport = require('passport');
const OAuth2Strategy = require('passport-oauth2');

const clientID = 'CBM_AVIO_AERO';
const clientSecret = '5$9AGMbwcrF$W5IHDy@Lh$Vy9qRgihBElUcO9ZHwtNpXUZMW70nRRQJuE9JLlzRW';

passport.use(new OAuth2Strategy({
   authorizationURL: 'https://fssfed.ge.com/fss/as/authorization.oauth2',
   tokenURL: 'https://fssfed.ge.com/fss/as/token.oauth2',
   clientID: clientID,
   clientSecret: clientSecret,
   // callbackURL: "https://cbm.avio.net/"
   callbackURL:"http://my-alb-1885598496.us-east-2.elb.amazonaws.com/"
 },
 function(accessToken: any[], refreshToken: any[], profile: any[], cb: any[]) {
   console.log('accessToken: ', accessToken);
   console.log('refreshToken: ', refreshToken);
   console.log('profile: ', profile);
   console.log('cb: ', cb);
 }
));

routes.post("/auth", passport.authenticate('oauth2'), async (req: Request, resp: Response) => {
  try {
	console.log(req.body);
  } catch (error) {
    logger.error("error in sso function: " + error);
    resp.status(500).json({ message: error.message ? error.message : "" });
  }
});

routes.get('/auth/callback',
 passport.authenticate('oauth2', { failureRedirect: '/login' }),
 function(req, res) {
   // Successful authentication, redirect home.
   console.log('callback');
   res.status(302);
   res.redirect('/');
});

export default routes;
