import express, {Request, Response} from 'express';
import parser from './parsedata';
const routes = express.Router();

routes.post('/', async (req: Request, resp: Response) => {
	if(req.body) {
	    parser.parserLogic(req);
	    resp.sendStatus(200);
	} else {
	    resp.sendStatus(500);
	}        
});

export default routes;