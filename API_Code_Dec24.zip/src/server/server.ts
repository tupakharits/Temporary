import CreateApp from './app';
import logger from '../logger';
import express from 'express';
import {db,dec_enabled_db} from "./db/db-provider";
import bodyParser from 'body-parser';
const port = process.env.PORT || 3000;
import cors from 'cors';

const app = CreateApp();

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

const queryText = `SELECT Fn_dashboardsummary(); SELECT fn_setAlerts()`;
const queryTENMinuteFunction = `SELECT Fn_parametersummary()`;
const queryHourlyMinuteFunction = `SELECT Fn_parametersummarydaily()`;

async function DBCall(query:string) {
    let dbResult: any;
    dbResult = await db.query(query);
    return dbResult.rows;
}

async function MinuteCall()
{
    try {
        return DBCall(queryText);
    } catch (error) {
        logger.error("error in user get function: " + error);
    }
}

async function TenMinuteCall() {
    try {
        return DBCall(queryTENMinuteFunction);
    } catch (error) {
        logger.error("error in user get function: " + error);
    }
}

function HourCall() {
    try {
        return DBCall(queryHourlyMinuteFunction);
    } catch (error) {
        logger.error("error in user get function: " + error);
    }
}

app.listen(port, () => {
    logger.debug(`server running on port ${port}`);
    console.log(`server running on port ${port}`);
    dec_enabled_db(process.env.DB_URL !== undefined ? process.env.DB_URL : '');
    setInterval(MinuteCall, 60000);
    setInterval(TenMinuteCall, 600000);
    setInterval(HourCall, (60000*60));
});