import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { ChartsModule } from 'ng2-charts';
import { Routes, RouterModule, Route } from '@angular/router';
import { HttpClientModule ,HttpClient,HTTP_INTERCEPTORS} from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {TranslateModule,TranslateLoader } from '@ngx-translate/core'
import {TranslateHttpLoader} from '@ngx-translate/http-loader'
import { ReactiveFormsModule } from '@angular/forms';
import { FlexLayoutModule } from "@angular/flex-layout" ;
import {MaterialModule} from './material-module';
import {CdkTableModule} from '@angular/cdk/table';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
//import { NgbTimeStruct, NgbDateStruct, NgbPopoverConfig, NgbPopover, NgbDatepicker } from '@ng-bootstrap/ng-bootstrap';
import {DatePipe} from '@angular/common'
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HomeComponent } from './home/home.component';
import { MotorConditionComponent } from './motor-condition/motor-condition.component';
import { MotorConditionCustomPopup } from './motor-condition/motor-condition.component';
import { ForecastComponent } from './forecast/forecast.component';
import { ConfigureComponent } from './configure/configure.component';
import { AlertsComponent } from './alerts/alerts.component';
import { FooterComponent } from './footer/footer.component';
import { ToolbarComponent } from './toolbar/toolbar.component';

// used to create fake backend
import { fakeBackendProvider, AuthGuard } from './_Helpers';
import { JwtInterceptor, ErrorInterceptor } from './_Helpers';
import { utilityservice } from './_Services/utility.service';
import { LoginAlertComponent } from './login-alert/login-alert.component';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { DBConnectionAlertComponent } from './dbconnection-alert/dbconnection-alert.component';
import { ExcelService } from './_Services/excel.service';
//import { LoadingComponent } from './loading/loading.component'
import { OverlayModule } from '@angular/cdk/overlay';
// import { LoadingInterceptor } from './_Helpers/loading.interceptors'
// import { LoadingService } from './_Services/loading.service';
import { MotorService} from './_Services/motor.service';
import { NgxSpinnerModule } from "ngx-spinner";
import {TempService} from './temp.service';

const Routes: Routes = [
  // {  path: '', component: LoginComponent }  ,
  // {path:'Dashboard', component:DashboardComponent},
  // {path:'Home', component:HomeComponent},
  // {path:'MotorCondition', component:MotorConditionComponent},
  // {path:'forecast', component:ForecastComponent},
  // {path:'configure', component:ConfigureComponent},
  // {path:'Alerts', component:AlertsComponent}
  {  path: '', component: LoginComponent }  ,
  {path:'Dashboard', component:DashboardComponent, canActivate:[AuthGuard]},
  {path:'Homepage', component:HomeComponent,canActivate:[AuthGuard]},
  {path:'MotorCondition', component:MotorConditionComponent,canActivate:[AuthGuard]},
  {path:'forecast', component:ForecastComponent,canActivate:[AuthGuard]},
  {path:'configure', component:ConfigureComponent,canActivate:[AuthGuard]},
  {path:'Alerts', component:AlertsComponent,canActivate:[AuthGuard]}
]
export function HttpLoaderFactory(http: HttpClient){
  return new TranslateHttpLoader(http);
}
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    HomeComponent,
    MotorConditionComponent,
    MotorConditionCustomPopup,
    ForecastComponent,
    ConfigureComponent,
    AlertsComponent,
    FooterComponent,
    ToolbarComponent,
    LoginAlertComponent,
    NavBarComponent,
    DBConnectionAlertComponent
  ],
  entryComponents: [MotorConditionCustomPopup],
  imports: [
    BrowserModule,   
    HttpClientModule,   // import HttpClientModule after BrowserModule.
    AppRoutingModule,
    ChartsModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    FlexLayoutModule,
    //NgxMaterialTimepickerModule,
    NgbModule,
    OverlayModule,
    CdkTableModule,
    NgxSpinnerModule,
    TranslateModule.forRoot({
      loader:{
        provide: TranslateLoader,
        useFactory:HttpLoaderFactory,
        deps:[HttpClient]
      }
    }),    
    RouterModule.forRoot(Routes),
    BrowserAnimationsModule
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
    { provide: AuthGuard, useClass: AuthGuard },
    fakeBackendProvider,utilityservice,DatePipe,ExcelService,MotorService,TempService],    
        
  bootstrap: [AppComponent]
})
export class AppModule { }
