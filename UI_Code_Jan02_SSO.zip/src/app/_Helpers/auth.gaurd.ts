// import { Injectable } from '@angular/core';
// import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
// import { AuthenticationService } from '../_Services';

// @Injectable({ providedIn: 'root' })

// export class AuthGuard implements CanActivate {
//     constructor(        
//         private router: Router,
//         private authenticationService: AuthenticationService
//     ) {}

//     canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
//         const currentUser = this.authenticationService.currentUserValue;
//       // debugger;
//        return true;
//        // check the token validity
//         if(this.authenticationService.UserLoggedIn()){
//             return true;
//         }
//         // if (currentUser ) {
//         //     // authorised so return true
//         //    debugger;
//         //     return true;
//         // }

//         // not logged in so redirect to login page with the return url
//         this.router.navigate(['/'], { queryParams: { returnUrl: state.url }});
//         return false;
//     }
// }


import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

import { AuthenticationService } from '../_Services/Authentication.service';
import { map, catchError } from 'rxjs/operators';
import { Observable, of } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {
    constructor(
        private router: Router,
        private authenticationService: AuthenticationService
    ) { }

    Data: any = [];

    canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable <boolean> {
        return this.authenticationService.isLoggedIn().pipe(map(e => {
            this.Data = e;
           // debugger;
            if(this.Data.status) {
                return true;
            } else {
                this.router.navigate(['/']);
            }
        }), catchError((err) => {
            this.router.navigate(['/']);
            return of(false);
        }));
    }
}