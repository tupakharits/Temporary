const express = require('express');
const SSOAuthRoute = express.Router();
const request = require('request');

const clientID = 'CBM_AVIO_AERO';
const clientSecret = '5$9AGMbwcrF$W5IHDy@Lh$Vy9qRgihBElUcO9ZHwtNpXUZMW70nRRQJuE9JLlzRW';

const oauth2 = require('simple-oauth2').create({
  client: {
    id: clientID,
    secret: clientSecret,
  },
  auth: {
    tokenHost: 'https://cbm.avio.net/',
    tokenPath: 'https://fssfed.ge.com/fss/as/token.oauth2',
    authorizePath: 'https://fssfed.ge.com/fss/as/authorization.oauth2',
  },
  http: {
    headers: {
      'Access-Control-Allow-Origin': '*'
    }
  }
});
//const BaseURI=window.location.origin;
//http://my-alb-1885598496.us-east-2.elb.amazonaws.com/Home
// Authorization uri definition
const authorizationUri = oauth2.authorizationCode.authorizeURL({
  redirect_uri: 'http://localhost:4200/Home',
  scope: '',
  state: '3(#0/!~',
});

// Initial page redirecting to GE
SSOAuthRoute.route('/login').get((req, res) => {
    console.log('Login api');
    console.log(authorizationUri);
    res.redirect(authorizationUri);
});

// Callback service parsing the authorization token and asking for the access token
SSOAuthRoute.route('/callback').get((req, res) => {
  const { code,scope } =req.query;//{code:'OqpPgVyugwtf09ED02OyBQLsKLNIOLYtzoSm_gAE&state=3(%230%2F!~'};
  const tokenConfig = {
    code,
  };
  tokenConfig.redirect_uri='http://localhost:4200/Home';
  const httpOptions={};
//console.log(tokenConfig);
  try {
    debugger;
    const result = oauth2.authorizationCode.getToken(tokenConfig, httpOptions).then((data)=>{
      console.log("data");
      console.log(data.access_token);
      return res.status(200).json(data);
    }).catch((error)=>{
      console.log("Error");
      console.log(error);
      return res.status(400).json(error);
    });

    //console.log('The resulting token: ', result);

    //const token = oauth2.accessToken.create(result);
    //console.log("Token");
//console.log(token);
   // return res.status(200).json(token);
  } catch (error) {
    console.error('Access Token Error', error.message);
    return res.status(500).json('Authentication failed');
  }
});

module.exports = SSOAuthRoute;