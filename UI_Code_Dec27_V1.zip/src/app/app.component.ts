import { Component } from '@angular/core';

import { TranslateService } from '@ngx-translate/core';
import { MotorService } from './motor.service';
import { utilityservice } from './utility.service';
import { Router } from '@angular/router';
import { AlertService, AuthenticationService } from './_Services'
//import {MDCTopAppBar} from '@material/top-app-bar';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'AvioAeroApp';
  public Languages:string[]=['English','Italian'];
 //public displayNoSignUp:boolean;
  constructor(public translate:TranslateService,private MotorService:MotorService, 
    private util:utilityservice, private router: Router,private authenticationService: AuthenticationService){
 
    translate.addLangs(['en-US', 'it-CH']);
    translate.setDefaultLang('en-US');

    const browserLang=translate.getBrowserLang();
    translate.use(browserLang.match(/en-US|it-CH/) ? browserLang:'en-US')

    //console.log('Browser Lang =', browserLang);
   // console.log('Navigator Lang =', navigator.language);
    //console.log('Current Lang =', translate.currentLang);
    
    // this.MotorService.getAll().subscribe((data) => {
    //   console.log(data);
    // });
  }
  onlogOut()
{
 
  this.util.displayNoSignUp=false;
  this.authenticationService.logout();
  this.router.navigate(['/']);
}
changeLang(language: string) {
    
    if(language=='English')
        this.translate.use('/en-US');
    else
        this.translate.use('/it-CH');
  }
}

