import { Component, OnInit, Inject } from '@angular/core';
import { ChartDataSets, ChartOptions } from 'chart.js';
import { Color, Label } from 'ng2-charts';
import { ActivatedRoute, Router } from '@angular/router';
import { MotorService } from  '../motor.service';
import { utilityservice } from '../utility.service';

import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';

import { debug } from 'util';


export interface DialogData {
  customDate: Date;
  customTime: string;
  customDuration:string;
}

@Component({
  selector: 'app-motor-condition',
  templateUrl: './motor-condition.component.html',
  styleUrls: ['./motor-condition.component.scss']
})

export class MotorConditionComponent implements OnInit {

  customDate:Date;
  customTime:string;
  DurationTime:string='hour';
 
  public lineChartData: any[] = [
    { data: [45, 56, 80, 81, 56, 55, 40], label: 'Power ',fill: false },
    { data: [85, 85, 85, 85, 85,85, 85], label: 'Threshold',fill: false },
    { data: [100, 100,100,100,100,100,100], label: 'Warning',fill: false },
    { data: [20, 20,20,20,20,20,20], label: 'Min Threshold',fill: false },
    { data: [10, 10,10,10,10,10,10], label: 'Min Warning',fill: false }
  ];
  
  public motordata:any;
  public motorDetails:any[];
  public MotorMake:string='';
  public MotorModel:string='';
  public AssetID:string='';
  public Location:string='';
  public RatedCurrent:string='';
  public Voltage:string='';
  public RatedPower:string='';
  public PowerFactor:string='';
  public  MaxRPM:string='';
  public MinRPM:string='';
  public DateTime_Selected:string='';
  public Duration:string='hour';
  public graphwidth:number=1000;

  LineChartInit(customTooltips){
    
    this.lineChartOptions = {
      legend: { position:'bottom' },
      tooltips: {
        enabled: true,
        mode: 'index',
        position: 'nearest',
       // custom: customTooltips,
       callbacks: {
        labelColor: function(tooltipItem, chart) {
            return {
                borderColor: 'rgb(255, 0, 0)',
                backgroundColor: 'rgb(255, 0, 0)'
            };
        },
        label:function(tooltipItem, chart){ return 'test toolstip';},
        labelTextColor: function(tooltipItem, chart) {
            return '#FFFFFF';
        }
    }
      },
      scales: {
        yAxes: [{
            ticks: {
                beginAtZero: true
            }
        }]
      }     
  }
}
  public Chart_selected:string='Power';
  public lineChartLabels: Label[] = ['12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00'];
  // public lineChartOptions: (ChartOptions & { annotation: any }) = {
  //   responsive: true,
  // };
  public lineChartColors: Color[] = [
    {borderColor: 'blue'},
    {borderColor: 'Orange',},
    {borderColor: 'red',},
    {borderColor: 'Orange',},
    {borderColor: 'red',},
  ];
  public  lineChartOptions: any = {
    // legend: { position:'bottom' },
    // scales: {
    //   xAxes:[{
    //     type: 'linear'
    //   }],
    //   yAxes: [{
    //       ticks: {
    //           beginAtZero: true
    //       }
    //   }],
    //   showtooltips:true,
    //   tooltipEvents: ["mousemove", "touchstart", "touchmove"],
    //   tooltips: {
    //     enabled: true,
    //     mode: 'index',
    //     position: 'nearest'
        //custom: customTooltips,
     // },
   // }
    }
  public lineChartLegend = true;
  public lineChartType = 'line';
  public lineChartPlugins = [];
  public MotorName:string='Xmotor';

  constructor(private route:ActivatedRoute, private router:Router,private MotorService:MotorService,private util:utilityservice, public dialog: MatDialog) {
    //debugger;
    //console.log(route.snapshot.data['p1']);
    if(route.snapshot.data["p1"]!=undefined)
        this.MotorName=route.snapshot.data['p1'];
    this.util.displayNoSignUp=true;
    this.MotorName=this.util.motorName;
    this.motorDetails=this.util.MotorDetails;
    //console.log(this.motorDetails);
}

  ngOnInit() {
    const customTooltips = function(tooltip) {
      // Tooltip Element
      let tooltipEl = document.getElementById('chartjs-tooltip');
      if (!tooltipEl) {
        tooltipEl = document.createElement('div');
        tooltipEl.id = 'chartjs-tooltip';
        tooltipEl.innerHTML = '<table></table>';
        this._chart.canvas.parentNode.appendChild(tooltipEl);
      }
      // Hide if no tooltip
      if (tooltip.opacity === 0) {
        tooltipEl.style.opacity = 0 as any;
        return;
      }
      // Set caret Position
      tooltipEl.classList.remove('above', 'below', 'no-transform');
      if (tooltip.yAlign) {
        tooltipEl.classList.add(tooltip.yAlign);
      } else {
        tooltipEl.classList.add('no-transform');
      }
      function getBody(bodyItem) {
        return bodyItem.lines;
      }
      // Set Text
      //debugger;
      if (tooltip.body) {
        
        const titleLines = tooltip.title || [];
        //const bodyLines = tooltip.body.map(getBody);
        let innerHtml = '<thead>';
        const bodyLines=[['power'],['current']];
        //console.log(titleLines);
        //console.log(bodyLines);
        titleLines.forEach(function(title) {
          innerHtml += '<tr><th>' + title + '</th></tr>';
        });
        innerHtml += '</thead><tbody>';
        bodyLines.forEach(function(body, i) {
          const colors = tooltip.labelColors[i];
          let style = 'background:' + colors.backgroundColor;
          style += '; border-color:' + colors.borderColor;
          style += '; border-width: 2px';
          const span = '<span class="chartjs-tooltip-key" style="' +
          style +
          '"></span>';
          innerHtml += '<tr><td>' + span + body+'Alekhya'+ '</td></tr>';
        });
        innerHtml += '</tbody>';
        //console.log(innerHtml);
        const tableRoot = tooltipEl.querySelector('table');
        tableRoot.innerHTML = innerHtml;
        console.log(tableRoot.innerHTML);
      }
      const positionY = this._chart.canvas.offsetTop;
      const positionX = this._chart.canvas.offsetLeft;
      // Display, position, and set styles for font
      tooltipEl.style.opacity = 1 as any;
      tooltipEl.style.left = positionX + tooltip.caretX + 'px';
      tooltipEl.style.top = positionY + tooltip.caretY + 'px';
      tooltipEl.style.fontFamily = tooltip._bodyFontFamily;
      tooltipEl.style.fontSize = tooltip.bodyFontSize + 'px';
      tooltipEl.style.fontStyle = tooltip._bodyFontStyle;
      tooltipEl.style.padding = tooltip.yPadding +
      'px ' +
      tooltip.xPadding +
      'px';
    };
    this.showConfig();
    this.LineChartInit(customTooltips);
  }

  showConfig() {  
    //debugger;
    this.MotorService.getAll().subscribe((data) => {
      console.log(data);
    });
    this.MotorService.getMotorDetails().subscribe((data) => {
      this.motorDetails=data;
      this.util.MotorDetails=data;
    });
    var params = 
    {
      PartNAme: this.MotorName,
      Parameter:this.Chart_selected,
      DateTime: this.DateTime_Selected,
      Duration: this.Duration
    }
    this.MotorService.getMotorFactorDetails(params).subscribe((data) => {
      console.log(data);
      //this.motorDetails=data;
      //this.util.MotorDetails=data;
    });
  }

  public ChangeMotor(Motor_name){
        this.MotorName=Motor_name;
        this.util.motorName=Motor_name;
        //Call change chart
        this.changeChart(this.Chart_selected);
        this.showConfig();
  }
  public ChangeDuration(Duration){
    //debugger;
     this.Duration=Duration;
     if(Duration=='hour'){this.graphwidth=50;}
     if(Duration=='day'){this.graphwidth=2000;}
     if(Duration=='month'){this.graphwidth=5000;}
     
     console.log(this.graphwidth);
     //this.showConfig();
  }
  public changeChart(Chart_data){
    this.Chart_selected=Chart_data;
    //debugger;
    if(Chart_data=='Power')
    this.lineChartData=[{ data: [35, 59, 90, 81, 76, 65, 70], label: Chart_data,fill: false },
                        { data: [85, 85, 85, 85, 85,85, 85], label: 'Threshold',fill: false },
                        { data: [100, 100,100,100,100,100,100], label: 'Warning',fill: false },
                        { data: [20, 20,20,20,20,20,20], label: 'Min Threshold',fill: false },
                        { data: [10, 10,10,10,10,10,10], label: 'Min Warning',fill: false }];
    else if(Chart_data=='Current')
    this.lineChartData=[{ data: [70, 70, 85, 81, 70,78, 60], label: Chart_data,fill: false },
                        { data: [85, 85, 85, 85, 85,85, 85], label: 'Threshold',fill: false },
                         { data: [100, 100,100,100,100,100,100], label: 'Warning',fill: false },
                         { data: [20, 20,20,20,20,20,20], label: 'Min Threshold',fill: false },
                         { data: [10, 10,10,10,10,10,10], label: 'Min Warning',fill: false }];
    else if(Chart_data=='MotorLoading%')
    this.lineChartData=[{ data: [35, 59, 90, 81, 76, 65, 70], label: Chart_data,fill: false },
                        { data: [85, 85, 85, 85, 85,85, 85], label: 'Threshold',fill: false },
                        { data: [100, 100,100,100,100,100,100], label: 'Warning',fill: false },
                        { data: [20, 20,20,20,20,20,20], label: 'Min Threshold',fill: false },
                        { data: [10, 10,10,10,10,10,10], label: 'Min Warning',fill: false }];
  }

  GetChartData(chartData){
    for(let i=0;i<chartData.length;i++)
    {
      //debugger;
    this.lineChartLabels.push(chartData[i].partname);
    this.lineChartData[0].data.push(chartData[i].effectivemotorlifeconsumption);
    this.lineChartData[0].data.push(chartData[i].effectivemotorlifeconsumption);
    //For Min Critical
    this.lineChartData[1].data.push(chartData[i].minCritical);
    this.lineChartData[1].data.push(chartData[i].minCritical);
    //For Min Threshold
    this.lineChartData[1].data.push(chartData[i].minThreshold);
    this.lineChartData[1].data.push(chartData[i].minThreshold);
    //For Max Critical
    this.lineChartData[1].data.push(chartData[i].maxCritical);
    this.lineChartData[1].data.push(chartData[i].maxCritical);
    //For Max Threshold
    this.lineChartData[1].data.push(chartData[i].maxThreshold);
    this.lineChartData[1].data.push(chartData[i].maxThreshold);
    
    }
  }

  public Forecast(){
    this.router.navigate(['/forecast']);
  }

  openDialog(): void {
    const dialogRef = this.dialog.open(MotorConditionCustomPopup, {
      //width: '350px',
      data: {customDate: this.customDate, customTime: this.customTime, DurationTime:this.DurationTime}
    });

    dialogRef.afterClosed().subscribe(result => {
      debugger;
      if(result){
      this.customDate = result.customDate;
      this.customTime = result.customTime;
      this.DurationTime= result.customDuration;
      console.log(this.DurationTime,this.customDate);
      }
      else 
      {

      }
    });    
  }
 
}


  @Component({
    selector: 'motor-condition-custom-popup',
    templateUrl: './motor-condition-custom-popup.component.html',
    
  })
  export class MotorConditionCustomPopup {
  
    constructor(public dialogRef: MatDialogRef<MotorConditionCustomPopup>,
      @Inject(MAT_DIALOG_DATA) public data: DialogData) {
        data.customDate=new Date();
data.customDuration='hour';
      }
  
    onNoClick(): void {
      this.dialogRef.close();
    }
    onOKClick(): void{

    }
  
  }


