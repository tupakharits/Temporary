import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { utilityservice } from '../utility.service';
import { MotorService } from  '../motor.service';
import { conditionallyCreateMapObjectLiteral } from '@angular/compiler/src/render3/view/util';
import { getLocaleDateTimeFormat } from '@angular/common';
import { utils } from 'protractor';
//import {MotorName} from  './app-routing.module'; 

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  constructor(private _router: Router,private route:ActivatedRoute,private util:utilityservice,private motorService:MotorService) { 
    this.util.displayNoSignUp=true;
    this.getDetails();
  }
  mototDetails:any;
  NoOfMotors:number=0;
  greenmotors:number=0;
  AmberMotors:number=0;
  RedMotors:number=0;
  PowerConsumptionTime:string= '18-11-2019';
  EnergyConsumptionTime:string='18-11-2019';
  ActiveAlert:number=0;
  HistoricalAlert:number=0;s

getDetails()
{
  debugger;
  this.motorService.getMotorDetails()
      .subscribe((data: any):void =>{ this.mototDetails = data;
        this.util.MotorDetails=data;
                //console.info(data+"Als");
                if(this.mototDetails){
               this.NoOfMotors=this.mototDetails.length;
               for(let i=0;i<this.mototDetails.length;i++)
               {
                 if(this.mototDetails[i].motorstatus=='R'){
                 this.RedMotors++;this.mototDetails[i].motorstatus='Red';}
                 else if(this.mototDetails[i].motorstatus=='G'){
                 this.greenmotors++;this.mototDetails[i].motorstatus='Green';}
                 else if(this.mototDetails[i].motorstatus=='A'){
                 this.AmberMotors++;this.mototDetails[i].motorstatus='Orange';}
                }
                this.GetChartData(this.mototDetails);
              }                        
              });
      }

  ngOnInit() {
  }
  
  //Motor Power Consumption Chart
  public PowerConsumptionChartLabels:string[] = [];
  public PowerConsumptionChart:any[] = [{data:[]}];
  public PowerConsumptionChartType:string = 'bar';
  public PowerConsumptionChartcolours: Array < any > = [{
    backgroundColor:[],// [ '#225de7', '#4fd8de','#4fd8de','#4fd8de','#4fd8de','#d12a56'],
    borderColor: ['rgba(135,206,250,1)', 'rgba(106,90,205,1)', 'rgba(148,159,177,1)']}];
    private  PowerConsumptionChartOptions: any = {
      legend: { 
        display:false, // to hide labels
        position:'bottom' },
      scales: {
          xAxes: [{
              barPercentage: 0.5
          }],
        yAxes: [{
            ticks: {
                beginAtZero: true
            }
        }]
      }
      }

    //Motor Life Consumption chart
    public LifeConsumptionChartLabels:string[] = [];
    public LifeConsumptionChart:any[] = [{data:[],label:"Motors"}];
    public LifeConsumptionChartType:string = 'bar';
    public LifeConsumptionChartcolours: Array < any > = [{
      backgroundColor: [],//[ '#225de7', '#4fd8de','#4fd8de','#4fd8de','#4fd8de','#d12a56'],
      borderColor: ['rgba(135,206,250,1)', 'rgba(106,90,205,1)', 'rgba(148,159,177,1)']}];
      private  LifeConsumptionChartOptions: any = {
        legend: { display:false,position:'bottom' },
        scales: {
            xAxes: [{
                barPercentage: 0.5
            }],
          yAxes: [{
              ticks: {
                  beginAtZero: true
              }
          }]
        }
        }

  // events
  public chartClicked(points,e:any):void {
    //console.log(points.active[0]._view.label);
    this.util.motorName=points.active[0]._view.label.toString();
    this._router.navigate(['/MotorCondition']);
  }
  public LifeConsumptionChartClicked(points,e:any):void {
    //console.log(points.active[0]._view.label);
    this.util.motorName=points.active[0]._view.label.toString();
    this._router.navigate(['/MotorCondition']);  
    //navigate to next page
  }
 
  public chartHovered(e:any):void {
  // console.log("Mouse hover");
  }
  GetChartData(chartData){
    for(let i=0;i<chartData.length;i++)
    {
      debugger;
    this.LifeConsumptionChartLabels.push(chartData[i].partname);
    this.LifeConsumptionChart[0].data.push(chartData[i].effectivemotorlifeconsumption);
    this.LifeConsumptionChartcolours[0].backgroundColor.push(this.mototDetails[i].motorstatus);
    this.PowerConsumptionChartLabels.push(chartData[i].partname);
    this.PowerConsumptionChart[0].data.push(chartData[i].avgmotorloadingpercent);
    this.PowerConsumptionChartcolours[0].backgroundColor.push(this.mototDetails[i].motorstatus);
    }
  }
}
