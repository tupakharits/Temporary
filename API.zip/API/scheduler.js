const aws = require('aws-sdk')
const { Client } = require('pg')
const dotenv_1 = require("dotenv");
const path_1 = require("path");
dotenv_1.config({ path: path_1.resolve(__dirname, "configs.env") });
console.log(process.env.DB_URL)

//KMS Component
var kms = new aws.KMS({
  accessKeyId: 'AKIAQ4BG2TDI2QTS4UUF',
  secretAccessKey: '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',
  region: 'us-east-2',
httpOptions: {
        connectTimeout: 10 * 1000,
        timeout: 10 * 1000 /* msec */
    }
});

const params = {
    CiphertextBlob: Buffer.from(process.env.DB_URL, 'base64')
  }
  
let result;
let DecryptedString;

exports.handler = async (event) => {
    
  var eventMessage = JSON.parse(JSON.stringify(event));
  var cronMessage = eventMessage.duration;
  console.log('CRON Message Value :' + cronMessage);

  //Decryption
  try {
    const Decrypted = await kms.decrypt(params).promise();
    DecryptedString = Decrypted.Plaintext.toString('utf-8');
  }
  catch (exception) {
    console.log(exception)
  }
  const queryText = `SELECT Fn_dashboardsummary(); SELECT fn_setAlerts()`;

  const queryTENMinuteFunction = `SELECT Fn_parametersummary()`;
  const queryHourlyMinuteFunction = `SELECT Fn_parametersummarydaily()`;

  const client = new Client({
    connectionString: DecryptedString
});


function MinuteCall()
{
  client.query(queryText)
            .then(result => console.log('Ran the Fn_dashboardsummary() and fn_setAlerts() function')) 
             .catch(e => console.error(e.stack)) 
              .then(() => client.end())
  return result
}

function TenMinuteCall()
{
    client.query(queryTENMinuteFunction)
            .then(result => console.log('Ran the Fn_parametersummary() function')) 
             .catch(e => console.error(e.stack)) 
              .then(() => client.end())
    return result
}


function HourCall()
{

  client.query(queryHourlyMinuteFunction)
            .then(result => console.log('Ran the Fn_parametersummarydaily() function')) 
             .catch(e => console.error(e.stack)) 
              .then(() => client.end())
  return result
}

//DB Client
await client.connect();

// switch (cronMessage) {
//   case '1m':
//     client.query(queryText)
//             .then(result => console.log('Ran the Fn_dashboardsummary() and fn_setAlerts() function')) 
//              .catch(e => console.error(e.stack)) 
//               .then(() => client.end())
//     break;
//   case '10m':
//     client.query(queryTENMinuteFunction)
//             .then(result => console.log('Ran the Fn_parametersummary() function')) 
//              .catch(e => console.error(e.stack)) 
//               .then(() => client.end())
//     break;
//   case '1hr':
//     client.query(queryHourlyMinuteFunction)
//             .then(result => console.log('Ran the Fn_parametersummarydaily() function')) 
//              .catch(e => console.error(e.stack)) 
//               .then(() => client.end())
// } 



  setInterval(MinuteCall, 60000);
  setInterval(TenMinuteCall, 600000);
  setInterval(HourCall, (60000*60));

    //return result;
}
