import { Component } from '@angular/core';

import { TranslateService } from '@ngx-translate/core';
import { MotorService } from './_Services/motor.service';
import { utilityservice } from './_Services/utility.service';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AlertService, AuthenticationService } from './_Services'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'AvioAeroApp';
  Lang;
  public Languages:string[]=['English','Italian'];
  constructor(public translate:TranslateService,private MotorService:MotorService, 
    private util:utilityservice, private router: Router,private authenticationService: AuthenticationService){
 
    translate.addLangs(['en-US', 'it-CH']);
    translate.setDefaultLang('en-US');
    this.Lang="English";
    const browserLang=translate.getBrowserLang();
   
    translate.use(browserLang.match(/en-US|it-CH/) ? browserLang:'en-US')
  }
  onlogOut()
{
 
  this.util.displayNoSignUp=false;

  this.authenticationService.serviceLogout().subscribe((res)=>{
    console.log(res);
    this.router.navigate(['/']);
  });
}
changeLang(language: string) {
    this.Lang=language;
    if(language=='English')
        this.translate.use('/en-US');
    else
        this.translate.use('/it-CH');
  }
}

