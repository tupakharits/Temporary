import { Component, OnInit } from '@angular/core';
import { MotorService } from  '../motor.service';
import {MatCardModule} from '@angular/material/card';
import { utilityservice } from '../utility.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  //displayNoSignUp=true;
  public motordata:any;
  public PlantName:string="";
  public PlantCity:string="";
  public NoOfMotors:string="";
  public ActiveAlerts="";
  public machinename="";
  StatusColor:string='';

  constructor(private _router: Router,private util:utilityservice, private motorService:MotorService) {
    this.util.displayNoSignUp=true;
    this.ShowConfig();
   }

  ngOnInit() {
    
  }

  ShowConfig() {  
    
    this.motorService.getHomeDetails()
      .subscribe((data: any):void =>{ this.motordata = data;
                console.info(data+"Als");
                if(this.motordata ){
                  this.util.MotorDetails=this.motordata;
                this.NoOfMotors=this.motordata[0].numberofmotors;
                this.ActiveAlerts=this.motordata[0].activealerts;
                this.PlantName=this.motordata[0].plantname;
                this.PlantCity=this.motordata[0].locationname;
                this.machinename=this.motordata[0].machinename;
                if(this.motordata[0].overallstatus=='G')
                this.StatusColor='Green';
                }
              });
      }
      OpenDashboard()
      {
        this._router.navigate(['/Dashboard']);
      }

}
