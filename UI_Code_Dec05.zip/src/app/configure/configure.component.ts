import {Component, OnInit, ViewChild} from '@angular/core';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {COMMA, ENTER} from '@angular/cdk/keycodes';
import {MatChipInputEvent} from '@angular/material';
import { utilityservice } from '../utility.service';
import {MotorService} from '../motor.service';
import { MotorConditionComponent } from '../motor-condition/motor-condition.component';

export interface PeriodicElement { 
  MotorName: string;
  MinCritical: string;
  MaxCritical: string;
  MinWarning:string;
  MaxWarning:string;
}
export interface EmailIds {
  name: string;
}
const ELEMENT_DATA: PeriodicElement[] = [
  // {MotorName: 'X-Axis',  MinCritical: '',MaxCritical: '',MinWarning:'',MaxWarning:''},
  // {MotorName: 'Z-Axis',  MinCritical: '',MaxCritical: '',MinWarning:'',MaxWarning:''},
  // {MotorName: 'C-Axis',  MinCritical: '',MaxCritical: '',MinWarning:'',MaxWarning:''},
  // {MotorName: 'C2-Axis',  MinCritical: '',MaxCritical: '',MinWarning:'',MaxWarning:''},
  // {MotorName: 'TT1-Axis',  MinCritical: '',MaxCritical: '',MinWarning:'',MaxWarning:''},
  // {MotorName: 'TT2-Axis',  MinCritical: '',MaxCritical: '',MinWarning:'',MaxWarning:''},
  
];

@Component({
  selector: 'app-configure',
  templateUrl: './configure.component.html',
  styleUrls: ['./configure.component.scss']
})

export class ConfigureComponent implements OnInit {
  displayedColumns: string[] = ['MotorName','MinCritical',  'MaxCritical', 'MinWarning','MaxWarning'];
  dataSource = new MatTableDataSource(ELEMENT_DATA);
  //public ELEMENT_DATA:any[]=[];
  Configdata:any;
  //dataSource :any[]=[];
  states: string[] = [
    'Power','Current','Motor Loading%'
   ];
   Motors:string[]=['X-Motor','Z-Motor','C-Motor','C2-Motor','LP1-Motor','LP2-Motor' ];
   public name:string = '';
   fieldArray: Array<any> = [
   
  ];
  newAttribute: any = {};
ParamSelect:string='MotorPower';
  firstField = true;
  firstFieldName = 'First Item name';
  isEditItems: boolean;
  Emails:string='';
  Email:string='';
  constructor(private util:utilityservice, private motorService:MotorService) {
    this.util.displayNoSignUp=true;
   }
  @ViewChild(MatSort, {static: true}) sort: MatSort;

  ShowConfig(){
    this.motorService.getMotorDetails().subscribe((data:any):void => {
      this.Motors=data;
    });
    
    var param={"MotorFactor": this.ParamSelect}
    this.motorService.getConfigureDetails(param).subscribe((data:any):void => {
      this.Configdata=data;
      this.dataSource=this.Configdata["MotorThreshold"];
      (data) => {
        this.dataSource=this.Configdata["MotorThreshold"];
        //this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      }
    });

  }
  ngOnInit() {    
   
   // this.dataSource.sort = this.sort;
    this.ShowConfig();
  }
  addFieldValue(value) {
      this.emailids.push({name : value});
  }

  onEditCloseItems() {
    this.isEditItems = !this.isEditItems;
  }

  changeParameter(parameter){
   
this.ParamSelect=parameter;
this.ShowConfig();
console.log(parameter);
  }

  // angular email chips
  visible = true;
  selectable = true;
  removable = true;
  addOnBlur = true;
  readonly separatorKeysCodes: number[] = [ENTER, COMMA];
  emailids: EmailIds[] = [
    {name: 'test@avioaero.it'},
    {name: 'test1@avioaero.it'},
    {name: 'test2@avioaero.it'},
  ];

  add(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;

    // Add our fruit
    if ((value || '').trim()) {
      this.emailids.push({name: value.trim()});
    }

    // Reset the input value
    if (input) {
      input.value = '';
    }
  }

  remove(emailid: EmailIds): void {
    const index = this.emailids.indexOf(emailid);

    if (index >= 0) {
      this.emailids.splice(index, 1);
    }
  }

}
