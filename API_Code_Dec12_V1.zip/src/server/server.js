//import CreateApp from './app';
//import logger from '../logger';
const express= require('express');
const router = require('./routes/api/index');
// const cors = require('cors');
// console.log(process.env.PORT);
const port = process.env.PORT || 3000;
const app = express();

const clientID = 'CBM_AVIO_AERO';
const clientSecret = '5$9AGMbwcrF$W5IHDy@Lh$Vy9qRgihBElUcO9ZHwtNpXUZMW70nRRQJuE9JLlzRW;';


  const oauth2 = require('simple-oauth2').create({
    client: {
      id: clientID,
      secret: clientSecret,
    },
    auth: {
      tokenHost: 'https://cbm.avio.net/',
      tokenPath: 'https://fssfed.ge.com/fss/as/token.oauth2',
      authorizePath: 'https://fssfed.ge.com/fss/as/authorization.oauth2',
    },
  });

  // Authorization uri definition
  const authorizationUri = oauth2.authorizationCode.authorizeURL({
   // redirect_uri: 'http://localhost:3000/callback',
     redirect_uri: 'http://my-alb-1885598496.us-east-2.elb.amazonaws.com',
    scope: '',
    state: '3(#0/!~',
  });

  // Initial page redirecting to GE
  app.get('/auth', (req, res) => {
    console.log(authorizationUri);
     res.redirect(authorizationUri);
    //return 'true';
  });

  // Callback service parsing the authorization token and asking for the access token
  app.get('/callback', async (req, res) => {
    const { code } = req.query;
    const options = {
      code,
    };

    try {
      const result = await oauth2.authorizationCode.getToken(options);
      // debugger;
      console.log('The resulting token: ', result);

      const token = oauth2.accessToken.create(result);

      return res.status(200).json(token);
    } catch (error) {
      console.error('Access Token Error', error.message);
      return res.status(500).json('Authentication failed');
    }
  });

  app.get('/', (req, res) => {
    //console.log(window.location);
   // res.redirect(authorizationUri);
    res.send('Hello<br><a href="/auth">Log in with GE</a>');
  });


//app.listen(port, () => {
    // logger.debug(`server running on port ${port}`);
    // console.log(`server running on port ${port}`)
//});​

app.listen(port, () => {
  console.log('Server is Running on Port : '+port);
});