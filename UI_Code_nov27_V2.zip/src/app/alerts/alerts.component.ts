import {Component, ViewChild} from '@angular/core';
import {MatPaginator, MatSort, MatTableDataSource} from '@angular/material';
import { utilityservice } from '../utility.service';

@Component({
  selector: 'app-alerts',
  templateUrl: './alerts.component.html',
  styleUrls: ['./alerts.component.scss']
})

export class AlertsComponent {
  displayedColumns = ['id', 'progress','name',  'color','Alert_Description','Date_Time','Criticality','Status','Date_time_if_closed','Remarks'];
  dataSource: MatTableDataSource<UserData>;
 //@ViewChild(MatPaginator) paginator: MatPaginator;
  //@ViewChild(MatSort) sort: MatSort;

  constructor(private util:utilityservice) {
    this.util.displayNoSignUp=true;
    // Create 100 users
    const users: UserData[] = [];
   // for (let i = 1; i <= 100; i++) { users.push()); }

    // Assign the data to the data source for the table to render
    this.dataSource = new MatTableDataSource(users);
  }

  /**
   * Set the paginator and sort after the view init since this component will
   * be able to query its view for the initialized paginator and sort.
   */
  ngAfterViewInit() {
   // this.dataSource.paginator = this.paginator;
   // this.dataSource.sort = this.sort;
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }
}

/** Builds and returns a new User. */
// function createNewUser(id: number): UserData {
//   const name =
//       NAMES[Math.round(Math.random() * (NAMES.length - 1))] + ' ' +
//       NAMES[Math.round(Math.random() * (NAMES.length - 1))].charAt(0) + '.';}

/** Constants used to fill up our data base. */
const COLORS = [];
const NAMES = ['', '', '', '', '', '',
  '', '', '', '', '', '',
  '', '', '', '', '', '', ''];

export interface UserData {
  id: string;
  name: string;
  progress: string;
  color: string;
  Alert_Description:string;
  Date_Time:string;
  Criticality:string;
  Status:string;
  Date_time_if_closed:string;
  Remarks:string;
}