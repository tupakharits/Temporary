import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { utilityservice } from '../utility.service';
//import {MotorName} from  './app-routing.module'; 

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  constructor(private _router: Router,private route:ActivatedRoute,private util:utilityservice) { 
    this.util.displayNoSignUp=true;
  }

  ngOnInit() {
  }
  //Motor Power Consumption Chart
  public PowerConsumptionChartLabels:string[] = ['X Axis', 'Z-Axis','C1','C2','Tum Table1', 'Tum Table 2'];
  public PowerConsumptionChart:any[] = [{data:[85, 30, 45,5,3,120],label:"Motors"}];
  public PowerConsumptionChartType:string = 'bar';
  public PowerConsumptionChartcolours: Array < any > = [{
    backgroundColor: [ 'orange', 'blue','blue','blue','blue','maroon'],
    borderColor: ['rgba(135,206,250,1)', 'rgba(106,90,205,1)', 'rgba(148,159,177,1)']}];
    private  PowerConsumptionChartOptions: any = {
      legend: { position:'bottom' },
      scales: {
          xAxes: [{
              barPercentage: 0.5
          }],
        yAxes: [{
            ticks: {
                beginAtZero: true
            }
        }]
      }
      }

    //Motor Life Consumption chart
    public LifeConsumptionChartLabels:string[] = ['X Axis', 'Z-Axis','C1','C2','Tum Table1', 'Tum Table 2'];
    public LifeConsumptionChart:number[] = [2555, 2920, 4380,5475,730,1095];
    public LifeConsumptionChartType:string = 'bar';
    public LifeConsumptionChartcolours: Array < any > = [{
      backgroundColor: [ 'orange', 'blue','blue','blue','blue','maroon'],
      borderColor: ['rgba(135,206,250,1)', 'rgba(106,90,205,1)', 'rgba(148,159,177,1)']}];
      private  LifeConsumptionChartOptions: any = {
        legend: { position:'bottom' },
        scales: {
            xAxes: [{
                barPercentage: 0.5
            }],
          yAxes: [{
              ticks: {
                  beginAtZero: true
              }
          }]
        }
        }

  // events
  public chartClicked(points,e:any):void {
    console.log(points.active[0]._view.label);
    this.util.motorName=points.active[0]._view.label.toString();
    //this._router.navigate(['/MotorCondition']);
  }
  public LifeConsumptionChartClicked(points,e:any):void {
    console.log(points.active[0]._view.label);
    this.util.motorName=points.active[0]._view.label.toString();
    this._router.navigate(['/MotorCondition']);  
    //navigate to next page
  }
 
  public chartHovered(e:any):void {
   // console.log(e);
  }
}
