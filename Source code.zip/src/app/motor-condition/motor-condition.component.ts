import { Component, OnInit } from '@angular/core';
import { ChartDataSets, ChartOptions } from 'chart.js';
import { Color, Label } from 'ng2-charts';
import { ActivatedRoute, Router } from '@angular/router';
import { MotorService } from  '../motor.service';
import { utilityservice } from '../utility.service';

@Component({
  selector: 'app-motor-condition',
  templateUrl: './motor-condition.component.html',
  styleUrls: ['./motor-condition.component.scss']
})

export class MotorConditionComponent implements OnInit {
 
  public lineChartData: ChartDataSets[] = [
    { data: [45, 56, 80, 81, 56, 55, 40], label: 'Power' },
    { data: [85, 85, 85, 85, 85,85, 85], label: 'Threshold' },
    { data: [100, 100,100,100,100,100,100], label: 'Warning' }
  ];
 
  public motordata:any;
  public Chart_selected:string='Power';
  public lineChartLabels: Label[] = ['12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00'];
  // public lineChartOptions: (ChartOptions & { annotation: any }) = {
  //   responsive: true,
  // };
  public lineChartColors: Color[] = [
    {      borderColor: 'blue',
    // backgroundColor: 'rgba(255,0,0,0.3)',
    },
    // {borderColor: 'purple',},
    // {borderColor: 'darkblue',},
    {borderColor: 'Orange',},
    {borderColor: 'red',},
  ];
  private  lineChartOptions: any = {
    legend: { position:'bottom' },
    scales: {
      yAxes: [{
          ticks: {
              beginAtZero: true
          }
      }]
    }
    }
  public lineChartLegend = true;
  public lineChartType = 'line';
  public lineChartPlugins = [];
  public MotorName:string='Xmotor';

  constructor(private route:ActivatedRoute, private router:Router,private MotorService:MotorService,private util:utilityservice) {
    //debugger;
    //console.log(route.snapshot.data['p1']);
    if(route.snapshot.data["p1"]!=undefined)
        this.MotorName=route.snapshot.data['p1'];
    this.util.displayNoSignUp=true;
    this.MotorName=this.util.motorName;
    
}

  ngOnInit() {
       
    this.showConfig();
  }

  showConfig() {  
    debugger;
    this.MotorService.getAll().subscribe((data) => {
      console.log(data);
    });

    // this.MotorService.getConfig()
    //   .subscribe((data: any):void =>{ this.motordata = data;
    //             console.info(data+"Als");});
      
      console.log(this.motordata+"Alekhya" );
      //  {
      //     heroesUrl: data['heroesUrl'],
      //     textfile:  data['textfile']
      // });
  }

  public ChangeMotor(Motor_name){
        this.MotorName=Motor_name;
        this.util.motorName=Motor_name;
  }
  public changeChart(Chart_data){
    this.Chart_selected=Chart_data;
    debugger;
    if(Chart_data=='Power')
    this.lineChartData=[{ data: [35, 59, 90, 81, 76, 65, 70], label: Chart_data },
                        { data: [85, 85, 85, 85, 85,85, 85], label: 'Threshold' },
                        { data: [100, 100,100,100,100,100,100], label: 'Warning' }];
    else if(Chart_data=='Current')
    this.lineChartData=[{ data: [70, 70, 85, 81, 70,78, 60], label: Chart_data },
                        { data: [85, 85, 85, 85, 85,85, 85], label: 'Threshold' },
                         { data: [100, 100,100,100,100,100,100], label: 'Warning' }];
    else if(Chart_data=='MotorLoading%')
    this.lineChartData=[{ data: [35, 59, 90, 81, 76, 65, 70], label: Chart_data },
                        { data: [85, 85, 85, 85, 85,85, 85], label: 'Threshold' },
                        { data: [100, 100,100,100,100,100,100], label: 'Warning' }];
  }
  public Forecast(){
    this.router.navigate(['/forecast']);
  }
}
