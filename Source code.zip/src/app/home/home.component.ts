import { Component, OnInit } from '@angular/core';
import { MotorService } from  '../motor.service';
import {MatCardModule} from '@angular/material/card';
import { utilityservice } from '../utility.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  //displayNoSignUp=true;
  public motordata:any;
  public PlantName:string="PlantCity";
  public PlantCity:string="PlantName";
  public NoOfMotors:string="";
  public ActiveAlerts="";
  constructor(private util:utilityservice, private motorService:MotorService) {
    this.util.displayNoSignUp=true;
    this.ShowConfig();
   }

  ngOnInit() {
    
  }

  ShowConfig() {  
    debugger;
    this.motorService.getHomeDetails()
      .subscribe((data: any):void =>{ this.motordata = data;
                console.info(data+"Als");
                if(this.motordata){
                this.NoOfMotors=this.motordata.Home.NoOfMotors;
                this.ActiveAlerts=this.motordata.Home.ActiveAlerts;
                this.PlantName=this.motordata.Home.PlantName;
                this.PlantCity=this.motordata.Home.PlantCity;
                }
              });
      }

}
