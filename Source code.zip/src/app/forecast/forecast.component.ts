import { Component, OnInit } from '@angular/core';
import { ChartDataSets, ChartOptions } from 'chart.js';
import { Color, Label } from 'ng2-charts';
import { utilityservice } from '../utility.service';

@Component({
  selector: 'app-forecast',
  templateUrl: './forecast.component.html',
  styleUrls: ['./forecast.component.scss']
})
export class ForecastComponent implements OnInit {

  constructor(private util:utilityservice) { 
    this.util.displayNoSignUp=true;
  }
public MotorName:string='X- Motor';
public Chart_selected:string='Power';
public PerformanceTimeLineChart: ChartDataSets[] = [
  { data: [45, 56, 80, 81, 56, 55, 70], label: 'Power' },
   { data: [,, ,,,,70,80], label: 'PowerForecast' },
  // { data: [35, 59, 90, 81, 76, 65, 70], label: 'Current' },
 // { data: [, , , , ,, 70,80], label: 'Current Forecast' },
  // { data: [70, 70, 90, 81, 70,78, 60], label: 'Power factor' },
  // { data: [, , , , ,, 60,75], label: 'Power factor Forecast' },
  { data: [85, 85, 85, 85, 85,85, 85,85], label: 'Threshold' },
  { data: [100, 100,100,100,100,100,100,100], label: 'Warning' }
];
public PerformanceTimeLineChartLabels: Label[] = ['12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00','19:00'];
// public lineChartOptions: (ChartOptions & { annotation: any }) = {
//   responsive: true,
// };
private  PerformanceTimeLineOptions: any = {
  legend: { position: 'right' },
  scales: {
    yAxes: [{
        ticks: {
            beginAtZero: true
        }
    }]
  }
}
public PerformanceTimeLineChartColors: Color[] = [
  {
    borderColor: 'blue',
  // backgroundColor: 'rgba(255,0,0,0.3)',
  },
  {
    borderColor: 'grey',
  },
  {
    borderColor: 'purple',  
  },
  {
    borderColor: 'grey',
  },
  {
    borderColor: 'violet',
  },
  {
    borderColor: 'grey',
  },
  {
    borderColor: 'Orange',
  },
  {
    borderColor: 'red',
  },
];
public PerformanceTimeLineChartLegend = true;
public PerformanceTimeLineChartType = 'line';
public PerformanceTimeLineChartPlugins = [];


  ngOnInit() {
  }
  public ChangeMotor(Motor_name){
   
    this.MotorName=Motor_name;

  }
  public changeChart(Chart_data){
    this.Chart_selected=Chart_data;
    debugger;
    if(Chart_data=='Power')
    this.PerformanceTimeLineChart=[ { data: [45, 56, 80, 81, 56, 55, 70], label: Chart_data },
                        { data: [,, ,,,,70,80], label: 'PowerForecast' },
                        { data: [85, 85, 85, 85, 85,85, 85], label: 'Threshold' },
                        { data: [100, 100,100,100,100,100,100], label: 'Warning' }];
    else if(Chart_data=='Current')
    this.PerformanceTimeLineChart=[ { data: [35, 59, 90, 81, 76, 65, 70], label: Chart_data },
                         { data: [, , , , ,, 70,80], label: 'Current Forecast' },
                        { data: [85, 85, 85, 85, 85,85, 85,85], label: 'Threshold' },
                         { data: [100, 100,100,100,100,100,100,100], label: 'Warning' }];
    else if(Chart_data=='MotorLoading%')
    this.PerformanceTimeLineChart=[{ data: [70, 70, 90, 81, 70,78, 80], label: Chart_data },
                        { data: [, , , , ,, 80,85], label: 'Power factor Forecast' },
                        { data: [85, 85, 85, 85, 85,85, 85,85], label: 'Threshold' },
                        { data: [100, 100,100,100,100,100,100,100], label: 'Warning' }];
  }
}
