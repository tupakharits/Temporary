import { Component, OnInit,Input, Output, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators,FormControl } from '@angular/forms';
import { first } from 'rxjs/operators';
import { AlertService } from  '../_Services/alert.service';
import { AuthenticationService} from  '../_Services/Authentication.service';
import { utilityservice } from '../_Services/utility.service';
import { invalid } from '@angular/compiler/src/render3/view/util';
import { tokenName } from '@angular/compiler';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit{
  //loginForm: FormGroup;
  //displayNoSignUp=true;
  //api/V1/auth/login
  Invalid:boolean=false;
  loading = false;
  submitted = false;
  returnUrl: string;
  BaseURL=window.location.origin+"/login";
  loginForm: FormGroup = new FormGroup({
    username: new FormControl(),
    password: new FormControl(),
  });

  constructor( private formBuilder: FormBuilder,private util:utilityservice,
    private route: ActivatedRoute,
    private router: Router,
    private authenticationService: AuthenticationService,
    private alertService: AlertService){
      if (this.authenticationService.currentUserValue) {          
        this.router.navigate(['/']);
    }
  }
  ngOnInit() {
    this.loginForm = this.formBuilder.group({
        username: ['', Validators.required],
        password: ['', Validators.required]
    });
    // get return url from route parameters or default to '/'
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
   
}
 // convenience getter for easy access to form fields
 get f() { return this.loginForm.controls; }

  submit() {
    this.submitted = true;
    if (this.loginForm.invalid) {
      this.Invalid=true;
      return;
      //this.submitEM.emit(this.loginForm.value);
    }
    this.Invalid=false;
    this.loading = true;
   
        this.authenticationService.login(this.f.username.value, this.f.password.value)
            .pipe(first())
            .subscribe(
                data => {
                  this.util.displayNoSignUp=true;
                    this.router.navigate(['/Home']);
                    
                },
                error => {
                    this.alertService.error(error);
                    this.loading = false;
                });
    }
  }
  // @Input() error: string | null;

//  @Output() submitEM = new EventEmitter();

