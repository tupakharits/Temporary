import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap, map } from 'rxjs/operators';
import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
  })

  export class TempService {
      constructor(private httpClient: HttpClient) {}
      getMotorFactorDetails(params): Observable<any[]> {
        const headeroptions={
          headers:new HttpHeaders({'Content-Type': 'application/json'})
        }
       // var url=this.APIurl+'/api/v1/motorcondition';       
        var url='assets/motorconditionsample.json;'
        // return this.httpClient.post(url,params ,headeroptions)
        // .pipe(map((data: any) => data));
        return this.httpClient.get(url)
        .pipe(map((data: any) => data));
        
      }
  }