import express from 'express';
import routes from './routes';
import bodyParser from 'body-parser';
import compression from 'compression';
import helmet from 'helmet'

const createApp = () => {    
    const app = express();   
    app.use(helmet());
    app.use(compression());
    app.use(bodyParser.json());
    app.use(bodyParser.urlencoded({ extended: true }));
    routes(app);
    return app;
}

export default createApp;
