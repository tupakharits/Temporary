import express from 'express';
import Parser from './parser/parser';
import MachineSummary from './machine/machine';
import ModuleSummary from './module/module';
import PartsSummary from './part/parts';
import User from './user/user';
import cors from "cors";


const app = express();
const router = express.Router();

//var corsOptions = {
   // origin: 'http://my-alb-1885598496.us-east-2.elb.amazonaws.com/',
   // methods: "GET,HEAD,OPTIONS,PUT,PATCH,POST,DELETE",
    // allowedHeaders: ["Origin", "X-Requested-With", "Content-Type", "Accept", "X-Access-Token"],
    // credentials: false,
    // preflightContinue: false
 // }

const options: cors.CorsOptions = {
    allowedHeaders: ["Origin", "X-Requested-With", "Content-Type", "Accept", "X-Access-Token"],   
    methods: "GET,HEAD,OPTIONS,PUT,PATCH,POST,DELETE",
    origin: '*',    
    optionsSuccessStatus: 200,
    preflightContinue: false,
     //credentials: true
}
router.use(cors(options));

router.use('/users', User);
router.use('/parser', Parser);
router.use('/machine', MachineSummary);
router.use('/module', ModuleSummary);
router.use('/parts', PartsSummary);

router.options("*",cors(options))

export default router;