import { Component, OnInit } from '@angular/core';
import { MotorService } from  '../motor.service';
//import {MatCardModule} from '@angular/material/card';
import { utilityservice } from '../utility.service';
import { Router } from '@angular/router';
import { NgxSpinnerService } from "ngx-spinner"; 
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  //displayNoSignUp=true;
  public motordata:any;
  public PlantName:string="";
  public PlantCity:string="";
  public NoOfMotors:string="";
  public ActiveAlerts="0";
  public machinename="";
  StatusColor:string='';
  public DbConnectionFail=false;

  constructor(private _router: Router,private util:utilityservice, private motorService:MotorService,
    private SpinnerService: NgxSpinnerService ) {
    this.util.displayNoSignUp=true;
    this.ShowConfig();
   }

  ngOnInit() {
    
  }

  ShowConfig() {  
    this.SpinnerService.show();
    this.motorService.getHomeDetails().subscribe(
      resultArray => {
        this.DbConnectionFail=false;
        this.motordata = resultArray;
        if(this.motordata ){
                        this.util.MotorDetails=this.motordata;
                      this.NoOfMotors=this.motordata[0].numberofmotors;
                      if(this.motordata[0].activealerts!=null)this.ActiveAlerts=this.motordata[0].activealerts;
                      this.PlantName=this.motordata[0].plantname;
                      this.PlantCity=this.motordata[0].locationname;
                      this.machinename=this.motordata[0].machinename;
                      if(this.motordata[0].overallstatus=='G')
                      this.StatusColor='Green';
                      else if(this.motordata[0].overallstatus=='A')
                      this.StatusColor='Orange';
                      else if(this.motordata[0].overallstatus=='R')
                      this.StatusColor='Red';
                      else
                      this.StatusColor='Grey';}
                      this.SpinnerService.hide();
        if(resultArray[0].status ===200){        
         // console.log("error"); 
        }
      },
      error =>{ 
        this.DbConnectionFail=true;
        this.SpinnerService.hide();
        console.log("Error :: " + error)})    
      }
      OpenDashboard()
      {
        this._router.navigate(['/Dashboard']);
      }

}
