import { Component, OnInit, Inject } from '@angular/core';
import { ChartDataSets, ChartOptions } from 'chart.js';
import { Color, Label } from 'ng2-charts';
import { ActivatedRoute, Router } from '@angular/router';
import { MotorService } from  '../motor.service';
import { utilityservice } from '../utility.service';

import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';

import { debug } from 'util';
import { DatePipe } from '@angular/common';
import { MotorName } from '../MotorName';
import { NgxSpinnerService } from 'ngx-spinner';


export interface DialogData {
  customDate: Date;
  customTimemodel: any[];//=[{hour:12,minute:00}];
  customDuration:string;
}

@Component({
  selector: 'app-motor-condition',
  templateUrl: './motor-condition.component.html',
  styleUrls: ['./motor-condition.component.scss']
})

export class MotorConditionComponent implements OnInit {

  customDate:Date;
  //customTime:string;
  DurationTime:string='hour';
  customTimemodel:any;// = [{hour: 13, minute: 30}];
 
  public lineChartData: any[] = [
    { data: [], label: 'Power ',fill: false },
    { data: [], label: 'Max Warning',fill: false },
    { data: [], label: 'Max Critical',fill: false }
    // { data: [], label: 'Min Threshold',fill: false },
    // { data: [], label: 'Min Warning',fill: false }
  ];
  public motordata:any;
  public motorDetails:any[];
  public graphData:any[];
  public motorConditionDetails:any;
  public MotorMake:string='';
  public MotorModel:string='';
  public AssetID:string='';
  public Location:string='';
  public RatedCurrent:string='';
  public Voltage:string='';
  public RatedPower:string='';
  public PowerFactor:string='';
  public  MaxRPM:string='';
  public MinRPM:string='';
  public DateTime_Selected:string=new Date().toString();
  public Duration:string='hour';
  public parameter:string='MotorPower';
  public graphwidth:number=1000;
  public ShowSpinner=true;

  DbConnectionFail=false;

  LineChartInit(customTooltips){
    
    this.lineChartOptions = {
      legend: { position:'bottom' },
      tooltips: {
        enabled: true,
        mode: 'index',
        position: 'nearest',
       // custom: customTooltips,
       callbacks: {
        labelColor: function(tooltipItem, chart) {
            return {
                borderColor: 'rgb(255, 0, 0)',
                backgroundColor: 'rgb(255, 0, 0)'
            };
        },
        //label:function(tooltipItem, chart){ return 'test toolstip';},
        labelTextColor: function(tooltipItem, chart) {
            return '#FFFFFF';
        }
    }
      },
      scales: {
        yAxes: [{
            ticks: {
                beginAtZero: true
            }
        }],
        xAxes: [{
          ticks:{beginAtZero:true}
        }]
      }     
  }
}
  public Chart_selected:string='MotorPower';
  public lineChartLabels: Label[] = [];//'12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00'];
  // public lineChartOptions: (ChartOptions & { annotation: any }) = {
  //   responsive: true,
  // };
  public lineChartColors: Color[] = [
    {borderColor: 'blue'},
    {borderColor: 'Orange',},
    {borderColor: 'red',},
    {borderColor: 'Orange',},
    {borderColor: 'red',},
  ];
  public  lineChartOptions: any = {
       }
  public lineChartLegend = true;
  public lineChartType = 'line';
  public lineChartPlugins = [];
  public MotorName:string='Xmotor';
  public motorstatus:string='Green';

  constructor(private route:ActivatedRoute, private router:Router,private MotorService:MotorService,
    private util:utilityservice, public dialog: MatDialog,private datePipe:DatePipe,private SpinnerService: NgxSpinnerService) {
    if(route.snapshot.data["p1"]!=undefined)
        this.MotorName=route.snapshot.data['p1'];
    this.util.displayNoSignUp=true;
    this.MotorName=this.util.motorName;
    this.motorDetails=this.util.MotorDetails;
    this.DateTime_Selected=this.datePipe.transform(new Date(),'MM/dd/yyyy HH:mm');
}

  ngOnInit() {
    const customTooltips = function(tooltip) {
      // Tooltip Element
      let tooltipEl = document.getElementById('chartjs-tooltip');
      if (!tooltipEl) {
        tooltipEl = document.createElement('div');
        tooltipEl.id = 'chartjs-tooltip';
        tooltipEl.innerHTML = '<table></table>';
        this._chart.canvas.parentNode.appendChild(tooltipEl);
      }
      // Hide if no tooltip
      if (tooltip.opacity === 0) {
        tooltipEl.style.opacity = 0 as any;
        return;
      }
      // Set caret Position
      tooltipEl.classList.remove('above', 'below', 'no-transform');
      if (tooltip.yAlign) {
        tooltipEl.classList.add(tooltip.yAlign);
      } else {
        tooltipEl.classList.add('no-transform');
      }
      function getBody(bodyItem) {
        return bodyItem.lines;
      }
      // Set Text
      //debugger;
      if (tooltip.body) {
        
        const titleLines = tooltip.title || [];
        //const bodyLines = tooltip.body.map(getBody);
        let innerHtml = '<thead>';
        const bodyLines=[['power'],['current']];
        titleLines.forEach(function(title) {
          innerHtml += '<tr><th>' + title + '</th></tr>';
        });
        innerHtml += '</thead><tbody>';
        bodyLines.forEach(function(body, i) {
          const colors = tooltip.labelColors[i];
          let style = 'background:' + colors.backgroundColor;
          style += '; border-color:' + colors.borderColor;
          style += '; border-width: 2px';
          const span = '<span class="chartjs-tooltip-key" style="' +
          style +
          '"></span>';
          innerHtml += '<tr><td>' + span + body+'Alekhya'+ '</td></tr>';
        });
        innerHtml += '</tbody>';
        //console.log(innerHtml);
        const tableRoot = tooltipEl.querySelector('table');
        tableRoot.innerHTML = innerHtml;
        //console.log(tableRoot.innerHTML);
      }
      const positionY = this._chart.canvas.offsetTop;
      const positionX = this._chart.canvas.offsetLeft;
      // Display, position, and set styles for font
      tooltipEl.style.opacity = 1 as any;
      tooltipEl.style.left = positionX + tooltip.caretX + 'px';
      tooltipEl.style.top = positionY + tooltip.caretY + 'px';
      tooltipEl.style.fontFamily = tooltip._bodyFontFamily;
      tooltipEl.style.fontSize = tooltip.bodyFontSize + 'px';
      tooltipEl.style.fontStyle = tooltip._bodyFontStyle;
      tooltipEl.style.padding = tooltip.yPadding +
      'px ' +
      tooltip.xPadding +
      'px';
    };
    this.showConfig();
    this.LineChartInit(customTooltips);
  }

  showConfig() {  

    this.MotorService.getMotorDetails().subscribe((data) =>
     {
      this.motorDetails=data;
      this.DbConnectionFail=false;
      this.DbConnectionFail=false;
      
      this.util.MotorDetails=data;
      for(let i=0;i<this.motorDetails.length;i++)
      {
        if(this.motorDetails[i].motorstatus=='R')
        this.motorDetails[i].motorstatus='Red';
        else if(this.motorDetails[i].motorstatus=='G')
        this.motorDetails[i].motorstatus='Green';
        else if(this.motorDetails[i].motorstatus=='A')
        this.motorDetails[i].motorstatus='Orange';
        else
        this.motorDetails[i].motorstatus='Grey';
        if(this.MotorName==this.motorDetails[i].partname)
        this.motorstatus=this.motorDetails[i].motorstatus;
       }
     
    },error =>{ 
      this.DbConnectionFail=true;
      console.log("Error :: " + error)});
      this.LoadGraphDetails();
  }

  LoadGraphDetails(){       
    this.SpinnerService.show();
 var cetTime = new Date(this.DateTime_Selected).toLocaleString("en-US", {timeZone: "Europe/Paris"});
 cetTime=this.datePipe.transform(new Date(cetTime),'MM-dd-yyyy HH:mm');

    var params = 
    {
      PartName: this.MotorName,
      Parameter:this.Chart_selected,//this.Chart_selected,
      DateTime: cetTime,  //this.DateTime_Selected,
      Duration: this.Duration
    }
    this.MotorService.getMotorFactorDetails(params).subscribe((data) => {
     
      this.motorConditionDetails=data;
      
      this.DbConnectionFail=false;
      if(this.motorConditionDetails){
      this.MotorMake=this.motorConditionDetails.MotorSnapShot.Make;
      this.MotorModel=this.motorConditionDetails.MotorSnapShot.Model;
      this.AssetID=this.motorConditionDetails.MotorSnapShot["Asset Id"];
      this.Location=this.motorConditionDetails.MotorSnapShot.Location;
      this.RatedCurrent=this.motorConditionDetails.MotorSnapShot.Current;
      this.Voltage=this.motorConditionDetails.MotorSnapShot.Voltage;
      this.RatedPower=this.motorConditionDetails.MotorSnapShot.Power;
      this.PowerFactor=this.motorConditionDetails.MotorSnapShot["Power Factor"];
      this.MaxRPM=this.motorConditionDetails.MotorSnapShot["Max RPM"];
      this.MinRPM=this.motorConditionDetails.MotorSnapShot["Min RPM"];
      this.graphData=this.motorConditionDetails.GraphData;
      this.ClearChartData();
      this.LoadChart(this.graphData);
      this.SpinnerService.hide();
}
      //this.motorDetails=data;
      //this.util.MotorDetails=data;
    },error =>{ 
      this.DbConnectionFail=true;
      this.SpinnerService.hide();
      console.log("Error :: " + error)});
  }
public LoadChart(graphdata){
    for(let i=0;i<graphdata.length;i++){
      if(this.graphData[i].DateTime!=null){
    this.lineChartData[0].data.push(this.graphData[i].summaryvalue);//For Power line
    this.lineChartData[1].data.push(this.graphData[i].maxwarning); //For max threshold
    this.lineChartData[2].data.push(this.graphData[i].maxcritical);  //For Warning
    // this.lineChartData[3].data.push(this.graphData[i].minthreshold); // min threshold
    // this.lineChartData[4].data.push(this.graphData[i].mincritical); // min warning
    this.lineChartLabels.push(this.graphData[i].DateTime);
      }
  }
}
public ClearChartData(){
  this.lineChartLabels=[];
  for(let i=0;i<this.lineChartData.length;i++)
  this.lineChartData[i].data=[];
}
  public ChangeMotor(Motor_name){
        this.MotorName=Motor_name;
        this.util.motorName=Motor_name;
        //Call change chart
       // this.changeChart(this.Chart_selected);
        this.LoadGraphDetails();
  }
  public ChangeDuration(Duration){
     this.Duration=Duration;
     if(Duration=='hour'){this.graphwidth=1100;}
     else if(Duration=='day'){this.graphwidth=2000;}
     else if(Duration=='month'){this.graphwidth=5000;}
     this.DateTime_Selected=this.datePipe.transform(new Date(),'MM-dd-yyyy HH:mm');
     
     this.LoadGraphDetails();
  }
  public changeChart(Chart_data){
    if(Chart_data.index==0) //Power
    this.Chart_selected='MotorPower';
    else if(Chart_data.index==1)//Current
    this.Chart_selected='MotorCurrent';
    else if(Chart_data.index==2)//Motor Loading
    this.Chart_selected='MotorLoadingPercentage';

    this.DateTime_Selected=this.datePipe.transform(new Date(),'MM-dd-yyyy HH:mm');
    this.lineChartData[0].label=Chart_data.tab.textLabel;
    this.LoadGraphDetails();
    
  }

  GetChartData(chartData){
    for(let i=0;i<chartData.length;i++)
    {
    this.lineChartLabels.push(chartData[i].partname);
    this.lineChartData[0].data.push(chartData[i].effectivemotorlifeconsumption);
    this.lineChartData[0].data.push(chartData[i].effectivemotorlifeconsumption);
    //For Min Critical
    this.lineChartData[1].data.push(chartData[i].minCritical);
    this.lineChartData[1].data.push(chartData[i].minCritical);
    //For Min Threshold
    this.lineChartData[1].data.push(chartData[i].minThreshold);
    this.lineChartData[1].data.push(chartData[i].minThreshold);
    //For Max Critical
    this.lineChartData[1].data.push(chartData[i].maxCritical);
    this.lineChartData[1].data.push(chartData[i].maxCritical);
    //For Max Threshold
    this.lineChartData[1].data.push(chartData[i].maxThreshold);
    this.lineChartData[1].data.push(chartData[i].maxThreshold);
    
    }
  }

  public Forecast(){
    this.router.navigate(['/forecast']);
  }

  openDialog(): void {
    const dialogRef = this.dialog.open(MotorConditionCustomPopup, {
      //width: '350px',
      data: {customDate: this.customDate,customTimemodel:this.customTimemodel},//, DurationTime:this.DurationTime},
      disableClose: true
    },);

    dialogRef.afterClosed().subscribe(result => {
    
      if(result){
      this.customDate =result.customDate;
      if(result.customTimemodel==null){
        let hr=this.datePipe.transform(this.customDate,'HH');
        let mn=this.datePipe.transform(this.customDate,'mm');
        this.customTimemodel= {hour: hr, minute: mn, second: 0};
       // this.customTimemodel= {hour: 12, minute: 0, second: 0};
      //this.customTimemodel["hour"]='12';this.customTimemodel["minute"]='00';
    }
      else
      this.customTimemodel = result.customTimemodel;
      
      this.DateTime_Selected=this.datePipe.transform(this.customDate,'MM-dd-yyyy')+' '+
      //this.customTimemodel[0].hour.toString()+":"+this.customTimemodel[0].minute.toString();
       this.customTimemodel["hour"].toString()+":"+this.customTimemodel["minute"].toString();
      this.Duration=result.customDuration;
      
      this.LoadGraphDetails();
      }
      else 
      {

      }
    });    
  }
 
}


  @Component({
    selector: 'motor-condition-custom-popup',
    templateUrl: './motor-condition-custom-popup.component.html',
    styleUrls: ['./motor-condition.component.scss']
  })
  export class MotorConditionCustomPopup {
    meridian = true;
    customTime = {hour: 13, minute: 30};
    constructor(public dialogRef: MatDialogRef<MotorConditionCustomPopup>,
      @Inject(MAT_DIALOG_DATA) public data: DialogData) {
        data.customDate=new Date();
data.customDuration='hour';
//data.customTime=[{hour: 13, minute: 30}];
      }
  
    onNoClick(): void {
      this.dialogRef.close();
    }
    onOKClick(): void{

    }
  
  }


