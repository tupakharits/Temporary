import {Component, OnInit, ViewChild} from '@angular/core';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {COMMA, ENTER} from '@angular/cdk/keycodes';
import {MatChipInputEvent} from '@angular/material';
import { utilityservice } from '../utility.service';
import {MotorService} from '../motor.service';
import { MotorConditionComponent } from '../motor-condition/motor-condition.component';
//import { Form, FormGroup } from '@angular/forms';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';

export interface PeriodicElement { 
  MotorName: string;
  MinCritical: string;
  MaxCritical: string;
  MinWarning:string;
  MaxWarning:string;
}
export interface EmailIds {
  name: string;
}
const ELEMENT_DATA: PeriodicElement[] = [
  
];

@Component({
  selector: 'app-configure',
  templateUrl: './configure.component.html',
  styleUrls: ['./configure.component.scss']
})

export class ConfigureComponent implements OnInit {
  displayedColumns: string[] = ['MotorName','MinCritical',  'MaxCritical', 'MinWarning','MaxWarning','Options'];
  dataSource = new MatTableDataSource(ELEMENT_DATA);
  data_temp:any[];
  Configdata:any;
  enableEdit:boolean=false;
   Motors:string[];//=['X-Motor','Z-Motor','C-Motor','C2-Motor','LP1-Motor','LP2-Motor' ];
   public name:string = '';
ParamSelect:string='MotorPower';
  isEditItems: boolean;
  DynamicEditStyle:string="NonEditStyle";
  Emails:string='';
  Email:string='';
  ReceipientList:string='';
  DbConnectionFail=false;
  enableEditIndex=null;

  constructor(private util:utilityservice, private motorService:MotorService, private formBuilder: FormBuilder,
    private SpinnerService: NgxSpinnerService) {
    this.util.displayNoSignUp=true;
    this.isEditItems=false;
   }
  @ViewChild(MatSort, {static: true}) sort: MatSort;

  ShowConfig()
  {
    this.motorService.getMotorDetails().subscribe((data:any):void => {
      this.Motors=[];
      this.Motors=data;
    },
    error =>{ 
      this.DbConnectionFail=true;
      console.log("Error :: " + error)});
  }
  GetConfigDetails(){
    this.SpinnerService.show();
    var param={"MotorFactor": this.ParamSelect}
    this.motorService.getConfigureDetails(param).subscribe((data:any):void => {
      this.Configdata=data;
      this.data_temp=data;
      this.DbConnectionFail=false;
      this.dataSource=this.Configdata["MotorThreshold"];
      (data) => {
        this.dataSource=this.Configdata["MotorThreshold"];       
        this.dataSource.sort = this.sort;
        this.SpinnerService.hide();
      }
    },
    error =>{ 
      this.DbConnectionFail=true;
      this.SpinnerService.hide();
      console.log("Error :: " + error)});

  }
EmailForm: FormGroup;
submitted = false;
  ngOnInit() {       

   // this.dataSource.sort = this.sort;
   this.EmailForm = this.formBuilder.group({    
    email: ['', [Validators.required, Validators.email,Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$')]]
});
   this.ShowConfig();
   this.GetConfigDetails();
   this.GetEmails();
  }
   // convenience getter for easy access to form fields
   get f() { return this.EmailForm.controls; }
   onSubmit() {
     //console.log("submitted");
    this.submitted = true;

    // stop here if form is invalid
    if (this.EmailForm.invalid) {
        return;
    }
this.addFieldValue(this.EmailForm.value.email);
   // alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.EmailForm.value))
}


  onSaveItems(row,i){
    this.enableEdit=false;
    this.enableEditIndex=null;
    var params={
      "parameterName":this.ParamSelect,
      "MinWarningLimit":row.minwarning,
      "MaxWarningLimit":row.maxwarning,
      "MinCriticalLimit":row.mincritical,
      "MaxCriticalLimit":row.maxcritical,
      "partName":row.motorname
    }
    this.motorService.SaveConfigureDetails(params).subscribe((data:any):void => {
      //console.log(data);
    },
      error =>{ 
        this.DbConnectionFail=true;
        console.log("Error :: " + error)
      });
    // this.isEditItems = false;
    // this.DynamicEditStyle="NonEditStyle";
    //Save to db
  }
  Cancel(row,i)
  {
    this.enableEdit=false;
    this.enableEditIndex=null;
    this.dataSource[i].mincritical=this.temp_minCrit;
    this.dataSource[i].minwarning=this.temp_minWarn;
    this.dataSource[i].maxcritical=this.temp_maxCrit;
    this.dataSource[i].maxwarning=this.temp_maxWarn;
   // this.dataSource=this.data_temp["MotorThreshold"];
  }
  temp_minCrit;
  temp_minWarn;
  temp_maxCrit;
  temp_maxWarn;
  startEdit(row,i){
this.enableEdit=true;
this.enableEditIndex=i;
this.temp_minCrit=row.mincritical;
this.temp_minWarn=row.minwarning;
this.temp_maxCrit=row.maxcritical;
this.temp_maxWarn=row.maxwarning;
  }

  changeParameter(parameter){ 
    this.EmailError=false;
    this.EmailErrorMin=false;
    if(parameter.index==0) //Power
    this.ParamSelect='MotorPower';
    else if(parameter.index==1)//Current
    this.ParamSelect='MotorCurrent';
    else if(parameter.index==2)//Motor Loading
    this.ParamSelect='MotorLoadingPercentage';
    //this.ParamSelect=parameter;
    this.GetConfigDetails();
    this.GetEmails();
  }

  // angular email chips
  visible = true;
  selectable = true;
  removable = true;
  addOnBlur = true;
  EmailError=false;
  EmailErrorMin=false;
  EmailDuplicateError=false;
  readonly separatorKeysCodes: number[] = [ENTER, COMMA];
  
  emailids:  EmailIds[]=[];
  GetEmails(){
    var params={
      "parametername":this.ParamSelect
      }
    this.motorService.GetEmailDetails(params).subscribe((data:any):void => {
      if(data){
        this.emailids=[];
              this.ReceipientList=data[0].recipientlist;
              if(this.ReceipientList){
                var splitted = this.ReceipientList.split(";", 3);                
                for(let i=0;i<splitted.length;i++)
                this.emailids.push({name: splitted[i]});
              }
          }
    },
      error =>{ 
        this.DbConnectionFail=true;
        console.log("Error :: " + error)
      });
  
  }
UpdateEmails(email)
{
  //console.log(this.ReceipientList+";"+email);
  var params={
    "parametername":this.ParamSelect,
    "email":email
    }
  this.motorService.UpdateEmailDetails(params).subscribe((data:any):void => {
       // console.log(data);
   
  },
    error =>{ 
      this.DbConnectionFail=true;
      console.log("Error :: " + error)
    });

}
addFieldValue(value) {
  value=value.toLowerCase();
  if(this.emailids.length>=3){
  this.EmailError=true;
  this.EmailDuplicateError=false;}
  else if (this.checkRoleExistence(value)){
    this.EmailDuplicateError=true;
    this.EmailError=false;
  }
  else{
    //const checkRoleExistence = roleParam => this.emailids.some( ({name}) => name == value)
    //console.log(this.checkRoleExistence(value));
  this.EmailDuplicateError=false;
    this.EmailErrorMin=false;  
    this.emailids.push({name: value});
    this.ReceipientList=this.emailids[0].name;
    for(let i=0;i<this.emailids.length;i++)
      this.ReceipientList=this.ReceipientList+";"+this.emailids[i].name;
      
    this.UpdateEmails(this.ReceipientList);
   
  }
}
checkRoleExistence(roleLabel: string):boolean {
  return this.emailids.some(r => r.name === roleLabel);
}
 
  remove(emailid: EmailIds): void {
    const index = this.emailids.indexOf(emailid);
    
    
    if(this.emailids.length==1){
        this.EmailErrorMin=true;       
    }
    else if (index >= 0) { 
      if(confirm("Are you sure to delete "+emailid)) {
      this.emailids.splice(index, 1);  
      this.ReceipientList=this.emailids[0].name;        
      for(let i=1;i<this.emailids.length;i++)
          this.ReceipientList=this.ReceipientList+";"+this.emailids[i].name;
      this.UpdateEmails(this.ReceipientList);     
      this.EmailError=false;
      this.EmailDuplicateError=false;
      }
    }
  }
  handlePatternEmail(){
   
    var regex = /^[A-Za-z0-9!@#$%^&*()_]{4,20}$/;
  return {
    test: function(value) {      
        return (value.length > 0) ? regex.test(value) : true;
    
    }
  };
  }

}
