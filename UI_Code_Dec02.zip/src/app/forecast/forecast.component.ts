import { Component, OnInit } from '@angular/core';
import { ChartDataSets, ChartOptions } from 'chart.js';
import { Color, Label } from 'ng2-charts';
import { utilityservice } from '../utility.service';
import { MotorService } from  '../motor.service';

@Component({
  selector: 'app-forecast',
  templateUrl: './forecast.component.html',
  styleUrls: ['./forecast.component.scss']
})
export class ForecastComponent implements OnInit {

  constructor(private util:utilityservice,private MotorService:MotorService) { 
    this.util.displayNoSignUp=true;
  }
public MotorName:string='X-Motor';
public Chart_selected:string='Power';
public motorDetails:any[];
public width:number=500;
public param_factor='MotorPower';
public GraphDetails:any;

public PerformanceTimeLineChart: any[]=[//] ChartDataSets[] = [
  { data: [], label: 'Power',fill: false },
   { data: [], label: 'Forecast',fill: false },
  { data: [], label: 'Threshold',fill: false },
  { data: [], label: 'Warning',fill: false },
  { data: [], label: 'Min Threshold',fill: false },
    { data: [], label: 'Min Warning',fill: false }
];

 public PerformanceTimeLineChartLabels: Label[] = [];//['12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00','19:00'];

private  PerformanceTimeLineOptions: any = {
  legend: { position: 'bottom' },
  scales: {
    yAxes: [{
        ticks: {
            beginAtZero: true
        }
    }]
  }
}
public PerformanceTimeLineChartColors: Color[] = [
  {borderColor: 'blue'},
  {borderColor:'#C4EE17'},
    {borderColor: 'Orange',},
    {borderColor: 'red',},
    {borderColor: 'Orange',},
    {borderColor: 'red',},
];
public PerformanceTimeLineChartLegend = true;
public PerformanceTimeLineChartType = 'line';
public PerformanceTimeLineChartPlugins = [];


  ngOnInit() {
    this.showConfig();
  }
showConfig(){
  this.MotorService.getMotorDetails().subscribe((data) => {
    this.motorDetails=data;
    console.log(data);
  });
  if(this.Chart_selected=='Power'){this.param_factor='MotorPower';}
  else if(this.Chart_selected=='Current'){this.param_factor='MotorCurrent';}
  else {this.param_factor='MotorLoadingPercentage';}
   var params={
       PartName:this.MotorName,
       Parameter:this.param_factor
        }
    this.MotorService.getMotorForcastDetails(params).subscribe((data)=>{
       this.GraphDetails=data;
       this.LoadChart(this.GraphDetails);
        });

}

  public ChangeMotor(Motor_name){   
    this.MotorName=Motor_name;
    this.showConfig();
  }
  public LoadChart(graphDetails){
    if(graphDetails.HistoricData.length>0){
      for(let i=0;i<graphDetails.HistoricData.length;i++)
      {
        this.PerformanceTimeLineChartLabels.push(graphDetails.HistoricData[i].DateTime);
        this.PerformanceTimeLineChart[0].data.push(graphDetails.HistoricData[i].value);//Power
        this.PerformanceTimeLineChart[1].data.push([,]);//Power
        this.PerformanceTimeLineChart[2].data.push(graphDetails.HistoricData[i].maxthreshold);//Max Threshold
        this.PerformanceTimeLineChart[3].data.push(graphDetails.HistoricData[i].maxcritical);//Max warning
        this.PerformanceTimeLineChart[4].data.push(graphDetails.HistoricData[i].minthreshold);//Min Threshold
        this.PerformanceTimeLineChart[5].data.push(graphDetails.HistoricData[i].mincritical);//Min critical
      }  
    }
    if(graphDetails.ForecastData.length>0){
      for(let i=0;i<graphDetails.ForecastData.length;i++){
      this.PerformanceTimeLineChartLabels.push(graphDetails.ForecastData[i].DateTime);
      this.PerformanceTimeLineChart[1].data.push(graphDetails.ForecastData[i].value);//Forecast
        this.PerformanceTimeLineChart[2].data.push(graphDetails.HistoricData[graphDetails.HistoricData.length-1].maxthreshold);//Max Threshold
        this.PerformanceTimeLineChart[3].data.push(graphDetails.HistoricData[graphDetails.HistoricData.length-1].maxcritical);//Max warning
        this.PerformanceTimeLineChart[4].data.push(graphDetails.HistoricData[graphDetails.HistoricData.length-1].minthreshold);//Min Threshold
        this.PerformanceTimeLineChart[5].data.push(graphDetails.HistoricData[graphDetails.HistoricData.length-1].mincritical);//Min critical
      }
    }
  }
  public changeChart(Chart_data){
    this.Chart_selected=Chart_data;
    this.PerformanceTimeLineChart[0].label=Chart_data;
    this.showConfig();
  }
}
