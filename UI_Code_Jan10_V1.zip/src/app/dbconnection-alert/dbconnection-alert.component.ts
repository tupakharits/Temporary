import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-dbconnection-alert',
  templateUrl: './dbconnection-alert.component.html',
  styleUrls: ['./dbconnection-alert.component.scss']
})
export class DBConnectionAlertComponent implements OnInit {
 private DBConnectinError=true;
 private subscription: Subscription;
  //message: any;
  constructor() { }

  ngOnInit() {
  }

}
