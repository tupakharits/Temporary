import CreateApp from './app';
import logger from '../logger';
import express from 'express';
import { db, dec_enabled_db } from "./db/db-provider";
import bodyParser from 'body-parser';
const port = process.env.PORT || 3000;
import cors from 'cors';

const app = CreateApp();

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

const queryText = `SELECT fn_dashboardsummary()`;
const querySETAlertText = `SELECT fn_setalerts()`;
const queryTENMinuteFunction = `SELECT fn_parametersummary()`;
const queryHourlyMinuteFunction = `SELECT fn_parametersummarydaily()`;

const queryMinuteCheckText = `SELECT fn_checkandacquiresummarylock(2)`;
const queryTENMinuteCheckText = `SELECT fn_checkandacquiresummarylock(3)`;
const queryHourlyMinuteCheckText = `SELECT fn_checkandacquiresummarylock(4)`;
const querySetAlertCheckText = `SELECT fn_checkandacquiresummarylock(9)`;

const releaseMinute2 = `SELECT fn_releasesummarylock(2)`;
const releaseTENMinute3 = `SELECT fn_releasesummarylock(3)`;
const releaseHourlyMinute4 = `SELECT fn_releasesummarylock(4)`;
const releaseSETAlert9 = `SELECT fn_releasesummarylock(9)`;

let minuteCheckResult;
let TENMinuteCheckResult;
let HourlyMinuteCheckResult;
let SetAlertCheckResult;

async function DBCall(query: string) {
    let dbResult: any;
    dbResult = await db.query(query);
    return dbResult.rows;
}

async function MinuteCall() {
    try {
        let minuteSummaryLockDBValue = await DBCall(queryMinuteCheckText)
        minuteCheckResult = minuteSummaryLockDBValue[0]['fn_checkandacquiresummarylock']
        if (minuteCheckResult == 1) {
            DBCall(queryText).then(() => {
                DBCall(releaseMinute2);
            })
        }

        let SetAlertSummaryLockDBValue = await DBCall(querySetAlertCheckText);
        SetAlertCheckResult = SetAlertSummaryLockDBValue[0]['fn_checkandacquiresummarylock']
        if (SetAlertCheckResult == 1) {
            DBCall(querySETAlertText).then(() => {
                DBCall(releaseSETAlert9);
            });
        }
    } catch (error) {
        logger.error("error in user get function: " + error);
    }
}

async function TenMinuteCall() {
    try {
        let TENMinuteSummaryLockDBValue = await DBCall(queryTENMinuteCheckText);
        TENMinuteCheckResult = TENMinuteSummaryLockDBValue[0]['fn_checkandacquiresummarylock']
        if (TENMinuteCheckResult == 1) {
            DBCall(queryTENMinuteFunction).then(() => {
                DBCall(releaseTENMinute3);
            });
        }
    } catch (error) {
        logger.error("error in user get function: " + error);
    }
}

async function HourCall() {
    try {
        let HourlyMinuteSummaryLockDbVal = await DBCall(queryHourlyMinuteCheckText);
        HourlyMinuteCheckResult = HourlyMinuteSummaryLockDbVal[0]['fn_checkandacquiresummarylock']
        if (HourlyMinuteCheckResult == 1) {
            DBCall(queryHourlyMinuteFunction).then(() => {
                DBCall(releaseHourlyMinute4);
            });
        }
    } catch (error) {
        logger.error("error in user get function: " + error);
    }
}

app.listen(port, () => {
    logger.debug(`server running on port ${port}`);
    console.log(`server running on port ${port}`);
    dec_enabled_db(process.env.DB_URL !== undefined ? process.env.DB_URL : '');
    setInterval(MinuteCall, 60000);
    setInterval(TenMinuteCall, 60000 * 10);
    setInterval(HourCall, (60000 * 60));
});