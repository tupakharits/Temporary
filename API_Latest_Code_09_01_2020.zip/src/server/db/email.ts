import {db} from "./db-provider";

export class EmailDBOperations {
  async emailQuery(queryText: string, params?: []) {
    let dbResult: any;
    dbResult = await db.query(queryText, params);
    return dbResult.rows;
  }
}
