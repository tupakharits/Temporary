import {db} from "./db-provider";

export class PartsDBOperations {
  async queryPartsDetails(queryText: string, params: []) {
    let dbResult: any;
    dbResult = await db.query(queryText, params);
    return dbResult.rows;
  }
}
