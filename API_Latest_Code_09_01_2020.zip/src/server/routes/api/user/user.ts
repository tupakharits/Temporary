import express, { Request, Response } from "express";
import { UserDBOperations } from "../../../db/user";
import logger from '../../../../logger';

const routes = express.Router();
routes.get("/:id", async (req: Request, resp: Response) => {
  try {
    logger.debug("Inside user");
    let userId: number;
    userId = +req.params.id;
    const queryText = "Select * from AVIOCBMUser where Id=$1";
    let params: any = [];
    params.push(userId);
    const dbResult = await new UserDBOperations().userDetails(
      queryText,
      params
    );

    //once integrated with postgress plz uncomment above line and remove below line and remove JSON.parse function.
    //const dbResult = `[{"id":2,"firstname":"John2","lastname":"Doe2","email":"john2@example.com","mobile":"1234567891","login":"jdoe2","lastlogin":null}]`;
    resp.send(dbResult);
  } catch (error) {
    logger.error("error in user get function: " + error);
    resp.status(500).json({ message: error.message ? error.message : "" });
  }
});

export default routes;
