import express, { Request, Response } from "express";
import { PartsDBOperations } from "../../../db/parts";
import logger from '../../../../logger';

const routes = express.Router();
routes.get("/", async (req: Request, resp: Response) => {
  try {
    const queryText = "select partname,motorstatus,(select avgmotorloadingpercent from partsummaryplotinfo b where b.partid= a.partid ) as avgmotorloadingpercent,(select effectivemotorlifeconsumption from partsummaryplotinfo b where b.partid= a.partid ) as effectivemotorlifeconsumption from partsummaryinfo a";
    let params: any = [];
    const dbResult = await new PartsDBOperations().queryPartsDetails(
      queryText,
      params
    );
    
    //once integrated with postgress plz uncomment above line and remove below line and remove JSON.parse function.
    //const dbResult=`[{"id":1,"partid":1,"partname":"X-Motor","motorstatus":"R","avgmotorloadingpercent":"85.00","effectivemotorlifeconsumption":"2555.00"},{"id":2,"partid":2,"partname":"Z-Motor","motorstatus":"G","avgmotorloadingpercent":"30.00","effectivemotorlifeconsumption":"2920.00"},{"id":3,"partid":3,"partname":"C-Motor","motorstatus":"G","avgmotorloadingpercent":"45.00","effectivemotorlifeconsumption":"4380.00"},{"id":4,"partid":4,"partname":"C2-Motor","motorstatus":"A","avgmotorloadingpercent":"5.00","effectivemotorlifeconsumption":"5475.00"},{"id":5,"partid":5,"partname":"LP1-Motor","motorstatus":"G","avgmotorloadingpercent":"3.00","effectivemotorlifeconsumption":"730.00"},{"id":6,"partid":6,"partname":"LP2-Motor","motorstatus":"G","avgmotorloadingpercent":"120.00","effectivemotorlifeconsumption":"1095.00"}]`;
    
    resp.setHeader("Content-type","application/json");
    resp.json(dbResult);
  } catch (error) {
    logger.error("error in parts get function: " + error);
    resp.status(500).json({ message: error.message ? error.message : "" });
  }
});

export default routes;
