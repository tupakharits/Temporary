var awsIot = require('aws-iot-device-sdk');
var ParseData = require('./src/parser/parsedata').parseData;
const path = require('path');
const logger = require('./logger').logger;
logger.debug(__dirname);
var thingShadows = awsIot.thingShadow({
    keyPath: path.resolve(__dirname, 'certs',process.env.KEY_FILE_NAME),
    certPath: path.resolve(__dirname, 'certs',process.env.CERT_FILE_NAME),
    caPath: path.resolve(__dirname, 'certs',process.env.CA_FILE_NAME),
    debug: true,    
    host: process.env.HOST_NAME
});


thingShadows.on('connect', () => {
    logger.debug('IOT Core connected');
    thingShadows.subscribe('CBM');
    //thingShadows.publish('TestTopic', jsonPacket);
});

thingShadows.on('message', async (topic,payload)=> {    
    if(topic === 'CBM') {
      try {
        await ParseData.parserLogic(payload);
      } catch(error) {
        logger.error(error);
      } 
    }
});

thingShadows.on('error',(error) => {  
  logger.error("IOT Core Connection error: " + error);
  process.exit(0);
});
