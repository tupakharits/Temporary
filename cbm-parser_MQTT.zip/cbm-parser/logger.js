const {createLogger, format, transports} = require('winston');
require('winston-daily-rotate-file');
const { printf } = format;
const fs = require('fs');
const path = require('path');

const logDir = 'log';

// Create the log directory if it does not exist
if (!fs.existsSync(path.resolve(__dirname, logDir))) {
    fs.mkdirSync(path.resolve(__dirname, logDir));
}

//rotate the logfile
const dailyRotateFileTransport = new transports.DailyRotateFile({
    filename: `${path.resolve(__dirname, logDir)}/%DATE%-logError.log`,
    datePattern: 'YYYY-MM-DD-HH'
});

//format the error
const myFormat = printf((info) => {
  console.log(info);
  if (info.meta && info.meta instanceof Error) {      
    return `${info.timestamp} ${info.level} ${info.message} : ${info.meta.stack}`;
  } 
  return `${info.timestamp} ${info.level}: ${info.message}`;
});

const logger = createLogger({
    level: 'debug',
    format: format.combine(
        format.timestamp({
          format: 'YYYY-MM-DD HH:mm:ss'
        }),
        myFormat
    ),
    transports: [
        new transports.Console({
          level: 'info',
          format: format.combine(
            format.colorize(),
            format.printf(
              info => `${info.timestamp} ${info.level}: ${info.message}`
            )
          )
        }),
        dailyRotateFileTransport
    ]
});

exports.logger = logger;


