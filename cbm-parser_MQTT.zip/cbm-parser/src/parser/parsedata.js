var ParserDbOpeartions = require("../db/parser-db-operations").ParserDbOpeartions;
const logger = require('../../logger').logger;

const parseData = {
  async parserLogic(req) {
    let reqPayload;
    console.log('Inside parseData before parsing')
    logger.debug('Inside parseData before parsing');
    //reqPayload = req;
    reqPayload = JSON.parse(req);
    console.log('Inside parseData after parsing');
    logger.debug('Inside parseData after parsing');
    for (let message of reqPayload.messages) {
      let payload = [];
      let packetHeader;
      let splittedPacketDetails;
      let packetVersion;
      let entityId;
      let locationId;
      let plantId;
      let departmentId;
      let machineId = 0;
      let headerTimeStamp;
      let currentTimeStamp;
      var packetId = 0;
      
      payload = message.payload.Values;

      try {
        packetHeader = message.payload.PacketHeader.toString();
        splittedPacketDetails = packetHeader.split(".");

        if (splittedPacketDetails.length !== 6) {          
          throw new Error(`Header ${splittedPacketDetails} has missing values`);
        }

        packetVersion = +splittedPacketDetails[0];
        entityId = +splittedPacketDetails[1];
        locationId = +splittedPacketDetails[2];
        plantId = +splittedPacketDetails[3];
        departmentId = +splittedPacketDetails[4];
        machineId = +splittedPacketDetails[5];
        //headerTimeStamp = new Date(reqPayload.payload.Timestamp);
        headerTimeStamp = new Date(message.payload.Timestamp).toISOString();
        currentTimeStamp = new Date(Date.now()).toISOString();        
        packetId = await new ParserDbOpeartions().insertPacket([
          packetVersion,
          entityId,
          locationId,
          plantId,
          departmentId,
          machineId,
          headerTimeStamp,
          currentTimeStamp
        ]);
        logger.debug(`Record Inserted Successfully into Packet Table having PacketId ${packetId}`);
      } catch (error) {        
        logger.error(error);
        continue;
      }

      for (let item of payload) {
        try {
          let machineParameter;
          let splittedMachineParameters = [];
          let moduleTypeId;
          let moduleId;
          let partId;
          let parameterId;
          let parameterTimeStamp;

          machineParameter = item.id.toString();
          splittedMachineParameters = machineParameter.split(".");
          if (splittedMachineParameters.length !== 5) {
            throw new Error(`Machine Parameter ${machineParameter} is missing some details`);
          }

          moduleTypeId = +splittedMachineParameters[1];
          moduleId = +splittedMachineParameters[2];
          partId = +splittedMachineParameters[3];
          parameterId = +splittedMachineParameters[4];

          let value = item.v;
          let quality = item.q === true ? 1 : 0;
          parameterTimeStamp = new Date(item.t);

          const packetDataId = await new ParserDbOpeartions().insertPacketData([
            machineId,
            moduleTypeId,
            moduleId,
            partId,
            parameterId,
            value,
            quality,
            parameterTimeStamp,
            packetId
          ]);
          logger.debug(`Record Inserted Successfully into PacketData Table having PacketDataId ${packetDataId}`);
        } catch (error) { logger.error(error);}
      }
    }
  }
};

exports.parseData = parseData;
