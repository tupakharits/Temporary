const express = require('express');
const SSOAuthRoute = express.Router();
const request = require('request');

const clientID = 'CBM_AVIO_AERO';
const clientSecret = '5$9AGMbwcrF$W5IHDy@Lh$Vy9qRgihBElUcO9ZHwtNpXUZMW70nRRQJuE9JLlzRW';

const oauth2 = require('simple-oauth2').create({
  client: {
    id: clientID,
    secret: clientSecret,
  },
  auth: {
    tokenHost: 'https://cbm.avio.net/',
    tokenPath: 'https://fssfed.ge.com/fss/as/token.oauth2',
    authorizePath: 'https://fssfed.ge.com/fss/as/authorization.oauth2',
  },
  http: {
    headers: {
      'Access-Control-Allow-Origin': '*'
    }
  }
});

// Authorization uri definition
const authorizationUri = oauth2.authorizationCode.authorizeURL({
  redirect_uri: 'https://cbm.avio.net/',
  scope: '',
  state: '3(#0/!~',
});

// Initial page redirecting to GE
SSOAuthRoute.route('/login').post((req, res) => {
    console.log('Login api');
    console.log(authorizationUri);
    res.redirect(authorizationUri);
});

// Callback service parsing the authorization token and asking for the access token
SSOAuthRoute.route('/callback', async (req, res) => {
  const { code } = req.query;
  const options = {
    code,
  };

  try {
    const result = await oauth2.authorizationCode.getToken(options);
    debugger;
    console.log('The resulting token: ', result);

    const token = oauth2.accessToken.create(result);

    return res.status(200).json(token);
  } catch (error) {
    console.error('Access Token Error', error.message);
    return res.status(500).json('Authentication failed');
  }
});

module.exports = SSOAuthRoute;