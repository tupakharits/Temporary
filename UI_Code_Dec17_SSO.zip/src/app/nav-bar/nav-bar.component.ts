import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.scss']
})
export class NavBarComponent implements OnInit {

  constructor() { }
  activeItem: string;
  
  ngOnInit() {
  }

  setActiveItem(page: string) {
    this.activeItem = page;
    //console.log(this.activeItem);
  }
}
